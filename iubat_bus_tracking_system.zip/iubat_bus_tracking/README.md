# IUBAT Bus Tracking System

A comprehensive real-time bus tracking system for IUBAT (International University of Business Agriculture and Technology) built with modern web technologies and IoT integration.

## 🚀 Features

- **Real-time GPS Tracking**: Live bus location updates via ESP32 with NEO-6M GPS
- **Multi-user System**: Student, Faculty, and Admin roles with different access levels
- **Interactive Maps**: React Leaflet integration for live bus tracking
- **Route Management**: Dynamic shuttle route management by admins
- **Responsive UI**: Modern, mobile-friendly interface
- **RESTful API**: Clean backend API with proper error handling
- **MongoDB Integration**: NoSQL database with optimized schemas

## 🏗️ Architecture

### Frontend
- **React.js** - Component-based UI framework
- **React Router** - Client-side routing
- **React Leaflet** - Interactive maps
- **Axios** - HTTP client for API calls
- **CSS3** - Modern styling with responsive design

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **Mongoose** - ODM for MongoDB
- **JWT** - Authentication tokens
- **bcrypt** - Password hashing

### Hardware
- **ESP32-CAM** - Microcontroller with WiFi
- **NEO-6M GPS** - GPS module for location tracking
- **HTTP Client** - Send location data to backend

## 📁 Project Structure

```
iubat_bus_tracking/
├── backend/
│   ├── config/ controllers/ middleware/ models/ routes/ services/
│   ├── tests/ yolo_server/
│   ├── .env.example
│   ├── package.json, package-lock.json
│   └── server.js and database scripts
├── esp32/
│   └── esp32_code/             # firmware and setup/troubleshooting guides
├── frontend/
│   ├── public/
│   ├── src/
│   │   ├── components/ pages/ utils/
│   │   └── App.js, index.js
│   ├── .env.example
│   └── package.json, package-lock.json
├── database_design.md
├── ENVIRONMENT_SETUP.md
└── README.md
```

## 🔧 Installation & Setup

### Prerequisites
- Node.js 20 or newer and npm
- MongoDB (local or Atlas)
- Python (only if running the optional YOLO inference service)
- Arduino IDE (only for flashing/configuring ESP32 hardware)

### Backend Setup

1. **Navigate to backend directory:**
   ```bash
   cd backend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Environment Configuration:**
   - Copy `backend/.env.example` to `backend/.env`.
   - Set `MONGO_URI` to your own MongoDB connection string and replace `JWT_SECRET` with a long, unique random value.
   - For the one-time admin creation script, also set `ADMIN_USERNAME`, `ADMIN_EMAIL`, and `ADMIN_PASSWORD`.
   - Optional settings include `YOLO_SERVER_URL` and the `MAIL_*` SMTP variables. Keep all real values in `.env`; never commit it or put secrets in frontend variables.

4. **Start MongoDB:**
   ```bash
   # For local MongoDB
   mongod

   # Or use MongoDB Atlas (cloud)
   ```

5. **Optional database setup:**
   ```bash
   # Creates an admin; set ADMIN_USERNAME, ADMIN_EMAIL, and ADMIN_PASSWORD first
   node createAdmin.js
   ```
   `node createUsers.js` is an optional sample student-account seeder and requires `STUDENT_INITIAL_PASSWORD`. `node seedRoutes.js` replaces existing routes of type `all`; review its data and effect before running it.

6. **Start backend server:**
   ```bash
   npm start
   ```

### Frontend Setup

1. **Navigate to frontend directory:**
   ```bash
   cd frontend
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Environment Configuration (optional):**
   - Copy `frontend/.env.example` to `frontend/.env` if the backend API is not at `http://localhost:5000`.
   - Set `REACT_APP_API_BASE_URL` to the backend base URL. React embeds this value at build time; do not put secrets in frontend variables.

4. **Start development server:**
   ```bash
   npm start
   ```

For a production frontend bundle, run `npm run build` from `frontend/`. The `REACT_APP_API_BASE_URL` setting is embedded at build time and must not contain credentials or other secrets.

### Optional YOLO Inference Service

```bash
cd backend/yolo_server
python -m venv .venv
# Activate the virtual environment, then:
python -m pip install -r requirements.txt
python yolo_server.py
```

The service loads the project model file `yolov8n.pt` and listens on port 5001. Python environments, caches, and backend bus-image uploads are ignored by Git; the model and existing project images are retained.

### ESP32 Firmware

Open the firmware in `esp32/esp32_code/` with Arduino IDE. Configure Wi-Fi credentials and the backend endpoint locally on the device; do not commit real Wi-Fi credentials. The firmware and troubleshooting documentation are under `esp32/`.

### YOLO Inference Service (optional)

The YOLO service is in `backend/yolo_server`. Create a Python environment, install `backend/yolo_server/requirements.txt`, and run `yolo_server.py` from that directory. The tracked `yolov8n.pt` model is retained; generated Python environments and caches are excluded from Git.

### ESP32 Setup

1. **Install Arduino IDE**
2. **Install ESP32 board support**
3. **Install required libraries:**
   - TinyGPS++
   - WiFi
   - HTTPClient

4. **Configure ESP32 code:**
   - Set Wi-Fi credentials locally in the device configuration; do not commit real network passwords.
   - Update backend API URL
   - Set unique bus ID

5. **Upload code to ESP32**

## 📡 API Endpoints

### Location APIs
- `POST /api/location/update` - Update bus location (ESP32)
- `GET /api/location/:busId` - Get bus location
- `GET /api/location/history/:busId` - Get location history

### Route APIs
- `GET /api/shuttle-routes` - Get all shuttle routes
- `GET /api/shuttle-routes/:id` - Get specific route

### Admin APIs
- `POST /api/admin/login` - Admin login
- `POST /api/admin/add-route` - Add new route
- `PUT /api/admin/update-route/:id` - Update route
- `DELETE /api/admin/delete-route/:id` - Delete route
- `GET /api/admin/routes` - Get all routes
- `POST /api/admin/add-bus` - Add new bus
- `GET /api/admin/buses` - Get all buses

## 🗄️ Database Schema

See `database_design.md` for detailed MongoDB collection schemas and relationships.

## 🔐 Authentication

- **JWT Tokens** for session management
- **bcrypt** for password hashing
- **Role-based access** (Student, Faculty, Admin)

## 📱 Usage

### For Students/Faculty
1. Login with credentials
2. View available shuttle routes
3. Track buses on live map
4. Check schedules

### For Admins
1. Login to admin panel
2. Add/edit/delete routes
3. Manage buses
4. Monitor system

### ESP32 Integration
- Automatically connects to WiFi
- Reads GPS coordinates
- Sends location updates every 5 seconds
- Handles connection failures gracefully

## 🧪 Testing

### API Testing
```bash
# Test location update
curl -X POST http://localhost:5000/api/location/update \
  -H "Content-Type: application/json" \
  -d '{
    "busId": "BUS_001",
    "latitude": 23.7937,
    "longitude": 90.4066,
    "timestamp": "2024-01-01T10:00:00Z"
  }'

# Test get routes
curl http://localhost:5000/api/shuttle-routes
```

### Frontend Testing
```bash
cd frontend
npm test
```

## 🚀 Deployment

### Backend Deployment
```bash
# Run the Node.js backend with a process manager if needed
npm install -g pm2
pm2 start server.js --name "iubat-bus-backend"
```

### Frontend Deployment
```bash
cd frontend
npm run build

# Deploy build folder to web server
```

### ESP32 Deployment
- Flash code to multiple ESP32 devices
- Configure unique bus IDs for each device
- Ensure stable WiFi connectivity

## 🔧 Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   - Check MongoDB is running
   - Verify connection string in `.env`

2. **ESP32 WiFi Issues**
   - Check WiFi credentials
   - Ensure ESP32 is in range of WiFi

3. **Map Not Loading**
   - Check internet connection
   - Verify Leaflet CSS/JS loading

4. **API Authentication Errors**
   - Check JWT token validity
   - Verify admin credentials

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License

This project is licensed under the MIT License.

## 📞 Support

For support and questions:
- Create an issue on GitHub
- Contact the development team

## 🔄 Future Enhancements

- Real-time notifications
- Route optimization
- Mobile app development
- Advanced analytics dashboard
- Integration with Google Maps API
- Offline map support