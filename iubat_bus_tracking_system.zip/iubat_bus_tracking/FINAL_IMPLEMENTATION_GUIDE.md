# IUBAT BUS TRACKING SYSTEM - Complete Implementation Guide
## End-to-End Pipeline Setup

**System Status**: Ready for final testing  
**Last Updated**: 2026-09-02  
**Hardware**: ESP32-CAM + NEO-6M GPS + SIM800L (WiFi primary mode)

---

## 🚀 QUICK START (5 Minutes)

### Prerequisites
- Backend running: `npm start` on port 5000
- YOLO server running: `python yolo_server.py` on port 5001
- MongoDB running locally or connected via URI
- ngrok tunnel active: `ngrok http 5000`
- ESP32-CAM connected to WiFi network "[YOUR_WIFI_SSID]" with password "[YOUR_WIFI_PASSWORD]"

### Step 1: Start Backend
```bash
cd backend
npm install
npm start
```
**Expected Output**: 
```
✅ MongoDB connected
✅ Server listening on port 5000
🔥🔥🔥 Upload endpoint ready at POST /api/bus/upload
```

### Step 2: Start YOLO Server
```bash
cd backend/yolo_server
python yolo_server.py
```
**Expected Output**:
```
📥 Loading YOLO AI model...
✅ YOLO model loaded successfully!
Running on http://localhost:5001
```

### Step 3: Activate ngrok Tunnel
```bash
ngrok http 5000
```
**Expected Output** (note the HTTPS URL):
```
Forwarding https://xxx-xxx-xxx.ngrok-free.dev -> http://localhost:5000
```

### Step 4: Upload ESP32 Code
1. Open `esp32/esp32_code.ino` in Arduino IDE
2. Install libraries:
   - esp_camera (built-in)
   - TinyGPS++ (Mikal Hart)
   - ArduinoJson (Benoit Blanchon)
   - WiFi (built-in)
3. Select board: "AI Thinker ESP32-CAM"
4. Select COM port
5. Click **Upload**

### Step 5: Monitor Serial Output
```
COM port: 115200 baud
Expected in first 30 seconds:
  ✅ GPS initialized
  ✅ WiFi CONNECTED
  📍 GPS FIX: YES
  ✅ Camera ready
```

**After 30 seconds** (automatic capture and upload):
```
📤 WiFi HTTPS UPLOAD SEQUENCE
Connecting to secure server...
Connected: YES (HTTPS established)
Bytes Sent: XXXX
===== ACTUAL SERVER RESPONSE =====
{"success":true,"passengerCount":X,...}
👥 PASSENGER COUNT: X
```

---

## 🔍 VERIFICATION CHECKLIST

### Backend Logs Check
After ESP32 uploads:
```
🔥🔥🔥 UPLOAD ENDPOINT WAS HIT! 🔥🔥🔥
📥 Received from ESP32-CAM:
   Bus ID: BUS-001
   Image: BUS-001_TIMESTAMP.jpg
   Image Size: XXXX
   GPS: 23.888138, 90.390167
   Speed: 1.3
   Satellites: 6

✅ Data saved to MongoDB (processing): 63a1b2c3d4e5f6...
✅ Image storage time: 120 ms
✅ Location history saved: BUS-001

🔄 Sending to YOLO for detection...
   YOLO URL: http://localhost:5001/detect
✅ YOLO Response received
   Passenger Count: 5
   Total Detections: 5

✅ Updated passenger count: 5
```

### File System Check
```bash
# Image should exist
ls backend/uploads/bus-images/
# Output: BUS-001_1693648800000.jpg

# Check file size is reasonable (5KB - 100KB for 320x240 JPEG)
ls -lh backend/uploads/bus-images/BUS-001_*.jpg
```

### MongoDB Check
```javascript
// In MongoDB compass or shell
use iubat_bus_tracking

// Check BusData collection
db.busdatas.findOne({ busId: "BUS-001" }, { sort: { createdAt: -1 } })
// Should show: busId, latitude, longitude, passengerCount, processing: false

// Check Bus collection (live status)
db.buses.findOne({ busId: "BUS-001" })
// Should show: currentLocation, currentPassengerCount, gpsFixed: true

// Check Location collection (GPS history)
db.locations.findOne({ busId: "BUS-001" }, { sort: { timestamp: -1 } })
// Should show: latitude, longitude, timestamp
```

### Frontend Check
1. Open React app: `http://localhost:3000`
2. Navigate to **Shuttle Bus Tracking** or live tracking page
3. Select BUS-001
4. Verify:
   - ✅ GPS marker appears on map
   - ✅ Passenger count displays
   - ✅ Speed displays
   - ✅ GPS status shows "YES"
   - ✅ Last update time is current
5. Wait 30 seconds for next upload
6. Verify all values update

---

## 📊 COMPLETE PIPELINE FLOW

```
ESP32-CAM
  ├─ Camera: Capture JPEG (320×240, Q12)
  ├─ GPS: Read coordinates from NEO-6M
  │   └─ Serial 2 (RX:15, TX:16)
  ├─ WiFi: Connect to "[YOUR_WIFI_SSID]" network
  │   └─ SerialClientSecure
  └─ Upload via HTTPS
      └─ POST https://xxx.ngrok-free.dev/api/bus/upload
         └─ multipart/form-data with image + metadata
```

⬇️

```
Backend (Node.js)
  ├─ Receive multipart upload
  ├─ Save image to disk
  ├─ Extract GPS data
  ├─ Save to BusData collection
  ├─ Update Bus collection with location
  └─ Call YOLO server
      └─ POST http://localhost:5001/detect
         └─ Returns passenger count
```

⬇️

```
YOLO Server (Python)
  ├─ Receive image
  ├─ Load YOLOv8n model
  ├─ Run inference (conf=0.25)
  ├─ Filter class=0 (person)
  └─ Count people + return detections
```

⬇️

```
MongoDB
  ├─ BusData: { busId, latitude, longitude, passengerCount, ... }
  ├─ Bus: { busId, currentLocation, currentPassengerCount, ... }
  └─ Location: { busId, latitude, longitude, timestamp, ... }
```

⬇️

```
React Frontend
  ├─ Poll GET /api/location/BUS-001 every 5 seconds
  ├─ Display map marker
  ├─ Show passenger count
  ├─ Show speed, GPS status
  └─ Update last refresh time
```

---

## ⚙️ CONFIGURATION

### ESP32 (esp32_code.ino)
```cpp
#define WIFI_SSID "[YOUR_WIFI_SSID]"
#define WIFI_PASSWORD "[YOUR_WIFI_PASSWORD]"
const char serverIP[] = "symphony-shady-selection.ngrok-free.dev";  // Update from ngrok
const int serverPort = 443;  // HTTPS
const char* backendEndpoint = "/api/bus/upload";
#define BUS_ID "BUS-001"
#define ROUTE_ID "ROUTE-01"

// Timing
const unsigned long UPLOAD_INTERVAL = 30000;  // 30 seconds
```

### Backend (server.js)
```javascript
// Auto-detected from environment:
// MongoDB URI: process.env.MONGO_URI or localhost:27017
// YOLO URL: process.env.YOLO_SERVER_URL or http://localhost:5001
// Backend port: process.env.PORT or 5000
```

### YOLO Server (yolo_server.py)
```python
model = YOLO('yolov8n.pt')  # Auto-download on first run
PERSON_CLASS = 0  # COCO dataset person class
app.run(host='0.0.0.0', port=5001)
```

### Frontend (.env or API config)
```
REACT_APP_API_BASE_URL=http://localhost:5000
```

---

## 🧪 STEP-BY-STEP TEST SEQUENCE

### TEST 1: Camera Capture
```
Expected Serial Output:
📷 Initializing camera...
✅ Camera ready!
===== CAMERA CAPTURE =====
✅ Image captured: 8234 bytes
```
**Status**: PASS/FAIL

### TEST 2: GPS Fix
```
Expected Serial Output:
📍 GPS DATA
📍 Latitude:  23.888138°
📍 Longitude: 90.390167°
✅ GPS Fixed: YES
🛰️  Satellites: 6
```
**Status**: PASS/FAIL

### TEST 3: WiFi Connection
```
Expected Serial Output:
📡 WiFi connecting to Admin...
✅ WiFi CONNECTED
📡 WiFi IP Address: 192.168.X.X
```
**Status**: PASS/FAIL

### TEST 4: HTTPS Upload
```
Expected Serial Output:
📤 WiFi HTTPS UPLOAD SEQUENCE
Connected: YES (HTTPS established)
Bytes Sent: 8234
===== ACTUAL SERVER RESPONSE =====
{"success":true,"passengerCount":3,...}
✅ HTTP 200-299 OK - Upload successful!
👥 PASSENGER COUNT: 3
```
**Status**: PASS/FAIL  
**Backend Response**: Check `/api/bus/upload` endpoint logs

### TEST 5: YOLO Detection
```
Expected Backend Logs:
🔄 Sending to YOLO for detection...
   YOLO URL: http://localhost:5001/detect
✅ YOLO Response received
   Passenger Count: 3
   Total Detections: 3
```
**Status**: PASS/FAIL

### TEST 6: MongoDB Update
```
Expected MongoDB State:
BusData: {
  busId: "BUS-001",
  latitude: 23.888138,
  longitude: 90.390167,
  passengerCount: 3,  ← Updated by YOLO
  processing: false,
  createdAt: ISODate(...)
}

Bus: {
  busId: "BUS-001",
  currentPassengerCount: 3,  ← Latest value
  currentLocation: { latitude: 23.888138, longitude: 90.390167, timestamp: ... },
  gpsFixed: true,
  satellites: 6,
  lastUpdated: ISODate(...)
}
```
**Status**: PASS/FAIL

### TEST 7: React Frontend Display
```
Expected Visual:
  [Map with marker at 23.888138, 90.390167]
  Bus ID: BUS-001
  Route: ROUTE-01
  Passengers: 3
  Speed: 1.3 km/h
  GPS Fixed: YES
  Satellites: 6
  Last Updated: 2 seconds ago
```
**Status**: PASS/FAIL  
**Test**: Refresh page, wait 5 seconds, verify update

### TEST 8: Continuous Polling (5-minute test)
```
Expected Behavior:
1. Upload #1 at T=0s
2. ESP uploads every 30 seconds
3. Frontend polls every 5 seconds
4. All 5+ uploads should show on both:
   - Backend logs: "UPLOAD ENDPOINT WAS HIT"
   - MongoDB: New BusData documents
   - React: Marker moves, numbers update
```
**Status**: PASS/FAIL

---

## 🔧 TROUBLESHOOTING

### Issue: ESP32 cannot connect to WiFi
```
Solution:
1. Verify SSID "[YOUR_WIFI_SSID]" is broadcasting
2. Check password "[YOUR_WIFI_PASSWORD]" is correct
3. Verify ESP32 is in range
4. Check Serial output for error messages
```

### Issue: WiFi connect but HTTPS fails (HTTP error)
```
Solution:
1. Verify ngrok tunnel is active: ngrok http 5000
2. Copy HTTPS URL from ngrok console
3. Update serverIP in esp32_code.ino
4. Re-upload ESP32 code
5. Check backend is running on port 5000
```

### Issue: Upload OK but MongoDB not updating
```
Solution:
1. Verify MongoDB is running: `mongod` or MongoDB Atlas connection
2. Check backend logs for database errors
3. Verify BusData model is loaded: grep "require.*BusData" server.js
4. Check connection string in .env or code
```

### Issue: YOLO fails (backend logs show error)
```
Solution:
1. Verify YOLO server running: http://localhost:5001/detect
2. Test YOLO manually with curl:
   curl -X POST -F "image=@test.jpg" http://localhost:5001/detect
3. Check YOLO model file exists: backend/yolo_server/yolov8n.pt
4. Verify Python dependencies: pip list | grep yolo
5. Check YOLO server logs for errors
```

### Issue: React shows "No live data available"
```
Solution:
1. Verify backend is running on correct port
2. Check API response: curl http://localhost:5000/api/location/BUS-001
3. Verify BusData exists in MongoDB
4. Check React console for CORS errors
5. Verify REACT_APP_API_BASE_URL is correct
6. Try manual refresh (F5) in browser
```

### Issue: HTTP 400 Bad Request from ESP32
```
Solution:
1. Check multipart boundary is consistent
2. Verify all form fields are present:
   - busId, routeId, latitude, longitude, altitude
   - speed, satellites, gpsFixed, date, time, image
3. Check Content-Length calculation
4. Verify image data is binary (not corrupted)
5. Check server logs for field validation errors
```

### Issue: HTTP 500 Internal Server Error
```
Solution:
1. Check backend console for exception
2. Verify MongoDB connection
3. Verify YOLO server is running
4. Check file permissions on uploads directory
5. Look for stack trace in backend logs
```

---

## 📈 PERFORMANCE METRICS

Expected values after successful upload:

| Metric | Expected | Range |
|--------|----------|-------|
| Image capture time | < 500ms | 100-800ms |
| HTTPS upload time | 2-5 sec | 1-10s |
| YOLO processing time | 1-3 sec | 0.5-5s |
| Total end-to-end | 3-9 sec | 2-15s |
| Image size (QVGA JPEG) | 5-30 KB | 3-50KB |
| Passenger accuracy | ±2 | ±3 |
| GPS accuracy | ±10m | ±30m |
| Frontend polling lag | 2-10s | 1-15s |

---

## 🎯 ACCEPTANCE CRITERIA

System is **COMPLETE** when:

- ✅ ESP32 compiles without errors
- ✅ GPS produces valid coordinates (test: `gpsFixed: true`, satellites > 3)
- ✅ WiFi connects successfully (SSID "[YOUR_WIFI_SSID]")
- ✅ HTTPS upload reaches backend (backend logs show "UPLOAD ENDPOINT WAS HIT")
- ✅ Backend receives image file (exists in uploads/bus-images/)
- ✅ Backend receives GPS metadata (latitude/longitude valid)
- ✅ YOLO runs and detects people (passenger count ≥ 0)
- ✅ MongoDB updates with passenger count (BusData.passengerCount > 0)
- ✅ Bus collection updates (Bus.currentPassengerCount matches latest)
- ✅ React displays latest passenger count (updates every 30 sec max)
- ✅ React map shows latest GPS location (marker moves correctly)
- ✅ React displays speed (currentSpeed)
- ✅ React displays GPS status (gpsFixed: true/false)
- ✅ React displays satellite count
- ✅ React shows "Last Updated: X seconds ago" (auto-refreshing)
- ✅ No hardcoded values in live display
- ✅ All 5+ uploads show unique timestamps in MongoDB
- ✅ No duplicate ESP32 sketches (only esp32_code.ino active)
- ✅ SIM800L path documented (WiFi is primary, SIM800L for fallback)
- ✅ All error messages are clear (no silent failures)
- ✅ System can run continuously for 5+ minutes

---

## 📝 NEXT STEPS (SIM800L)

After verifying WiFi works perfectly:

1. **Document Power**: SIM800L requires stable 3.8-4.0V, ~2A peak
2. **Add Regulator**: AMS1117-3.8V + 2x 10µF caps (VIN/GND)
3. **Uncomment SIM800L** in esp32_code.ino
4. **Test GPRS Path**: Follow phases 11-12 in requirements
5. **Verify Fallback**: Both WiFi and SIM800L working as primary/secondary

---

## 📞 Support

For debugging, attach output from:
1. Serial monitor (ESP32)
2. Backend console (npm start)
3. YOLO server console (python yolo_server.py)
4. Browser console (React)
5. MongoDB query results

All together paint the complete picture.
