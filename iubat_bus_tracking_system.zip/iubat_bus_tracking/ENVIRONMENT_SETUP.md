# Environment Setup for IUBAT Bus Tracking System

## 1. BACKEND CONFIGURATION

Create `backend/.env` by copying `backend/.env.example`. Set `MONGO_URI` to your own local or Atlas connection string and replace `JWT_SECRET` with a long, unique secret. Never commit `.env` or paste a real connection string into documentation.

```env
PORT=5000
MONGO_URI=mongodb://localhost:27017/iubat_bus_tracking
JWT_SECRET=<generate-a-long-random-secret>
YOLO_SERVER_URL=http://localhost:5001

# Optional SMTP configuration for password-reset email
MAIL_HOST=<your-smtp-host>
MAIL_PORT=587
MAIL_USER=<your-smtp-username>
MAIL_PASS=<your-smtp-app-password>
MAIL_SECURE=false
MAIL_FROM=<sender-address>
```

### Startup Commands

#### Terminal 1: MongoDB
```bash
# Windows
mongod
# OR MongoDB Atlas (no local startup needed)
```

#### Terminal 2: YOLO Server
```bash
cd backend/yolo_server
python yolo_server.py
# Output should show: Running on http://localhost:5001
```

#### Terminal 3: Backend
```bash
cd backend
npm install  # First time only
npm start
# Output should show: 
#   ✅ MongoDB connected
#   ✅ Server listening on port 5000
```

#### Terminal 4: ngrok Tunnel
```bash
ngrok http 5000
# Output will show: https://xxx-xxx-xxx.ngrok-free.dev
# Copy the HTTPS URL for ESP32 configuration
```

#### Terminal 5: Frontend (optional)
```bash
cd frontend
npm install  # First time only
npm start
# Opens http://localhost:3000
```

---

## 2. ESP32 CONFIGURATION

### Serial Port Setup
- **Baud Rate**: 115200
- **Data Bits**: 8
- **Stop Bits**: 1
- **Parity**: None
- **Flow Control**: None

### esp32/esp32_code.ino Configuration
```cpp
// Update these values:

// WiFi Credentials (network you're using)
#define WIFI_SSID "[YOUR_WIFI_SSID]"
#define WIFI_PASSWORD "[YOUR_WIFI_PASSWORD]"

// Server Configuration (from ngrok output)
const char serverIP[] = "symphony-shady-selection.ngrok-free.dev";  // UPDATE THIS
const int serverPort = 443;  // HTTPS port
const char* backendEndpoint = "/api/bus/upload";

// Bus Identification
#define BUS_ID "BUS-001"
#define ROUTE_ID "ROUTE-01"

// Timing (30 seconds = 1 upload per 30 sec)
const unsigned long UPLOAD_INTERVAL = 30000;

// Camera Configuration
config.frame_size = FRAMESIZE_QVGA;  // 320x240
config.jpeg_quality = 12;  // 1-63, lower = smaller file

// GPS Pins (NEO-6M)
#define GPS_RX 15
#define GPS_TX 16

// SIM800L Pins (currently disabled)
#define SIM800_TX 13
#define SIM800_RX 14
```

### Arduino IDE Setup
1. **Board Manager**: Search "esp32", install "esp32 by Espressif Systems"
2. **Board Selection**: Tools → Board → AI Thinker ESP32-CAM
3. **Port**: Tools → Port → COMx
4. **Upload Speed**: 921600 or 115200
5. **Required Libraries**:
   - esp_camera (built-in)
   - TinyGPS++ (search "TinyGPS" by Mikal Hart)
   - ArduinoJson (search "ArduinoJson" by Benoit Blanchon)
   - WiFi (built-in)

### Flashing Commands (if CLI needed)
```bash
# Using esptool.py
python -m esptool --chip esp32 --port COM3 --baud 921600 write_flash -z 0x1000 firmware.bin
```

---

## 3. FRONTEND CONFIGURATION

### .env File (frontend/.env)
```env
REACT_APP_API_BASE_URL=http://localhost:5000
REACT_APP_ENVIRONMENT=development
```

### Build and Serve
```bash
# Development
npm start
# http://localhost:3000

# Production Build
npm run build
# Produces optimized build/ folder
```

---

## 4. DATABASE SETUP

### MongoDB Local Installation

#### Windows
```bash
# Download from https://www.mongodb.com/try/download/community
# Run installer, keep defaults
# MongoDB starts as service

# Verify running
mongosh
```

#### macOS
```bash
brew tap mongodb/brew
brew install mongodb-community
brew services start mongodb-community
```

#### Linux (Ubuntu/Debian)
```bash
sudo apt-get install -y mongodb
sudo systemctl start mongodb
```

### MongoDB Atlas (Cloud)

1. Go to https://www.mongodb.com/cloud/atlas
2. Create free cluster
3. Get connection string: `mongodb://localhost:27017/iubat_bus_tracking`
4. Add to backend/.env: `MONGO_URI=mongodb://localhost:27017/iubat_bus_tracking`

### Initial Database Setup

```javascript
// Connect with MongoDB Compass or mongosh

use iubat_bus_tracking

// Create collections (auto-created on first insert, or explicit):
db.createCollection('busdatas')
db.createCollection('buses')
db.createCollection('locations')
db.createCollection('busexperimentlogs')

// Create indexes
db.busdatas.createIndex({ busId: 1, createdAt: -1 })
db.buses.createIndex({ busId: 1 })
db.locations.createIndex({ busId: 1, timestamp: -1 })

// Verify
db.getCollectionNames()
// Output: ['busdatas', 'buses', 'locations', 'busexperimentlogs', ...]
```

---

## 5. PYTHON/YOLO SETUP

### Python Environment Setup

```bash
# Windows
python -m venv yolo_env
yolo_env\Scripts\activate

# macOS/Linux
python3 -m venv yolo_env
source yolo_env/bin/activate
```

### Install YOLO Dependencies

```bash
# Install from requirements.txt
pip install -r backend/yolo_server/requirements.txt

# OR manually:
pip install opencv-python
pip install flask
pip install flask-cors
pip install ultralytics
pip install torch torchvision torchaudio
```

### Verify YOLO Installation

```bash
python -c "from ultralytics import YOLO; model = YOLO('yolov8n.pt'); print('✅ YOLO loaded')"
```

### Run YOLO Server

```bash
cd backend/yolo_server
python yolo_server.py
# Should output: Running on http://0.0.0.0:5001
# Can access at http://localhost:5001
```

---

## 6. NGROK CONFIGURATION

### Installation

```bash
# Download from https://ngrok.com/download
# Extract and add to PATH

# Verify
ngrok version
```

### Authentication

```bash
ngrok config add-authtoken YOUR_TOKEN_HERE
# Get token from https://dashboard.ngrok.com/auth
```

### Start Tunnel

```bash
ngrok http 5000
# Output:
# Forwarding https://xxx-xxx-xxx.ngrok-free.dev -> http://localhost:5000
# Forwarding http://xxx-xxx-xxx.ngrok-free.dev -> http://localhost:5000

# COPY THE HTTPS URL and update ESP32 code!
```

### Keep ngrok Active

- ngrok free tier requires dashboard to be active
- Session timeout after 8 hours
- To make permanent: ngrok pro ($12/month) or use Cloudflare Tunnel (free)

---

## 7. COMPLETE STARTUP SEQUENCE

### First Time Only
```bash
# 1. Install Node dependencies
cd backend
npm install
cd ../frontend
npm install

# 2. Install Python dependencies
cd ../backend/yolo_server
pip install -r requirements.txt

# 3. Set up MongoDB (local or Atlas)
# 4. Create .env files (see section 1)
# 5. Upload esp32_code.ino to board
```

### Every Time You Want to Run

#### Minimal Setup (WiFi only, no frontend)
```
Terminal 1: mongod (or skip if using Atlas)
Terminal 2: cd backend && npm start
Terminal 3: cd backend/yolo_server && python yolo_server.py
Terminal 4: ngrok http 5000
Terminal 5: Copy ngrok HTTPS URL → update esp32_code.ino → upload
Terminal 6: Open serial monitor → watch logs
```

#### Full Setup (with frontend)
```
Terminal 1: mongod
Terminal 2: cd backend && npm start
Terminal 3: cd backend/yolo_server && python yolo_server.py
Terminal 4: ngrok http 5000
Terminal 5: cd frontend && npm start
Terminal 6: ESP32 serial monitor
```

---

## 8. TROUBLESHOOTING STARTUP

| Issue | Solution |
|-------|----------|
| MongoDB connection refused | Check if `mongod` is running, or update MONGO_URI |
| Port 5000 already in use | `netstat -ano \| findstr :5000` (Windows) → kill process |
| YOLO model download fails | Check internet, or `pip install --upgrade ultralytics` |
| ngrok shows "connection refused" | Verify backend is running on :5000 |
| ESP32 can't find "[YOUR_WIFI_SSID]" WiFi | Check SSID spelling, check WiFi network is broadcasting |
| ESP32 HTTPS connection fails | Verify ngrok URL in code, use HTTPS URL not HTTP |
| React shows CORS errors | Check backend has `app.use(cors())` enabled |
| MongoDB data not persisting | Check write permissions on data directory |

---

## 9. QUICK HEALTH CHECK

### Run this after startup to verify everything is connected:

```bash
# Check Backend
curl http://localhost:5000/api/bus/data
# Should return: {"success":true,"data":[...]}

# Check YOLO Server
curl http://localhost:5001
# Should return: Flask app or endpoint info

# Check MongoDB
mongosh
> use iubat_bus_tracking
> db.buses.countDocuments()
# Should return: 0 or more

# Check ngrok
# Visit https://dashboard.ngrok.com → should show active tunnel

# Check ESP32
# Serial monitor should show WiFi connection and GPS fix within 30 seconds
```

---

## 10. PRODUCTION DEPLOYMENT

### Option A: Local Server Only (Test Environment)
- Keep all services running on localhost
- Use ngrok for external access (or Cloudflare Tunnel)
- Update DNS to point to tunnel

### Option B: VPS/Cloud Server
- Deploy backend to AWS/GCP/DigitalOcean
- Deploy YOLO to same or different server
- Use MongoDB Atlas (cloud)
- Remove ngrok, use direct IP/domain

### Option C: Docker Containerization
```dockerfile
# backend/Dockerfile
FROM node:18
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
EXPOSE 5000
CMD ["npm", "start"]
```

```bash
docker build -t iubat-backend .
docker run -p 5000:5000 -e MONGO_URI=... iubat-backend
```

---

## 📋 CONFIGURATION CHECKLIST

- [ ] MongoDB running or Atlas connected
- [ ] Backend npm dependencies installed
- [ ] YOLO Python environment set up
- [ ] YOLO dependencies installed
- [ ] Backend .env file created with MONGO_URI
- [ ] YOLO server starts without errors
- [ ] ngrok tunnel active with HTTPS URL
- [ ] ESP32 arduino.ino updated with ngrok URL
- [ ] ESP32 code uploaded successfully
- [ ] Serial monitor shows "[YOUR_WIFI_SSID]" and "[YOUR_WIFI_PASSWORD]"
- [ ] First upload completes with HTTP 200
- [ ] MongoDB contains BusData and Bus documents
- [ ] Frontend loads and shows bus tracking
- [ ] React displays real passenger count (not hardcoded)

Once all checked ✓, system is ready for testing!
