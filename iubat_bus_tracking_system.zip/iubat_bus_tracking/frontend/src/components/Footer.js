import "./Footer.css";

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-brand">IUBAT Bus Tracking System</div>
      <div className="footer-dept">Department of CSE</div>
      <div className="footer-university">IUBAT</div>

      <div className="footer-developed">
        <span>Developed By:</span>
        <span>Rashedul Hasan Srabon</span>
        <span>Sabbir Hossain</span>
      </div>

      <div className="footer-email">Email: rhsrabon19@email.com</div>
      <div className="footer-copy">© 2026 All Rights Reserved</div>
    </footer>
  );
}

export default Footer;
