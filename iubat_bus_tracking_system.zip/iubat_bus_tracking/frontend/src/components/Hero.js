function Hero() {
  return (
    <div style={{
      backgroundImage: `linear-gradient(rgba(207, 216, 221, 0.85), rgba(161, 197, 201, 0.85)), url(${process.env.PUBLIC_URL + "/bus.jpg"})`,
      backgroundSize: "cover",
      backgroundPosition: "center",
      height: "80vh",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      color: "#093C5D",
      textAlign: "center"
    }}>
      <h1 style={{ fontSize: "3rem", margin: "0" }}>
        Welcome to IUBAT Bus Transport
      </h1>
      <p>Your reliable journey, just a tap away!</p>
    </div>
  );
}

export default Hero;