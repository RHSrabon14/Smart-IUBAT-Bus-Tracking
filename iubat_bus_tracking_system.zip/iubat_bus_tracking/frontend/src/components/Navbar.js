import { Link, useNavigate } from "react-router-dom";
import { isAuthenticated, logout } from "../utils/auth";
import "./Navbar.css";

function Navbar() {
  const navigate = useNavigate();
  const loggedIn = isAuthenticated();

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  const adminToken = localStorage.getItem("adminToken");

  return (
    <div className="navbar">

      <div className="nav-left">
        <img src="/iubat.png" alt="IUBAT" />
        <h2>
          IUBAT - INTERNATIONAL UNIVERSITY OF BUSINESS AGRICULTURE AND TECHNOLOGY
        </h2>
      </div>

      <div className="nav-links">
        <Link to="/" className="nav-button">Home</Link>
        <Link to="/schedule" className="nav-button">Schedules</Link>
        <Link to="/shuttle" className="nav-button">Shuttle Routes</Link>
        {adminToken ? (
          <Link to="/admin-dashboard" className="nav-button admin-button">
            Admin Panel
          </Link>
        ) : (
          <Link to="/admin-login" className="nav-button admin-button">
            Admin Panel
          </Link>
        )}
        {loggedIn ? (
          <button className="nav-button logout-button" onClick={handleLogout}>
            Logout
          </button>
        ) : (
          <Link to="/login-choice" className="nav-button">Login</Link>
        )}
      </div>

    </div>
  );
}

export default Navbar;