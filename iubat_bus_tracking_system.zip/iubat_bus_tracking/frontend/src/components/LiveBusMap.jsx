import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from "react-leaflet";
import L from "leaflet";
import axios from "axios";
import "leaflet/dist/leaflet.css";
import { API_BASE_URL } from "../utils/api";

const defaultCenter = [23.7937, 90.4066];

delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require("leaflet/dist/images/marker-icon-2x.png"),
  iconUrl: require("leaflet/dist/images/marker-icon.png"),
  shadowUrl: require("leaflet/dist/images/marker-shadow.png"),
});

const LiveBusMap = ({ busId, title = "Live Bus Tracking", subtitle = "Real-time GPS" }) => {
  const [locationData, setLocationData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchLiveLocation = async () => {
      if (!busId) {
        setLocationData(null);
        return;
      }

      try {
        setLoading(true);
        const response = await axios.get(`${API_BASE_URL}/api/location/${busId}`);
        const busData = response.data?.data;

        if (busData?.currentLocation?.latitude != null && busData?.currentLocation?.longitude != null) {
          setLocationData(busData);
          setError(null);
        } else {
          setLocationData(null);
          setError("Live location not available yet.");
        }
      } catch (err) {
        setLocationData(null);
        setError("Unable to load GPS data. Please check the backend.");
      } finally {
        setLoading(false);
      }
    };

    fetchLiveLocation();
    const interval = setInterval(fetchLiveLocation, 5000);
    return () => clearInterval(interval);
  }, [busId]);

  const renderContent = () => {
    if (!busId) {
      return (
        <div style={styles.emptyState}>
          <h3>Select a route or shuttle to begin live tracking.</h3>
        </div>
      );
    }

    if (loading && !locationData) {
      return (
        <div style={styles.emptyState}>
          <p>Loading live GPS data...</p>
        </div>
      );
    }

    if (error && !locationData) {
      return (
        <div style={styles.emptyState}>
          <p>{error}</p>
        </div>
      );
    }

    const coordinates = locationData?.currentLocation;
    const formattedTime = coordinates?.timestamp ? new Date(coordinates.timestamp).toLocaleString() : "N/A";

    return (
      <MapContainer
        center={coordinates ? [coordinates.latitude, coordinates.longitude] : defaultCenter}
        zoom={coordinates ? 15 : 13}
        scrollWheelZoom={false}
        style={styles.mapContainer}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />

        {coordinates && (
          <>
            <Marker position={[coordinates.latitude, coordinates.longitude]}>
              <Popup>
                <div style={{ minWidth: 210 }}>
                  <strong>{title}</strong>
                  <p style={{ margin: "4px 0" }}>{subtitle}</p>
                  <p><strong>Bus ID:</strong> {locationData.busId || busId || "N/A"}</p>
                  <p><strong>Route:</strong> {locationData.routeName || title || "N/A"}</p>
                  <p><strong>Passengers:</strong> {locationData.currentPassengerCount ?? "N/A"}</p>
                  <p><strong>Speed:</strong> {locationData.currentSpeed ?? "N/A"} km/h</p>
                  <p><strong>Satellites:</strong> {locationData.satellites ?? "N/A"}</p>
                  <p><strong>GPS Fixed:</strong> {locationData.gpsFixed ? "YES" : "NO"}</p>
                  <p><strong>Last Updated:</strong> {formattedTime}</p>
                </div>
              </Popup>
            </Marker>
            <CircleMarker
              center={[coordinates.latitude, coordinates.longitude]}
              radius={22}
              pathOptions={{ color: "#1F8EF1", fillColor: "#1F8EF1", fillOpacity: 0.2 }}
            />
          </>
        )}
      </MapContainer>
    );
  };

  return (
    <div style={styles.card}>
      <div style={styles.heading}>
        <div>
          <p style={styles.mapLabel}>{subtitle}</p>
          <h3 style={styles.mapTitle}>{title}</h3>
        </div>
        <span style={styles.statusBadge}>{busId ? "Live GPS" : "Idle"}</span>
      </div>
      <div style={styles.mapWrapper}>{renderContent()}</div>
      {locationData?.currentLocation && (
        <div style={styles.locationFooter}>
          <span>
            <strong>Bus ID:</strong> {locationData.busId || busId || "N/A"}
          </span>
          <span>
            <strong>Route:</strong> {locationData.routeName || title || "N/A"}
          </span>
          <span>
            <strong>Latitude:</strong> {locationData.currentLocation.latitude.toFixed(6)}
          </span>
          <span>
            <strong>Longitude:</strong> {locationData.currentLocation.longitude.toFixed(6)}
          </span>
          <span>
            <strong>Passengers:</strong> {locationData.currentPassengerCount ?? "N/A"}
          </span>
          <span>
            <strong>Speed:</strong> {locationData.currentSpeed ?? "N/A"} km/h
          </span>
          <span>
            <strong>Satellites:</strong> {locationData.satellites ?? "N/A"}
          </span>
          <span>
            <strong>GPS Fixed:</strong> {locationData.gpsFixed ? "YES" : "NO"}
          </span>
          <span>
            <strong>Last updated:</strong> {locationData.currentLocation.timestamp ? new Date(locationData.currentLocation.timestamp).toLocaleString() : "N/A"}
          </span>
        </div>
      )}
    </div>
  );
};

const styles = {
  card: {
    width: "100%",
    borderRadius: "22px",
    background: "#ffffff",
    padding: "18px",
    boxShadow: "0 18px 40px rgba(31, 142, 241, 0.08)",
    border: "1px solid #edf4ff",
  },
  heading: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: "16px",
    gap: "12px",
  },
  mapLabel: {
    margin: 0,
    fontSize: "0.85rem",
    color: "#1f8ef1",
    fontWeight: 700,
    letterSpacing: "0.04em",
  },
  mapTitle: {
    margin: "6px 0 0",
    fontSize: "1.35rem",
    color: "#10284d",
  },
  statusBadge: {
    backgroundColor: "#e9f4ff",
    color: "#1f6ccb",
    padding: "10px 14px",
    borderRadius: "999px",
    fontWeight: 700,
    fontSize: "0.85rem",
  },
  mapWrapper: {
    width: "100%",
    minHeight: "360px",
    borderRadius: "18px",
    overflow: "hidden",
    background: "#f6f9ff",
  },
  mapContainer: {
    height: "100%",
    width: "100%",
    minHeight: "360px",
  },
  emptyState: {
    height: "360px",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    padding: "24px",
    textAlign: "center",
    color: "#345069",
  },
  locationFooter: {
    marginTop: "16px",
    display: "flex",
    flexWrap: "wrap",
    gap: "12px",
    color: "#4b5f78",
    fontSize: "0.95rem",
    justifyContent: "space-between",
  },
};

export default LiveBusMap;
