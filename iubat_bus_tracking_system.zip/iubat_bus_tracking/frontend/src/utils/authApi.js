import axios from "axios";
import { API_BASE_URL } from "./api";

const client = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export async function forgotPassword(role, identifier) {
  const response = await client.post("/auth/forgot-password", { role, identifier });
  return response.data;
}

export async function resetPassword(role, identifier, otp, password) {
  const response = await client.post("/auth/reset-password", { role, identifier, otp, password });
  return response.data;
}
