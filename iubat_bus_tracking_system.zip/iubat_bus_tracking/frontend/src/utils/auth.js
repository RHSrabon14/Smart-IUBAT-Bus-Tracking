export const isAuthenticated = () => {
  return localStorage.getItem("isLoggedIn") === "true";
};

export const login = () => {
  localStorage.setItem("isLoggedIn", "true");
};

export const logout = () => {
  localStorage.removeItem("isLoggedIn");
  localStorage.removeItem("student");
  localStorage.removeItem("faculty");
  localStorage.removeItem("route");
  localStorage.removeItem("shuttleRoute");
};
