import { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { login, isAuthenticated } from "../utils/auth";
import "./Login.css";

function StudentLogin() {
  const [studentId, setStudentId] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/route-select";

  useEffect(() => {
    if (isAuthenticated()) {
      navigate("/route-select", { replace: true });
    }
  }, [navigate]);

  const handleLogin = () => {
    // Check empty
    if (!studentId || !password) {
      alert("Please fill all fields");
      return;
    }

    // Check ID format
    if (!/^\d{8}$/.test(studentId)) {
      alert("Invalid Student ID");
      return;
    }

    // Password rule
    const expectedPassword = `${studentId}@iubat.edu`;

    // Login check: accept any valid student ID with the matching password
    if (password === expectedPassword) {
      alert("Login Successful ✅");
      localStorage.setItem("student", studentId);
      login();
      navigate(from, { replace: true });

    } else {
      alert("Invalid credentials ❌");
    }
  };

  return (
    <div className="login-container">

      <div className="login-card">

        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <img 
            src="/iubat.png" 
            alt="IUBAT Logo" 
            style={{ height: "60px", marginBottom: "10px" }} 
          />
          <p style={{ fontSize: "14px", color: "#093C5D", fontWeight: "bold", margin: "0" }}>
            IUBAT- INTERNATIONAL UNIVERSITY OF BUSINESS AGRICULTURE AND TECHNOLOGY
          </p>
        </div>

        <h2>🎓 Student Login</h2>

        <input
          type="text"
          placeholder="Student ID"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <Link to="/forgot-password?role=student" className="forgot-link">
          Forgot Password?
        </Link>

        <button onClick={handleLogin}>Sign In</button>

      </div>

    </div>
  );
}

export default StudentLogin;