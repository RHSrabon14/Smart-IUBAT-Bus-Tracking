import { useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { isAuthenticated } from "../utils/auth";
import "./Login.css";

function LoginChoice() {
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || { pathname: "/" };

  useEffect(() => {
    if (isAuthenticated()) {
      navigate("/route-select", { replace: true });
    }
  }, [navigate]);

  return (
    <div className="login-container">
      <div className="login-card">
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <img
            src="/iubat.png"
            alt="IUBAT Logo"
            style={{ height: "60px", marginBottom: "10px" }}
          />
          <p style={{ fontSize: "14px", color: "#093C5D", fontWeight: "bold", margin: "0" }}>
            Choose your login type to continue
          </p>
        </div>

        <h2>Login Portal</h2>
        <p style={{ marginBottom: "20px", color: "#555" }}>
          You need to sign in to continue to <strong>{from.pathname}</strong>.
        </p>

        <div style={{ display: "grid", gap: "12px" }}>
          <button
            onClick={() => navigate("/student-login", { state: { from } })}
          >
            Student Login
          </button>
          <button
            onClick={() => navigate("/faculty-login", { state: { from } })}
          >
            Faculty Login
          </button>
        </div>
      </div>
    </div>
  );
}

export default LoginChoice;
