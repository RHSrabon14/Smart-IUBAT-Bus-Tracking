import React, { useEffect, useState } from "react";
import axios from "axios";
import { API_BASE_URL } from "../utils/api";

function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchAlerts();
  }, []);

  const fetchAlerts = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/transport/alerts`);
      const data = response.data.data || response.data;
      setAlerts(Array.isArray(data) ? data : []);
    } catch (err) {
      setError("Unable to load alerts. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.title}>Alerts</h1>
        <p style={styles.subtitle}>Latest transport updates and important notices</p>
        {loading && <div style={styles.status}>Loading alerts...</div>}
        {error && <div style={styles.statusError}>{error}</div>}
        <div style={styles.list}>
          {alerts.length === 0 && !loading ? (
            <div style={styles.emptyMessage}>No alerts are available at the moment.</div>
          ) : (
            alerts.map((alert) => (
              <div key={alert._id || alert.id} style={styles.card}>
                <div style={styles.topRow}>
                  <span style={styles.badge}>{alert.type || "Alert"}</span>
                  <span style={styles.time}>{new Date(alert.createdAt || Date.now()).toLocaleString()}</span>
                </div>
                <h3 style={styles.cardTitle}>{alert.title || alert.message || "New Alert"}</h3>
                <p style={styles.message}>{alert.message || alert.description || "No details available."}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#eef5ff",
    padding: "40px 16px",
  },
  container: {
    maxWidth: "980px",
    margin: "0 auto",
    background: "#fff",
    borderRadius: "18px",
    padding: "32px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
  },
  title: {
    margin: 0,
    fontSize: "2rem",
    color: "#10284d",
  },
  subtitle: {
    margin: "8px 0 24px",
    color: "#5d6b83",
  },
  list: {
    display: "flex",
    flexDirection: "column",
    gap: "16px",
  },
  card: {
    border: "1px solid #e3ecff",
    borderRadius: "14px",
    padding: "18px",
    background: "#f9fbff",
  },
  topRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
  },
  badge: {
    background: "#e8f3ff",
    color: "#1a73e8",
    padding: "6px 10px",
    borderRadius: "999px",
    fontSize: "0.85rem",
    fontWeight: 700,
  },
  time: {
    color: "#6a7a91",
    fontSize: "0.9rem",
  },
  cardTitle: {
    margin: "12px 0 8px",
    color: "#10284d",
  },
  message: {
    margin: 0,
    color: "#4a5a73",
  },
  status: {
    marginBottom: "16px",
    color: "#10284d",
  },
  statusError: {
    marginBottom: "16px",
    color: "#c33",
  },
  emptyMessage: {
    color: "#4a5a73",
    padding: "16px",
    background: "#f2f7ff",
    borderRadius: "12px",
  },
};


export default Alerts;
