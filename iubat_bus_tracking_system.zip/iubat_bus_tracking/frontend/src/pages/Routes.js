import { useEffect, useState } from "react";
import axios from "axios";
import "./Routes.css";
import { API_BASE_URL } from "../utils/api";

function RoutesPage() {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchRoutes();
    const interval = setInterval(fetchRoutes, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchRoutes = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/routes/evening`);
      const data = response.data.data || response.data;
      setRoutes(Array.isArray(data) ? data.filter((route) => route.routeType !== "shuttle") : []);
    } catch (err) {
      setError("Unable to load route information. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="routes-page">
      <div className="routes-header">
        <p className="routes-label">Today's Route Schedule</p>
        <h1>🚌 Route Information</h1>
        <p className="routes-time">Evening Routes</p>
        <p className="routes-intro">All route data is served from MongoDB and managed by admin.</p>
      </div>

      {loading ? (
        <div className="routes-status">Loading route data...</div>
      ) : error ? (
        <div className="routes-status error">{error}</div>
      ) : (
        <section className="routes-card">
          <h2>All Routes</h2>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Bus No</th>
                  <th>Route Name</th>
                  <th>Time</th>
                  <th>Destination</th>
                </tr>
              </thead>
              <tbody>
                {routes.length === 0 ? (
                  <tr>
                    <td colSpan="3">No routes available yet.</td>
                  </tr>
                ) : (
                  routes.map((route) => (
                    <tr key={route._id}>
                      <td>{route.busNo}</td>
                      <td>{route.routeName}</td>
                      <td>{route.time}</td>
                      <td>{route.destination || "Destination"}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

export default RoutesPage;