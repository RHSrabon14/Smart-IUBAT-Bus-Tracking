import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import axios from 'axios';
import 'leaflet/dist/leaflet.css';
import { API_BASE_URL } from '../utils/api';

// Fix for default markers in react-leaflet
import L from 'leaflet';
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
  iconUrl: require('leaflet/dist/images/marker-icon.png'),
  shadowUrl: require('leaflet/dist/images/marker-shadow.png'),
});

const MapPage = () => {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // IUBAT coordinates (approximate)
  const iubPosition = [23.7937, 90.4066];

  useEffect(() => {
    fetchBusLocations();
    const interval = setInterval(fetchBusLocations, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchBusLocations = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/api/location/all`);
      setBuses(response.data.data || []);
      setError(null);
    } catch (err) {
      setError('Failed to fetch live bus locations.');
      console.error('Error fetching bus locations:', err);
    } finally {
      setLoading(false);
    }
  };

  const BusMarker = ({ bus }) => {
    if (!bus.currentLocation?.latitude || !bus.currentLocation?.longitude) {
      return null;
    }

    return (
      <Marker
        position={[bus.currentLocation.latitude, bus.currentLocation.longitude]}
        key={bus.busId}
      >
        <Popup>
          <div>
            <h3>Bus {bus.busNumber || bus.busId}</h3>
            <p><strong>Bus ID:</strong> {bus.busId}</p>
            <p><strong>Status:</strong> {bus.status || 'active'}</p>
            <p><strong>Last Update:</strong> {bus.currentLocation.timestamp ? new Date(bus.currentLocation.timestamp).toLocaleString() : 'N/A'}</p>
            <p><strong>Coordinates:</strong> {bus.currentLocation.latitude.toFixed(6)}, {bus.currentLocation.longitude.toFixed(6)}</p>
          </div>
        </Popup>
      </Marker>
    );
  };

  return (
    <div className="map-page">
      <div className="container">
        <h1 className="page-title">Live Bus Tracking</h1>

        {error && (
          <div className="error-message" style={{
            backgroundColor: '#fee',
            color: '#c33',
            padding: '10px',
            borderRadius: '5px',
            marginBottom: '20px'
          }}>
            {error}
          </div>
        )}

        <div className="map-container" style={{ height: '600px', width: '100%' }}>
          {loading ? (
            <div style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              height: '100%',
              backgroundColor: '#f5f5f5'
            }}>
              <div>Loading map...</div>
            </div>
          ) : (
            <MapContainer
              center={iubPosition}
              zoom={15}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />

              {buses.map(bus => (
                <BusMarker key={bus.busId} bus={bus} />
              ))}
            </MapContainer>
          )}
        </div>

        <div className="bus-list" style={{ marginTop: '20px' }}>
          <h2>Active Buses</h2>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '10px' }}>
            {buses.filter(bus => bus.currentLocation).map(bus => (
              <div key={bus.busId} style={{
                border: '1px solid #ddd',
                borderRadius: '5px',
                padding: '10px',
                backgroundColor: '#f9f9f9'
              }}>
                <h3>Bus {bus.busNumber || bus.busId}</h3>
                <p><strong>ID:</strong> {bus.busId}</p>
                <p><strong>Status:</strong> {bus.status || 'active'}</p>
                <p><strong>Last Seen:</strong> {bus.currentLocation.timestamp ? new Date(bus.currentLocation.timestamp).toLocaleTimeString() : 'N/A'}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapPage;