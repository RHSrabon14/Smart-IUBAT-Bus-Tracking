import { useState, useEffect, useCallback } from "react";
import axios from "axios";
import LiveBusMap from "../components/LiveBusMap";
import { API_BASE_URL } from "../utils/api";

function ShuttleRouteTracking({ category = "Shuttle" }) {
  const [shuttles, setShuttles] = useState([]);
  const [selectedShuttle, setSelectedShuttle] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [etaSummary, setEtaSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const resolveShuttleBusId = (shuttle) => {
    return shuttle?.busId ? String(shuttle.busId).trim() : "";
  };

  useEffect(() => {
    if (!selectedShuttle) {
      setSelectedLocation(null);
      return;
    }

    const busId = resolveShuttleBusId(selectedShuttle);
    const fetchLocation = async () => {
      try {
        if (!busId) {
          setSelectedLocation(null);
          setEtaSummary(null);
          return;
        }
        const response = await axios.get(`${API_BASE_URL}/api/location/${busId}`);
        setSelectedLocation(response.data.data);
        setEtaSummary(response.data.data?.eta || null);
      } catch (err) {
        setSelectedLocation(null);
        setEtaSummary(null);
      }
    };

    fetchLocation();
    const interval = setInterval(fetchLocation, 5000);
    return () => clearInterval(interval);
  }, [selectedShuttle]);

  const fetchShuttleRoutes = useCallback(async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/transport/buses-by-schedule?schedule=${category}`);
      const categoryBuses = (response.data.data || [])
        .filter((bus) => bus.status !== "inactive")
        .map((bus) => ({
          _id: bus._id,
          busId: bus.busId,
          busNumber: bus.busNumber,
          routeName: bus.routeName || bus.route?.routeName || bus.routeId?.routeName || "Route not assigned",
          time: bus.departureTime || bus.route?.time || bus.routeId?.time || "Not Fixed",
          capacity: bus.capacity,
          destination: bus.route?.destination || bus.routeId?.destination || "",
        }));
      setShuttles(categoryBuses);
      setError("");
      setLoading(false);
    } catch (err) {
      setError("Unable to load shuttle routes. Please try again.");
      setLoading(false);
    }
  }, [category]);

  useEffect(() => {
    setSelectedShuttle(null);
    setSelectedLocation(null);
    setLoading(true);
    fetchShuttleRoutes();
  }, [category, fetchShuttleRoutes]);

  const filteredShuttles = shuttles.filter((shuttle) =>
    shuttle.routeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    shuttle.busNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
    shuttle.busId.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleShuttleSelect = (shuttle) => {
    setSelectedShuttle(shuttle);
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <img src="/iubat.png" alt="IUBAT Logo" style={styles.logo} />
          <div>
            <p style={styles.subtitle}>IUBAT Bus Tracking</p>
            <h1 style={styles.title}>{category} Bus Tracking</h1>
            <p style={styles.description}>
              Track {category.toLowerCase()} buses in real-time and view live location updates.
            </p>
          </div>
        </div>

        <div style={styles.searchContainer}>
          <input
            type="text"
              placeholder={`Search ${category.toLowerCase()} buses...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={styles.searchInput}
          />
        </div>

        <div style={styles.mainContent}>
          <div style={styles.routesSection}>
            <div style={styles.routesHeader}>
              <h2 style={styles.sectionTitle}>{category} Buses</h2>
              <p style={styles.sectionInfo}>Select a bus to see live tracking details.</p>
              {loading && <p>Loading {category.toLowerCase()} buses...</p>}
              {error && <p style={{ color: "red" }}>{error}</p>}
              {!loading && !error && shuttles.length === 0 && <p>No {category.toLowerCase()} buses available today.</p>}
            </div>
            <div style={styles.routesGrid}>
              {filteredShuttles.map((shuttle) => (
                <button
                  key={shuttle._id}
                  onClick={() => handleShuttleSelect(shuttle)}
                  style={{
                    ...styles.routeCard,
                    borderColor:
                      selectedShuttle && selectedShuttle._id === shuttle._id
                        ? "#1F8EF1"
                        : "#e0e0e0",
                    backgroundColor:
                      selectedShuttle && selectedShuttle._id === shuttle._id
                        ? "#1F8EF1"
                        : "#ffffff",
                    color:
                      selectedShuttle && selectedShuttle._id === shuttle._id
                        ? "#ffffff"
                        : "#333333",
                    transform:
                      selectedShuttle && selectedShuttle._id === shuttle._id
                        ? "translateY(-4px)"
                        : "translateY(0)",
                  }}
                  onMouseEnter={(e) => {
                    if (!selectedShuttle || selectedShuttle._id !== shuttle._id) {
                      e.currentTarget.style.borderColor = "#a0c4f7";
                      e.currentTarget.style.transform = "translateY(-2px)";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (!selectedShuttle || selectedShuttle._id !== shuttle._id) {
                      e.currentTarget.style.borderColor = "#e0e0e0";
                      e.currentTarget.style.transform = "translateY(0)";
                    }
                  }}
                >
                  <span style={styles.busIcon}>🚌</span>
                  <div>
                    <div style={styles.busNumber}>{shuttle.busNumber}</div>
                    <small>Bus ID: {shuttle.busId}</small>
                    <span style={styles.routeName}>{shuttle.routeName}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div style={styles.sidePanel}>
            <div style={styles.mapCard}>
              <div style={styles.mapHeader}>
                <div>
                  <p style={styles.mapLabel}>Live Tracking</p>
                  <h3 style={styles.mapTitle}>GPS Preview</h3>
                </div>
                <span style={styles.mapBadge}>
                  {selectedShuttle ? selectedShuttle.busNumber : `No ${category.toLowerCase()} bus selected`}
                </span>
              </div>
              <div style={styles.mapBox}>
                {selectedShuttle ? (
                  <LiveBusMap
                    busId={resolveShuttleBusId(selectedShuttle)}
                    title={`${selectedShuttle.routeName}`}
                    subtitle={`Bus ID ${selectedShuttle.busId}`}
                  />
                ) : (
                  <div>
                    <p style={styles.mapPlaceholderTitle}>GPS map placeholder</p>
                    <p style={styles.mapPlaceholderText}>
                      Select a bus from the left panel to view live GPS tracking.
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div style={styles.detailsPanel}>
              <h3 style={styles.panelTitle}>{category} Bus Details</h3>
              <div style={styles.detailRow}>
                <span>Bus Number</span>
                <strong>{selectedShuttle ? selectedShuttle.busNumber : "Select a bus"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Bus ID</span>
                <strong>{selectedShuttle ? selectedShuttle.busId : "Select a bus"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Route</span>
                <strong>{selectedShuttle ? selectedShuttle.routeName : "Select a bus"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Departure Time</span>
                <strong>{selectedLocation?.departureTime || selectedShuttle?.time || "N/A"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Schedule</span>
                <strong>{category}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Destination</span>
                <strong>{selectedShuttle?.destination || "Not available"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Capacity</span>
                <strong>{selectedShuttle ? `${selectedShuttle.capacity || 0} seats` : "N/A"}</strong>
              </div>
            </div>

            <div style={styles.statusPanel}>
              <div style={styles.statusHeader}>
                <h3 style={styles.panelTitle}>Live Status</h3>
                <p style={styles.statusNote}>Real-time {category.toLowerCase()} bus tracking information</p>
              </div>
              <div style={styles.statusCard}>
                <div style={styles.statusItem}>
                  <span>Current Location</span>
                  <strong>
                    {selectedLocation?.currentLocation
                      ? `${selectedLocation.currentLocation.latitude.toFixed(4)}, ${selectedLocation.currentLocation.longitude.toFixed(4)}`
                      : selectedShuttle
                        ? `${selectedShuttle.routeName} area`
                      : "N/A"}
                  </strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Estimated Arrival</span>
                  <strong>{etaSummary?.estimatedArrivalTime || "N/A"}</strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Remaining Distance</span>
                  <strong>{etaSummary ? `${etaSummary.remainingDistanceKm} km` : "N/A"}</strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Remaining Time</span>
                  <strong>{etaSummary ? `${etaSummary.remainingTimeMinutes} min` : "N/A"}</strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Delay</span>
                  <strong>{etaSummary ? `${etaSummary.delayMinutes} min` : "N/A"}</strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Status</span>
                  <strong style={{ color: selectedLocation ? "#2e7d32" : "#999" }}>
                    {selectedLocation ? "Running" : "Waiting"}
                  </strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Last Update</span>
                  <strong>
                    {selectedLocation?.currentLocation?.timestamp
                      ? new Date(selectedLocation.currentLocation.timestamp).toLocaleTimeString()
                      : "N/A"}
                  </strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#eef4fb",
    padding: "24px",
  },
  container: {
    maxWidth: "1320px",
    margin: "0 auto",
    backgroundColor: "#ffffff",
    borderRadius: "24px",
    boxShadow: "0 20px 60px rgba(31, 142, 241, 0.12)",
    padding: "32px",
  },
  header: {
    display: "flex",
    alignItems: "center",
    gap: "20px",
    flexWrap: "wrap",
    marginBottom: "28px",
  },
  logo: {
    width: "90px",
    height: "90px",
    borderRadius: "18px",
    objectFit: "cover",
    border: "2px solid #1F8EF1",
    padding: "8px",
    backgroundColor: "#fff",
  },
  subtitle: {
    margin: 0,
    color: "#1F8EF1",
    fontWeight: 700,
    letterSpacing: "0.08em",
  },
  title: {
    margin: "8px 0 10px",
    fontSize: "2.6rem",
    color: "#162E4D",
  },
  description: {
    margin: 0,
    color: "#4d5c6e",
    maxWidth: "680px",
    lineHeight: 1.6,
  },
  searchContainer: {
    marginBottom: "28px",
    textAlign: "center",
  },
  searchInput: {
    width: "100%",
    maxWidth: "460px",
    padding: "14px 18px",
    borderRadius: "14px",
    border: "1px solid #d9e4f5",
    fontSize: "1rem",
    outline: "none",
    boxShadow: "0 6px 18px rgba(31, 142, 241, 0.08)",
    transition: "border-color 0.3s ease",
  },
  mainContent: {
    display: "grid",
    gridTemplateColumns: "1.05fr 1fr",
    gap: "28px",
    alignItems: "start",
  },
  routesSection: {
    backgroundColor: "#fbfcff",
    borderRadius: "20px",
    padding: "24px",
    boxShadow: "0 8px 30px rgba(31, 142, 241, 0.08)",
  },
  routesHeader: {
    marginBottom: "18px",
  },
  sectionTitle: {
    margin: 0,
    fontSize: "1.7rem",
    color: "#10284d",
  },
  sectionInfo: {
    margin: "10px 0 0",
    color: "#5f6c7b",
  },
  routesGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "16px",
  },
  routeCard: {
    border: "2px solid #e0e8f7",
    borderRadius: "18px",
    padding: "22px",
    cursor: "pointer",
    transition: "transform 0.25s ease, border-color 0.25s ease, background-color 0.25s ease",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
    minHeight: "120px",
    textAlign: "left",
    background: "#ffffff",
  },
  busIcon: {
    fontSize: "1.9rem",
    marginBottom: "12px",
  },
  busNumber: {
    fontSize: "1.2rem",
    fontWeight: 700,
    marginBottom: "4px",
  },
  routeName: {
    fontSize: "1rem",
    fontWeight: 500,
  },
  sidePanel: {
    display: "grid",
    gap: "22px",
  },
  mapCard: {
    backgroundColor: "#ffffff",
    borderRadius: "22px",
    padding: "22px",
    border: "1px solid #e8eff9",
    boxShadow: "0 14px 35px rgba(31, 142, 241, 0.08)",
  },
  mapHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: "12px",
    alignItems: "flex-start",
    marginBottom: "18px",
  },
  mapLabel: {
    margin: 0,
    fontSize: "0.95rem",
    color: "#1F8EF1",
    fontWeight: 700,
    letterSpacing: "0.04em",
    textTransform: "uppercase",
  },
  mapTitle: {
    margin: "6px 0 0",
    fontSize: "1.4rem",
    color: "#152840",
  },
  mapBadge: {
    backgroundColor: "#eaf5ff",
    color: "#1f6ccb",
    borderRadius: "999px",
    padding: "10px 14px",
    fontSize: "0.9rem",
    fontWeight: 700,
  },
  mapBox: {
    minHeight: "360px",
    borderRadius: "18px",
    backgroundColor: "#f4f8ff",
    border: "1px dashed #c8daf4",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    padding: "28px",
    color: "#243b5b",
  },
  mapPlaceholderTitle: {
    margin: 0,
    fontSize: "1.3rem",
    fontWeight: 700,
  },
  mapPlaceholderText: {
    margin: "10px 0 0",
    color: "#56677f",
  },
  detailsPanel: {
    backgroundColor: "#f7fbff",
    borderRadius: "22px",
    padding: "22px",
    border: "1px solid #e5effa",
  },
  statusPanel: {
    backgroundColor: "#ffffff",
    borderRadius: "22px",
    padding: "22px",
    border: "1px solid #e8eff9",
  },
  panelTitle: {
    margin: "0 0 14px",
    fontSize: "1.25rem",
    color: "#12243a",
  },
  detailRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: "24px",
    marginBottom: "18px",
    color: "#4d5c74",
  },
  statusHeader: {
    marginBottom: "16px",
  },
  statusNote: {
    margin: 0,
    color: "#6b7b92",
    fontSize: "0.95rem",
  },
  statusCard: {
    display: "grid",
    gap: "16px",
    backgroundColor: "#eef5ff",
    borderRadius: "18px",
    padding: "20px",
  },
  statusItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "16px",
    padding: "14px 18px",
    borderRadius: "16px",
    backgroundColor: "#ffffff",
    boxShadow: "0 2px 18px rgba(31, 142, 241, 0.08)",
    color: "#293c5f",
  },
};

export default ShuttleRouteTracking;
