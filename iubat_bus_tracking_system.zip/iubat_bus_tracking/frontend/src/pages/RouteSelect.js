import "./RouteSelect.css";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function RouteSelect() {
  const [selected, setSelected] = useState("");
  const navigate = useNavigate();

  const handleContinue = () => {
    if (!selected) {
      alert("Please select a route");
      return;
    }

    localStorage.setItem("route", selected);

    if (selected === "shuttle") navigate("/shuttle-routes");
    if (selected === "morning") navigate("/morning-routes");
    if (selected === "evening") navigate("/evening-routes");
  };

  return (
    <div className="route-container">

      <img src="/iubat.png" alt="logo" className="logo" />

      <h1>Select Your Route</h1>

      <p>
        By selecting your route, every day you will get update of bus location on your route.
      </p>
      <p><b>Note:</b> You can change your route at any time</p>

      <div className="route-options">

        <div
          className={`route-card ${selected === "all" ? "active" : ""}`}
          onClick={() => setSelected("all")}
        >
          🚌
          <h3>All Routes</h3>
        </div>

        <div
          className={`route-card ${selected === "shuttle" ? "active" : ""}`}
          onClick={() => setSelected("shuttle")}
        >
          🚌
          <h3>Shuttle Route</h3>
        </div>

      </div>

      {selected === "all" && (
        <div className="route-category-options">
          {["shuttle", "morning", "evening"].map((category) => (
            <button
              key={category}
              type="button"
              className={`route-category-button ${selected === category ? "active" : ""}`}
              onClick={() => setSelected(category)}
            >
              {category[0].toUpperCase() + category.slice(1)}
            </button>
          ))}
        </div>
      )}

      <button onClick={handleContinue} className="continue-btn">
        Continue
      </button>

    </div>
  );
}

export default RouteSelect;