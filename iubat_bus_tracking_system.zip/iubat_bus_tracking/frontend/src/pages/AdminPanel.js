import { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "./AdminPanel.css";
import { API_BASE_URL } from "../utils/api";
import LiveBusMap from "../components/LiveBusMap";

function AdminPanel() {
  const [, setRoutes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("dashboard");
  const [dashboardData, setDashboardData] = useState(null);
  const [buses, setBuses] = useState([]);
  const [drivers, setDrivers] = useState([]);
  const [liveTracking, setLiveTracking] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [maintenance, setMaintenance] = useState([]);
  const [performanceSummary, setPerformanceSummary] = useState(null);
  const [busForm, setBusForm] = useState({
    busId: "",
    busNumber: "",
    routeId: "",
    routeModel: "",
    routeName: "",
    capacity: "50",
    currentPassengerCount: "0",
    schedule: "Shuttle",
    departureTime: "07:30",
    gpsStatus: "Offline",
    cameraStatus: "Offline",
    runningStatus: "Stopped",
    status: "active",
  });
  const [editBusId, setEditBusId] = useState(null);
  const [driverForm, setDriverForm] = useState({
    driverId: "",
    name: "",
    phone: "",
    email: "",
    licenseNumber: "",
    licenseExpiryDate: "",
    address: "",
    emergencyContact: "",
    status: "Available",
  });
  const [editDriverId, setEditDriverId] = useState(null);
  const [assignForm, setAssignForm] = useState({ driverId: "", busId: "", scheduleType: "Morning Route", routeId: "", shift: "Morning" });
  const [alertForm, setAlertForm] = useState({ title: "", message: "", type: "Bus Delay", busId: "", route: "" });
  const [maintenanceForm, setMaintenanceForm] = useState({ busId: "", lastServiceDate: "", nextServiceDate: "", odometer: "", status: "Good", notes: "" });
  const [lostItems, setLostItems] = useState([]);
  const [foundItems, setFoundItems] = useState([]);
  const [selectedLostItem, setSelectedLostItem] = useState(null);
  const [selectedFoundItem, setSelectedFoundItem] = useState(null);
  const [foundForm, setFoundForm] = useState({
    itemName: "",
    category: "",
    description: "",
    busNumber: "",
    route: "",
    dateFound: "",
    phone: "",
    reportedBy: "Admin",
    image: null,
  });
  const [selectedBusId, setSelectedBusId] = useState("");
  const [statusMessage, setStatusMessage] = useState("");
  const navigate = useNavigate();

  const fetchRoutes = useCallback(async () => {
    try {
      const [morningRes, eveningRes, shuttleRes] = await Promise.all([
        axios.get(`${API_BASE_URL}/api/routes/morning`),
        axios.get(`${API_BASE_URL}/api/routes/evening`),
        axios.get(`${API_BASE_URL}/api/routes/shuttle`),
      ]);
      const formattedRoutes = [
        ...(morningRes.data.data || []).map((route) => ({ ...route, section: "Morning", type: route.routeType || "morning" })),
        ...(eveningRes.data.data || []).map((route) => ({ ...route, section: "Evening", type: route.routeType || "evening" })),
        ...(shuttleRes.data.data || []).map((route) => ({ ...route, section: "Shuttle", type: route.routeType || "shuttle" })),
      ];
      setRoutes(formattedRoutes);
    } catch (err) {
      setError("Unable to load routes. Please try again.");
    }
  }, []);

  const fetchTransportData = useCallback(async () => {
    try {
      const token = localStorage.getItem("adminToken");
      const config = {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      };
      const [dashboardRes, busesRes, driversRes, alertsRes, maintenanceRes, trackingRes, performanceRes] = await Promise.all([
        axios.get(`${API_BASE_URL}/api/admin/dashboard`, config),
        axios.get(`${API_BASE_URL}/api/admin/transport-buses`, config),
        axios.get(`${API_BASE_URL}/api/admin/drivers`, config),
        axios.get(`${API_BASE_URL}/api/admin/alerts`, config),
        axios.get(`${API_BASE_URL}/api/admin/maintenance`, config),
        axios.get(`${API_BASE_URL}/api/admin/live-tracking`, config),
        axios.get(`${API_BASE_URL}/api/performance/summary`),
      ]);
      setDashboardData(dashboardRes.data.data || null);
      setBuses(busesRes.data.data || []);
      setDrivers(driversRes.data.data || []);
      setAlerts(alertsRes.data.data || []);
      setMaintenance(maintenanceRes.data.data || []);
      setLiveTracking(trackingRes.data.data || []);
      setPerformanceSummary(performanceRes.data.data || null);
      if (!selectedBusId && (trackingRes.data.data || []).length) {
        setSelectedBusId(trackingRes.data.data[0].busId || trackingRes.data.data[0].busNumber || "");
      }
    } catch (err) {
      console.error(err);
      setError(err.response?.data?.message || "Unable to load dashboard data.");
    }
  }, [selectedBusId]);

  const fetchLostItems = useCallback(async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/lostitems`);
      setLostItems(response.data.data || []);
    } catch (err) {
      console.error(err);
    }
  }, []);

  const fetchFoundItems = useCallback(async () => {
    try {
      const token = localStorage.getItem("adminToken");
      const response = await axios.get(`${API_BASE_URL}/api/founditems`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setFoundItems(response.data.data || []);
    } catch (err) {
      console.error(err);
    }
  }, []);

  useEffect(() => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      navigate("/admin-login");
      return;
    }

    fetchRoutes();
    fetchLostItems();
    fetchFoundItems();
    fetchTransportData();

    const interval = setInterval(() => {
      fetchTransportData();
    }, 10000);

    return () => clearInterval(interval);
  }, [navigate, fetchRoutes, fetchLostItems, fetchFoundItems, fetchTransportData]);

  const handleDelete = async (id, type = "route") => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }

    if (!window.confirm("Delete this record permanently?")) {
      return;
    }

    try {
      const url = type === "lost"
        ? `${API_BASE_URL}/api/lostitems/${id}`
        : type === "found"
          ? `${API_BASE_URL}/api/founditems/${id}`
          : `${API_BASE_URL}/api/routes/${type === "shuttle" ? "shuttle" : type === "morning" ? "morning" : "evening"}/${id}`;
      await axios.delete(url, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (type === "route") fetchRoutes();
      if (type === "lost") fetchLostItems();
      if (type === "found") fetchFoundItems();
      setStatusMessage("Record deleted successfully.");
    } catch (err) {
      const msg = err.response?.data?.msg || "Unable to delete this record.";
      setError(msg);
      if (err.response?.status === 401 || err.response?.status === 403) {
        localStorage.removeItem("adminToken");
        localStorage.removeItem("admin");
        navigate("/admin-login");
      }
    }
  };

  const handleBusSubmit = async () => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }
    if (!busForm.busId || !busForm.busNumber || !busForm.routeName.trim()) {
      setError("Bus ID, Bus Number, and Route are required.");
      return;
    }

    setLoading(true);
    try {
      const config = {
        headers: { Authorization: `Bearer ${token}` },
      };
      const payload = {
        ...busForm,
        busId: busForm.busId.trim(),
        busNumber: busForm.busNumber.trim(),
        capacity: Number(busForm.capacity || 50),
        currentPassengerCount: Number(busForm.currentPassengerCount || 0),
      };
      const response = editBusId
        ? await axios.put(`${API_BASE_URL}/api/admin/buses/${editBusId}`, payload, config)
        : await axios.post(`${API_BASE_URL}/api/admin/buses`, payload, config);
      setStatusMessage(response.data?.message || "Bus saved successfully.");
      resetBusForm();
      fetchTransportData();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data?.error || "Unable to save bus.");
    } finally {
      setLoading(false);
    }
  };

  const resetBusForm = () => {
    setEditBusId(null);
    setBusForm({ busId: "", busNumber: "", routeId: "", routeModel: "", routeName: "", capacity: "50", currentPassengerCount: "0", schedule: "Shuttle", departureTime: "07:30", gpsStatus: "Offline", cameraStatus: "Offline", runningStatus: "Stopped", status: "active" });
  };

  const handleBusEdit = (bus) => {
    setEditBusId(bus._id);
    setBusForm({
      busId: bus.busId || "",
      busNumber: bus.busNumber || "",
      routeId: bus.routeId?._id || bus.routeId || "",
      routeModel: bus.routeModel || "",
      routeName: bus.routeName || bus.routeId?.routeName || "",
      capacity: String(bus.capacity || 50),
      currentPassengerCount: String(bus.currentPassengerCount || 0),
      schedule: bus.schedule || "Morning",
      departureTime: bus.departureTime || "07:30",
      gpsStatus: bus.gpsStatus || "Offline",
      cameraStatus: bus.cameraStatus || "Offline",
      runningStatus: bus.runningStatus || "Stopped",
      status: bus.status || "active",
    });
    setActiveTab("buses");
  };

  const handleBusToggle = async (bus) => {
    const token = localStorage.getItem("adminToken");
    try {
      const response = await axios.put(`${API_BASE_URL}/api/admin/buses/${bus._id}`, { status: bus.status === "active" ? "inactive" : "active" }, { headers: { Authorization: `Bearer ${token}` } });
      setStatusMessage(response.data?.message || "Bus status updated.");
      fetchTransportData();
    } catch (err) {
      setError("Unable to update bus status.");
    }
  };

  const handleBusDelete = async (busId) => {
    const token = localStorage.getItem("adminToken");
    try {
      const response = await axios.delete(`${API_BASE_URL}/api/admin/buses/${busId}`, { headers: { Authorization: `Bearer ${token}` } });
      setStatusMessage(response.data?.message || "Bus deleted.");
      fetchTransportData();
    } catch (err) {
      setError("Unable to delete bus.");
    }
  };

  const handleDriverSubmit = async () => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }
    if (!driverForm.driverId || !driverForm.name || !driverForm.phone) {
      setError("Driver ID, name, and phone are required.");
      return;
    }

    setLoading(true);
    try {
      const config = { headers: { Authorization: `Bearer ${token}` } };
      const payload = { ...driverForm, licenseExpiryDate: driverForm.licenseExpiryDate || null };
      const response = editDriverId
        ? await axios.put(`${API_BASE_URL}/api/admin/drivers/${editDriverId}`, payload, config)
        : await axios.post(`${API_BASE_URL}/api/admin/drivers`, payload, config);
      setStatusMessage(response.data?.message || "Driver saved successfully.");
      resetDriverForm();
      fetchTransportData();
    } catch (err) {
      setError(err.response?.data?.message || err.response?.data?.error || "Unable to save driver.");
    } finally {
      setLoading(false);
    }
  };

  const resetDriverForm = () => {
    setEditDriverId(null);
    setDriverForm({ driverId: "", name: "", phone: "", email: "", licenseNumber: "", licenseExpiryDate: "", address: "", emergencyContact: "", status: "Available" });
  };

  const handleDriverEdit = (driver) => {
    setEditDriverId(driver._id);
    setDriverForm({
      driverId: driver.driverId || "",
      name: driver.name || "",
      phone: driver.phone || "",
      email: driver.email || "",
      licenseNumber: driver.licenseNumber || "",
      licenseExpiryDate: driver.licenseExpiryDate ? new Date(driver.licenseExpiryDate).toISOString().split("T")[0] : "",
      address: driver.address || "",
      emergencyContact: driver.emergencyContact || "",
      status: driver.status || "Available",
    });
    setActiveTab("drivers");
  };

  const handleDriverDelete = async (driverId) => {
    const token = localStorage.getItem("adminToken");
    try {
      const response = await axios.delete(`${API_BASE_URL}/api/admin/drivers/${driverId}`, { headers: { Authorization: `Bearer ${token}` } });
      setStatusMessage(response.data?.message || "Driver deleted.");
      fetchTransportData();
    } catch (err) {
      setError("Unable to delete driver.");
    }
  };

  const handleAssignDriver = async () => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Admin session expired. Please log in again.");
      navigate("/admin-login");
      return;
    }

    try {
      const response = await axios.post(`${API_BASE_URL}/api/assignments`, assignForm, { headers: { Authorization: `Bearer ${token}` } });
      setStatusMessage(response.data?.message || "Driver assigned.");
      setAssignForm({ driverId: "", busId: "", scheduleType: "Morning Route", routeId: "", routeModel: "", routeName: "", shift: "Morning" });
      fetchRoutes();
      fetchTransportData();
    } catch (err) {
      const message = err.response?.data?.message || err.response?.data?.msg;
      if (err.response?.status === 401) {
        localStorage.removeItem("adminToken");
        localStorage.removeItem("admin");
        setError(message || "Admin session expired. Please log in again.");
        navigate("/admin-login");
        return;
      }
      setError(message || "Unable to assign driver.");
    }
  };

  const handleAssignBusChange = (busId) => {
    const bus = buses.find((item) => item._id === busId);
    const scheduleType = bus?.schedule ? `${bus.schedule} Route` : "Morning Route";
    setAssignForm({
      ...assignForm,
      busId,
      scheduleType,
      routeId: bus?.routeId?._id || bus?.routeId || "",
      routeModel: bus?.routeModel || "",
      routeName: bus?.routeName || bus?.routeId?.routeName || "",
      shift: bus?.schedule === "Evening" ? "Evening" : bus?.schedule === "Shuttle" ? "All Day" : "Morning",
    });
  };

  const handleAssignScheduleChange = (scheduleType) => {
    const bus = buses.find((item) => item._id === assignForm.busId);
    const sameSchedule = bus && normalizeSchedule(bus.schedule) === normalizeSchedule(scheduleType);
    setAssignForm({
      ...assignForm,
      scheduleType,
      routeId: sameSchedule ? bus.routeId?._id || bus.routeId || "" : "",
      routeModel: sameSchedule ? bus.routeModel || "" : "",
      routeName: sameSchedule ? bus.routeName || "" : "",
      shift: scheduleType === "Evening Route" ? "Evening" : scheduleType === "Shuttle Route" ? "All Day" : "Morning",
    });
  };

  const normalizeSchedule = (value) => String(value || "").replace(/ Route$/, "");
  const driverUnavailableReason = (driver) => {
    if (!driver.isActive) return "Inactive";
    if (driver.status === "On Duty" || driver.availability === "Busy") return "On Duty";
    if (driver.status === "On Leave" || driver.status === "Off Duty" || driver.availability === "On Leave") return "Unavailable";
    if (driver.assignedBus) return "Already Assigned";
    return "";
  };
  const selectedAssignmentSchedule = normalizeSchedule(assignForm.scheduleType);
  const assignmentRoutes = Array.from(new Map(
    buses
      .filter((bus) => normalizeSchedule(bus.schedule) === selectedAssignmentSchedule)
      .map((bus) => [bus.routeName?.trim(), bus])
      .filter(([routeName]) => routeName)
  ).entries());

  const handleAlertSubmit = async () => {
    const token = localStorage.getItem("adminToken");
    try {
      const response = await axios.post(`${API_BASE_URL}/api/admin/alerts`, alertForm, { headers: { Authorization: `Bearer ${token}` } });
      setStatusMessage(response.data?.message || "Alert created.");
      setAlertForm({ title: "", message: "", type: "Bus Delay", busId: "", route: "" });
      fetchTransportData();
    } catch (err) {
      setError("Unable to create alert.");
    }
  };

  const handleMaintenanceSubmit = async () => {
    const token = localStorage.getItem("adminToken");
    try {
      const response = await axios.post(`${API_BASE_URL}/api/admin/maintenance`, maintenanceForm, { headers: { Authorization: `Bearer ${token}` } });
      setStatusMessage(response.data?.message || "Maintenance record added.");
      setMaintenanceForm({ busId: "", lastServiceDate: "", nextServiceDate: "", odometer: "", status: "Good", notes: "" });
      fetchTransportData();
    } catch (err) {
      setError("Unable to add maintenance record.");
    }
  };

  const handleFoundChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image") {
      setFoundForm({ ...foundForm, image: files[0] });
      return;
    }
    setFoundForm({ ...foundForm, [name]: value });
  };

  const handleFoundSubmit = async () => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }

    const formData = new FormData();
    formData.append("itemName", foundForm.itemName);
    formData.append("category", foundForm.category);
    formData.append("description", foundForm.description);
    formData.append("busNumber", foundForm.busNumber);
    formData.append("route", foundForm.route);
    formData.append("dateFound", foundForm.dateFound);
    formData.append("phone", foundForm.phone);
    formData.append("reportedBy", foundForm.reportedBy);
    if (foundForm.image) formData.append("image", foundForm.image);

    try {
      await axios.post(`${API_BASE_URL}/api/founditems`, formData, {
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "multipart/form-data" },
      });
      setFoundForm({ itemName: "", category: "", description: "", busNumber: "", route: "", dateFound: "", phone: "", reportedBy: "Admin", image: null });
      fetchFoundItems();
    } catch (err) {
      setError("Unable to add found item.");
    }
  };

  const handleMatch = async () => {
    const token = localStorage.getItem("adminToken");
    if (!token || !selectedLostItem || !selectedFoundItem) {
      setError("Select a lost item and a found item to match.");
      return;
    }

    try {
      await axios.post(`${API_BASE_URL}/api/match`, {
        lostId: selectedLostItem,
        foundId: selectedFoundItem,
      }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchLostItems();
      fetchFoundItems();
    } catch (err) {
      setError("Unable to match items.");
    }
  };

  const handleReady = async (itemId) => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }

    try {
      await axios.put(`${API_BASE_URL}/api/lostitems/${itemId}/ready`, null, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchLostItems();
      fetchFoundItems();
    } catch (err) {
      setError("Unable to update item status.");
    }
  };

  const handleReturned = async (itemId) => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      setError("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }

    try {
      await axios.put(`${API_BASE_URL}/api/lostitems/${itemId}/returned`, null, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchLostItems();
      fetchFoundItems();
    } catch (err) {
      setError("Unable to update item status.");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("admin");
    navigate("/");
  };

  const summary = dashboardData?.summary || {};
  const driverStats = dashboardData?.drivers || {};

  return (
    <div className="admin-panel-page">
      <header className="admin-panel-header">
        <div>
          <p className="admin-label">Admin Panel</p>
          <h1>Transport Operations Center</h1>
          <p className="admin-subtitle">Track buses, drivers, routes, alerts, maintenance, and live passenger updates without changing your current UI.</p>
        </div>
        <button className="logout-button" onClick={handleLogout}>Logout</button>
      </header>

      {statusMessage && <div className="form-success">{statusMessage}</div>}
      {error && <div className="form-error">{error}</div>}

      <div className="admin-tabs">
        <button className={activeTab === "dashboard" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("dashboard")}>Dashboard</button>
        <button className={activeTab === "buses" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("buses")}>Buses</button>
        <button className={activeTab === "drivers" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("drivers")}>Drivers</button>
        <button className={activeTab === "alerts" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("alerts")}>Alerts</button>
        <button className={activeTab === "maintenance" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("maintenance")}>Maintenance</button>
        <button className={activeTab === "tracking" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("tracking")}>Tracking</button>
        <button className={activeTab === "lost" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("lost")}>Lost Reports</button>
        <button className={activeTab === "found" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("found")}>Found Items</button>
        <button className={activeTab === "match" ? "tab-active" : "tab-button"} onClick={() => setActiveTab("match")}>Match Items</button>
      </div>

      {activeTab === "dashboard" && (
        <>
          <section className="admin-panel-form-card">
            <div className="form-header">
              <h2>System Summary</h2>
            </div>
            <div className="dashboard-grid">
              {[
                { label: "Total Buses", value: summary.totalRegisteredBuses ?? "N/A" },
                { label: "Total Drivers", value: summary.totalDrivers ?? "N/A" },
                { label: "Morning Routes", value: summary.morningRoutes ?? "N/A" },
                { label: "Evening Routes", value: summary.eveningRoutes ?? "N/A" },
                { label: "Shuttle Routes", value: summary.shuttleRoutes ?? "N/A" },
                { label: "Passenger Count", value: summary.currentLivePassengerCount ?? "N/A" },
                { label: "Maintenance", value: summary.maintenanceRecords ?? "N/A" },
                { label: "Lost Reports", value: summary.lostItemReports ?? "N/A" },
                { label: "Found Items", value: summary.foundItems ?? "N/A" },
                { label: "Matched Items", value: summary.matchedItems ?? "N/A" },
                { label: "Online Buses", value: summary.onlineBuses ?? "N/A" },
                { label: "Offline Buses", value: summary.offlineBuses ?? "N/A" },
              ].map((item) => (
                <div className="stat-card" key={item.label}>
                  <h3>{item.value}</h3>
                  <p>{item.label}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="admin-panel-list-card">
            <div className="form-header">
              <h2>Driver & Alert Status</h2>
            </div>
            <div className="dashboard-grid">
              <div className="stat-card">
                  <h3>{driverStats.totalDrivers ?? "N/A"}</h3>
                <p>Total Drivers</p>
              </div>
              <div className="stat-card">
                  <h3>{driverStats.onDuty ?? "N/A"}</h3>
                <p>Drivers On Duty</p>
              </div>
              <div className="stat-card">
                  <h3>{driverStats.available ?? "N/A"}</h3>
                <p>Drivers Available</p>
              </div>
              <div className="stat-card">
                  <h3>{driverStats.onLeave ?? "N/A"}</h3>
                <p>Drivers On Leave</p>
              </div>
              <div className="stat-card">
                <h3>{performanceSummary?.averageRating ?? "N/A"}</h3>
                <p>Average Rating</p>
              </div>
              <div className="stat-card">
                <h3>{performanceSummary?.todayRating ?? "N/A"}</h3>
                <p>Today's Rating</p>
              </div>
              <div className="stat-card">
                <h3>{performanceSummary?.weeklyRating ?? "N/A"}</h3>
                <p>Weekly Rating</p>
              </div>
              <div className="stat-card">
                <h3>{performanceSummary?.monthlyRating ?? "N/A"}</h3>
                <p>Monthly Rating</p>
              </div>
              <div className="stat-card">
                <h3>{performanceSummary?.topDriver?.name || "N/A"}</h3>
                <p>Top Driver</p>
              </div>
              <div className="stat-card">
                <h3>{performanceSummary?.lowestRatedDriver?.name || "N/A"}</h3>
                <p>Lowest Rated Driver</p>
              </div>
            </div>
            <div className="admin-routes-table-wrapper" style={{ marginTop: "24px" }}>
              <table className="admin-routes-table">
                <thead>
                  <tr>
                    <th>Activity</th>
                    <th>Details</th>
                  </tr>
                </thead>
                <tbody>
                  {(dashboardData?.recentActivities || []).length === 0 ? (
                    <tr><td colSpan="2">No activity data available.</td></tr>
                  ) : (dashboardData.recentActivities || []).map((activity, index) => (
                    <tr key={`${activity.type}-${activity.createdAt || index}`}>
                      <td>{activity.type}</td>
                      <td>{activity.detail}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {activeTab === "buses" && (
        <>
          <section className="admin-panel-form-card">
            <div className="form-header">
              <h2>{editBusId ? "Edit Bus" : "Add Bus"}</h2>
            </div>
            <div className="admin-panel-form">
              <label>Bus ID<input value={busForm.busId} onChange={(e) => setBusForm({ ...busForm, busId: e.target.value })} placeholder="BUS-001" /></label>
              <label>Bus Number<input value={busForm.busNumber} onChange={(e) => setBusForm({ ...busForm, busNumber: e.target.value })} placeholder="B-12" /></label>
              <label>Schedule<select value={busForm.schedule} onChange={(e) => setBusForm({ ...busForm, schedule: e.target.value, routeId: "", routeModel: "", routeName: "" })}><option value="Shuttle">Shuttle</option><option value="Morning">Morning</option><option value="Evening">Evening</option></select></label>
              <label>Route<input type="text" value={busForm.routeName} onChange={(e) => setBusForm({ ...busForm, routeName: e.target.value, routeId: "", routeModel: "" })} placeholder="Type route name here..." /></label>
              <label>Departure Time<input type="time" value={busForm.departureTime} onChange={(e) => setBusForm({ ...busForm, departureTime: e.target.value })} /></label>
              <label>Capacity<input type="number" value={busForm.capacity} onChange={(e) => setBusForm({ ...busForm, capacity: e.target.value })} /></label>
              <label>Current Passenger Count<input type="number" value={busForm.currentPassengerCount} onChange={(e) => setBusForm({ ...busForm, currentPassengerCount: e.target.value })} readOnly /></label>
              <label>GPS Status<select value={busForm.gpsStatus} onChange={(e) => setBusForm({ ...busForm, gpsStatus: e.target.value })}><option value="Online">Online</option><option value="Offline">Offline</option></select></label>
              <label>Camera Status<select value={busForm.cameraStatus} onChange={(e) => setBusForm({ ...busForm, cameraStatus: e.target.value })}><option value="Online">Online</option><option value="Offline">Offline</option></select></label>
              <label>Running Status<select value={busForm.runningStatus} onChange={(e) => setBusForm({ ...busForm, runningStatus: e.target.value })}><option value="Running">Running</option><option value="Stopped">Stopped</option><option value="Maintenance">Maintenance</option></select></label>
              <label>Status<select value={busForm.status} onChange={(e) => setBusForm({ ...busForm, status: e.target.value })}><option value="active">Active</option><option value="inactive">Inactive</option><option value="maintenance">Maintenance</option></select></label>
              <div className="form-actions">
                <button onClick={handleBusSubmit} disabled={loading}>{loading ? "Saving..." : editBusId ? "Save Bus" : "Add Bus"}</button>
                {editBusId && <button className="cancel-button" onClick={resetBusForm}>Cancel</button>}
              </div>
            </div>
          </section>

          <section className="admin-panel-list-card">
            <h2>All Buses</h2>
            <div className="admin-routes-table-wrapper">
              <table className="admin-routes-table">
                <thead><tr><th>Bus ID</th><th>Bus Number</th><th>Assigned Driver</th><th>Assigned Route</th><th>Schedule</th><th>Capacity</th><th>Passengers</th><th>GPS</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                  {buses.map((bus) => (
                    <tr key={bus._id}>
                      <td>{bus.busId}</td>
                      <td>{bus.busNumber}</td>
                      <td>{bus.driverId?.name || bus.driverName || "Unassigned"}</td>
                      <td>{bus.routeName || bus.routeId?.routeName || "Unassigned"}</td>
                      <td>{bus.schedule || "Morning"}</td>
                      <td>{bus.capacity || 50}</td>
                      <td>{bus.currentPassengerCount || 0}</td>
                      <td>{bus.gpsStatus}</td>
                      <td>{bus.status}</td>
                      <td className="action-buttons-cell">
                        <button className="secondary-button" onClick={() => handleBusEdit(bus)}>Edit</button>
                        <button className="secondary-button" onClick={() => handleBusToggle(bus)}>{bus.status === "active" ? "Deactivate" : "Activate"}</button>
                        <button className="danger-button" onClick={() => handleBusDelete(bus._id)}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {activeTab === "drivers" && (
        <>
          <section className="admin-panel-form-card">
            <div className="form-header"><h2>{editDriverId ? "Edit Driver" : "Add Driver"}</h2></div>
            <div className="admin-panel-form">
              <label>Driver ID<input value={driverForm.driverId} onChange={(e) => setDriverForm({ ...driverForm, driverId: e.target.value })} placeholder="DRV-001" /></label>
              <label>Driver Name<input value={driverForm.name} onChange={(e) => setDriverForm({ ...driverForm, name: e.target.value })} /></label>
              <label>Phone<input value={driverForm.phone} onChange={(e) => setDriverForm({ ...driverForm, phone: e.target.value })} /></label>
              <label>Email<input value={driverForm.email} onChange={(e) => setDriverForm({ ...driverForm, email: e.target.value })} /></label>
              <label>License Number<input value={driverForm.licenseNumber} onChange={(e) => setDriverForm({ ...driverForm, licenseNumber: e.target.value })} /></label>
              <label>License Expiry Date<input type="date" value={driverForm.licenseExpiryDate} onChange={(e) => setDriverForm({ ...driverForm, licenseExpiryDate: e.target.value })} /></label>
              <label>Address<input value={driverForm.address} onChange={(e) => setDriverForm({ ...driverForm, address: e.target.value })} /></label>
              <label>Emergency Contact<input value={driverForm.emergencyContact} onChange={(e) => setDriverForm({ ...driverForm, emergencyContact: e.target.value })} /></label>
              <label>Status<select value={driverForm.status} onChange={(e) => setDriverForm({ ...driverForm, status: e.target.value })}><option value="Available">Available</option><option value="On Duty">On Duty</option><option value="Off Duty">Off Duty</option><option value="On Leave">On Leave</option></select></label>
              <div className="form-actions"><button onClick={handleDriverSubmit} disabled={loading}>{loading ? "Saving..." : editDriverId ? "Save Driver" : "Add Driver"}</button>{editDriverId && <button className="cancel-button" onClick={resetDriverForm}>Cancel</button>}</div>
            </div>
          </section>

          <section className="admin-panel-list-card">
            <div className="form-header"><h2>Assign Driver to Bus</h2></div>
            <div className="admin-panel-form">
              <label>Driver<select value={assignForm.driverId} onChange={(e) => setAssignForm({ ...assignForm, driverId: e.target.value })}><option value="">Select Driver</option>{drivers.map((driver) => { const reason = driverUnavailableReason(driver); return <option key={driver._id} value={driver._id} disabled={Boolean(reason)}>{driver.name}{reason ? ` - ${reason}` : ""}</option>; })}</select></label>
              <label>Bus<select value={assignForm.busId} onChange={(e) => handleAssignBusChange(e.target.value)}><option value="">Select Bus</option>{buses.filter((bus) => bus.status === "active").map((bus) => <option key={bus._id} value={bus._id}>{bus.busNumber} ({bus.busId})</option>)}</select></label>
              <label>Schedule Type<select value={assignForm.scheduleType} onChange={(e) => handleAssignScheduleChange(e.target.value)}><option value="Morning Route">Morning Route</option><option value="Evening Route">Evening Route</option><option value="Shuttle Route">Shuttle Route</option></select></label>
              <label>Route<select value={assignForm.routeName} onChange={(e) => { const bus = assignmentRoutes.find(([routeName]) => routeName === e.target.value)?.[1]; setAssignForm({ ...assignForm, routeId: bus?.routeId?._id || bus?.routeId || "", routeModel: bus?.routeModel || "", routeName: e.target.value }); }}><option value="">{assignmentRoutes.length ? "Select Route" : "No routes available"}</option>{assignmentRoutes.map(([routeName, bus]) => <option key={`${routeName}-${bus._id}`} value={routeName}>{routeName}</option>)}</select></label>
              <label>Shift<select value={assignForm.shift} onChange={(e) => setAssignForm({ ...assignForm, shift: e.target.value })}><option value="Morning">Morning</option><option value="Evening">Evening</option><option value="All Day">All Day</option></select></label>
              <div className="form-actions"><button onClick={handleAssignDriver}>Assign</button></div>
            </div>
          </section>

          <section className="admin-panel-list-card">
            <h2>Driver List</h2>
            <div className="admin-routes-table-wrapper">
              <table className="admin-routes-table">
                <thead><tr><th>Name</th><th>Phone</th><th>Status</th><th>Assigned Bus</th><th>Actions</th></tr></thead>
                <tbody>
                  {drivers.map((driver) => (
                    <tr key={driver._id}>
                      <td>{driver.name}</td>
                      <td>{driver.phone}</td>
                      <td>{driver.status}</td>
                      <td>{driver.assignedBus?.busNumber || "Unassigned"}</td>
                      <td className="action-buttons-cell"><button className="secondary-button" onClick={() => handleDriverEdit(driver)}>Edit</button><button className="danger-button" onClick={() => handleDriverDelete(driver._id)}>Delete</button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {activeTab === "alerts" && (
        <>
          <section className="admin-panel-form-card">
            <div className="form-header"><h2>Create Alert</h2></div>
            <div className="admin-panel-form">
              <label>Title<input value={alertForm.title} onChange={(e) => setAlertForm({ ...alertForm, title: e.target.value })} /></label>
              <label>Message<input value={alertForm.message} onChange={(e) => setAlertForm({ ...alertForm, message: e.target.value })} /></label>
              <label>Type<select value={alertForm.type} onChange={(e) => setAlertForm({ ...alertForm, type: e.target.value })}><option value="Bus Delay">Bus Delay</option><option value="Route Changed">Route Changed</option><option value="Emergency">Emergency</option><option value="Maintenance">Maintenance</option><option value="Holiday">Holiday</option><option value="Weather">Weather</option><option value="Bus Breakdown">Bus Breakdown</option></select></label>
              <label>Bus ID<input value={alertForm.busId} onChange={(e) => setAlertForm({ ...alertForm, busId: e.target.value })} /></label>
              <label>Route<input value={alertForm.route} onChange={(e) => setAlertForm({ ...alertForm, route: e.target.value })} /></label>
              <div className="form-actions"><button onClick={handleAlertSubmit}>Send Alert</button></div>
            </div>
          </section>
          <section className="admin-panel-list-card">
            <h2>Active Alerts</h2>
            <div className="admin-routes-table-wrapper">
              <table className="admin-routes-table">
                <thead><tr><th>Title</th><th>Type</th><th>Message</th></tr></thead>
                <tbody>{alerts.map((alert) => <tr key={alert._id}><td>{alert.title}</td><td>{alert.type}</td><td>{alert.message}</td></tr>)}</tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {activeTab === "maintenance" && (
        <>
          <section className="admin-panel-form-card">
            <div className="form-header"><h2>Maintenance Update</h2></div>
            <div className="admin-panel-form">
              <label>Bus ID<input value={maintenanceForm.busId} onChange={(e) => setMaintenanceForm({ ...maintenanceForm, busId: e.target.value })} /></label>
              <label>Last Service Date<input type="date" value={maintenanceForm.lastServiceDate} onChange={(e) => setMaintenanceForm({ ...maintenanceForm, lastServiceDate: e.target.value })} /></label>
              <label>Next Service Date<input type="date" value={maintenanceForm.nextServiceDate} onChange={(e) => setMaintenanceForm({ ...maintenanceForm, nextServiceDate: e.target.value })} /></label>
              <label>Odometer<input type="number" value={maintenanceForm.odometer} onChange={(e) => setMaintenanceForm({ ...maintenanceForm, odometer: e.target.value })} /></label>
              <label>Status<select value={maintenanceForm.status} onChange={(e) => setMaintenanceForm({ ...maintenanceForm, status: e.target.value })}><option value="Good">Good</option><option value="Needs Service">Needs Service</option><option value="Critical">Critical</option></select></label>
              <label>Notes<input value={maintenanceForm.notes} onChange={(e) => setMaintenanceForm({ ...maintenanceForm, notes: e.target.value })} /></label>
              <div className="form-actions"><button onClick={handleMaintenanceSubmit}>Save Maintenance</button></div>
            </div>
          </section>
          <section className="admin-panel-list-card">
            <h2>Maintenance Records</h2>
            <div className="admin-routes-table-wrapper">
              <table className="admin-routes-table">
                <thead><tr><th>Bus ID</th><th>Status</th><th>Next Service</th><th>Odometer</th></tr></thead>
                <tbody>{maintenance.map((item) => <tr key={item._id}><td>{item.busId}</td><td>{item.status}</td><td>{item.nextServiceDate ? new Date(item.nextServiceDate).toLocaleDateString() : "N/A"}</td><td>{item.odometer}</td></tr>)}</tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {activeTab === "tracking" && (
        <>
          <section className="admin-panel-form-card">
            <div className="form-header"><h2>Live GPS Monitoring</h2></div>
            <label>
              Select Bus
              <select value={selectedBusId} onChange={(e) => setSelectedBusId(e.target.value)}>
                <option value="">Choose bus</option>
                {liveTracking.map((bus) => <option key={bus._id} value={bus.busId || bus.busNumber}>{bus.busNumber || bus.busId}</option>)}
              </select>
            </label>
            <div style={{ marginTop: "20px" }}>
              <LiveBusMap busId={selectedBusId} title="Live Bus Tracking" subtitle="Admin Live Map" />
            </div>
          </section>
          <section className="admin-panel-list-card">
            <h2>Tracked Buses</h2>
            <div className="admin-routes-table-wrapper">
              <table className="admin-routes-table">
                <thead><tr><th>Bus</th><th>Bus ID</th><th>Route</th><th>Schedule</th><th>Running</th><th>GPS</th><th>Passengers</th></tr></thead>
                <tbody>{liveTracking.length === 0 ? <tr><td colSpan="7">No active buses available.</td></tr> : liveTracking.map((bus) => <tr key={bus._id}><td>{bus.busNumber || bus.busId}</td><td>{bus.busId || "N/A"}</td><td>{bus.routeName || "N/A"}</td><td>{bus.schedule || "N/A"}</td><td>{bus.runningStatus || "Stopped"}</td><td>{bus.gpsStatus || "Offline"}</td><td>{bus.currentPassengerCount ?? 0}</td></tr>)}</tbody>
              </table>
            </div>
          </section>
        </>
      )}

      {activeTab === "lost" && (
        <section className="admin-panel-list-card">
          <h2>Lost Reports</h2>
          <div className="admin-routes-table-wrapper">
            <table className="admin-routes-table">
              <thead><tr><th>Item</th><th>Student ID</th><th>Route</th><th>Date Lost</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>{lostItems.length === 0 ? <tr><td colSpan="6">No lost reports found.</td></tr> : lostItems.map((item) => <tr key={item._id}><td>{item.itemName}</td><td>{item.studentId}</td><td>{item.route}</td><td>{new Date(item.dateLost).toLocaleDateString()}</td><td>{item.status}</td><td className="action-buttons-cell"><button className="secondary-button" onClick={() => handleReady(item._id)}>Ready</button><button className="secondary-button" onClick={() => handleReturned(item._id)}>Returned</button><button className="danger-button" onClick={() => handleDelete(item._id, "lost")}>Delete</button></td></tr>)}</tbody>
            </table>
          </div>
        </section>
      )}

      {activeTab === "found" && (
        <section className="admin-panel-list-card">
          <div className="form-header"><h2>Found Items</h2></div>
          <div className="admin-panel-form">
            <label>Item Name<input value={foundForm.itemName} onChange={handleFoundChange} name="itemName" placeholder="Item name" /></label>
            <label>Category<input value={foundForm.category} onChange={handleFoundChange} name="category" placeholder="Category" /></label>
            <label>Bus Number<input value={foundForm.busNumber} onChange={handleFoundChange} name="busNumber" placeholder="Bus number" /></label>
            <label>Route<input value={foundForm.route} onChange={handleFoundChange} name="route" placeholder="Route" /></label>
            <label>Date Found<input type="date" value={foundForm.dateFound} onChange={handleFoundChange} name="dateFound" /></label>
            <label>Phone<input value={foundForm.phone} onChange={handleFoundChange} name="phone" placeholder="Contact phone" /></label>
            <label>Reported By<input value={foundForm.reportedBy} onChange={handleFoundChange} name="reportedBy" placeholder="Reported by" /></label>
            <label>Upload Image<input type="file" name="image" accept="image/*" onChange={handleFoundChange} /></label>
            <button onClick={handleFoundSubmit} className="secondary-button">Add Found Item</button>
          </div>
          <div className="admin-routes-table-wrapper" style={{ marginTop: "24px" }}>
            <table className="admin-routes-table">
              <thead><tr><th>Item</th><th>Route</th><th>Date Found</th><th>Status</th><th>Actions</th></tr></thead>
              <tbody>{foundItems.length === 0 ? <tr><td colSpan="5">No found items recorded.</td></tr> : foundItems.map((item) => <tr key={item._id}><td>{item.itemName}</td><td>{item.route}</td><td>{new Date(item.dateFound).toLocaleDateString()}</td><td>{item.status}</td><td className="action-buttons-cell"><button className="danger-button" onClick={() => handleDelete(item._id, "found")}>Delete</button></td></tr>)}</tbody>
            </table>
          </div>
        </section>
      )}

      {activeTab === "match" && (
        <section className="admin-panel-list-card">
          <h2>Match Lost and Found Items</h2>
          <div className="match-grid">
            <div>
              <label>Select Lost Report<select value={selectedLostItem || ""} onChange={(e) => setSelectedLostItem(e.target.value)}><option value="">Choose lost report</option>{lostItems.map((item) => <option key={item._id} value={item._id}>{item.itemName} • {item.route} • {item.studentId}</option>)}</select></label>
            </div>
            <div>
              <label>Select Found Item<select value={selectedFoundItem || ""} onChange={(e) => setSelectedFoundItem(e.target.value)}><option value="">Choose found item</option>{foundItems.map((item) => <option key={item._id} value={item._id}>{item.itemName} • {item.route}</option>)}</select></label>
            </div>
            <div className="match-actions"><button className="secondary-button" onClick={handleMatch}>Match Selected Items</button></div>
          </div>
        </section>
      )}
    </div>
  );
}

export default AdminPanel;