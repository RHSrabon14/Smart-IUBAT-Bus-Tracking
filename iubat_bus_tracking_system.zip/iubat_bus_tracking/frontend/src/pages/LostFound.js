import React, { useState, useEffect } from "react";
import axios from "axios";
import { API_BASE_URL } from "../utils/api";

const statusStyles = {
  Lost: { background: "#ffe9e9", color: "#c92f2f" },
  Found: { background: "#fff4d9", color: "#9e7000" },
  "Ready for Collection": { background: "#e7f0ff", color: "#1f5ccf" },
  Returned: { background: "#eaf9ec", color: "#1a7c3d" },
};

function LostFound() {
  const [form, setForm] = useState({
    itemName: "",
    category: "",
    description: "",
    dateLost: "",
    busNumber: "",
    route: "",
    studentId: "",
    phone: "",
    image: null,
  });
  const [reports, setReports] = useState([]);
  const [foundItems, setFoundItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetchReports();
    fetchFoundItems();
    const interval = setInterval(() => {
      fetchReports();
      fetchFoundItems();
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const fetchReports = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/lostitems`);
      setReports(response.data.data || []);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchFoundItems = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/founditems`);
      setFoundItems(response.data.data || []);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image") {
      setForm({ ...form, image: files[0] });
      return;
    }
    setForm({ ...form, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.itemName || !form.category || !form.description || !form.dateLost || !form.busNumber || !form.route || !form.studentId || !form.phone) {
      setMessage("Please complete every required field before submitting.");
      return;
    }

    const formData = new FormData();
    formData.append("itemName", form.itemName);
    formData.append("category", form.category);
    formData.append("description", form.description);
    formData.append("dateLost", form.dateLost);
    formData.append("busNumber", form.busNumber);
    formData.append("route", form.route);
    formData.append("studentId", form.studentId);
    formData.append("phone", form.phone);
    if (form.image) {
      formData.append("image", form.image);
    }

    try {
      setLoading(true);
      await axios.post(`${API_BASE_URL}/api/lostitems`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      setMessage("Lost item report submitted successfully.");
      setForm({
        itemName: "",
        category: "",
        description: "",
        dateLost: "",
        busNumber: "",
        route: "",
        studentId: "",
        phone: "",
        image: null,
      });
      fetchReports();
    } catch (error) {
      console.error(error);
      setMessage("Unable to submit the report right now. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <div>
            <p style={styles.label}>Student Services</p>
            <h1 style={styles.title}>Lost & Found</h1>
            <p style={styles.subtitle}>
              Report lost items, view found items, and track real-time status updates for your lost property.
            </p>
          </div>
        </div>

        <div style={styles.content}>
          <section style={styles.formCard}>
            <div style={styles.cardHeader}>
              <div>
                <h3 style={styles.cardTitle}>Report Lost Item</h3>
                <p style={styles.cardSubtitle}>Submit your item details and we will match it with found reports.</p>
              </div>
              <span style={styles.helpPill}>Lost → Found → Ready for Collection → Returned</span>
            </div>

            <form onSubmit={handleSubmit} style={styles.formGrid}>
              <input name="itemName" value={form.itemName} onChange={handleChange} placeholder="Item Name" style={styles.input} />
              <input name="category" value={form.category} onChange={handleChange} placeholder="Category" style={styles.input} />
              <input type="date" name="dateLost" value={form.dateLost} onChange={handleChange} style={styles.input} />
              <input name="busNumber" value={form.busNumber} onChange={handleChange} placeholder="Bus Number" style={styles.input} />
              <input name="route" value={form.route} onChange={handleChange} placeholder="Route" style={styles.input} />
              <input name="studentId" value={form.studentId} onChange={handleChange} placeholder="Student ID" style={styles.input} />
              <input name="phone" value={form.phone} onChange={handleChange} placeholder="Phone Number" style={styles.input} />
              <label style={styles.fileLabel}>
                {form.image ? form.image.name : "Upload Image (optional)"}
                <input name="image" type="file" accept="image/*" onChange={handleChange} style={styles.fileInput} />
              </label>
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                placeholder="Item Description"
                style={{ ...styles.input, minHeight: "140px", gridColumn: "1 / -1" }}
              />
              {message && <div style={styles.message}>{message}</div>}
              <button type="submit" disabled={loading} style={styles.submitButton}>
                {loading ? "Submitting..." : "Submit Lost Item"}
              </button>
            </form>
          </section>

          <section style={styles.listCard}>
            <div style={styles.cardHeader}> 
              <div>
                <h3 style={styles.cardTitle}>Found Items</h3>
                <p style={styles.cardSubtitle}>Browse items already recovered by the admin team.</p>
              </div>
              <span style={styles.statusCount}>{foundItems.length} items</span>
            </div>

            <div style={styles.itemsGrid}>
              {foundItems.map((item) => (
                <div key={item._id} style={styles.itemCard}>
                  <div style={styles.itemTop}>
                    <strong>{item.itemName}</strong>
                    <span style={{ ...styles.statusBadge, ...statusStyles[item.status] }}>{item.status}</span>
                  </div>
                  <p style={styles.itemMeta}>{item.category} • {item.route} • Bus {item.busNumber}</p>
                  <p style={styles.itemMeta}>{new Date(item.dateFound).toLocaleDateString()}</p>
                  <p style={styles.itemMeta}>{item.description}</p>
                  {item.imageUrl && (
                    <img src={`${API_BASE_URL}${item.imageUrl}`} alt={item.itemName} style={styles.itemImage} />
                  )}
                </div>
              ))}
            </div>
          </section>
        </div>

        <section style={styles.reportsSection}>
          <div style={styles.sectionHeader}>
            <div>
              <h2 style={styles.sectionTitle}>Recent Lost Reports</h2>
              <p style={styles.sectionSubtitle}>Track statuses for lost items and see when your report is matched.</p>
            </div>
            <button style={styles.refreshButton} onClick={fetchReports}>Refresh Status</button>
          </div>

          <div style={styles.reportGrid}>
            {reports.map((report) => (
              <div key={report._id} style={styles.reportCard}>
                <div style={styles.reportHeader}>
                  <div>
                    <strong>{report.itemName}</strong>
                    <p style={styles.reportMeta}>{report.route} • Bus {report.busNumber}</p>
                  </div>
                  <span style={{ ...styles.statusBadge, ...statusStyles[report.status] }}>{report.status}</span>
                </div>
                <p style={styles.reportMeta}>Student ID: {report.studentId}</p>
                <p style={styles.reportMeta}>Phone: {report.phone}</p>
                <p style={styles.reportDescription}>{report.description}</p>
                {report.imageUrl && (
                  <img src={`${API_BASE_URL}${report.imageUrl}`} alt="Report" style={styles.reportImage} />
                )}
                {report.matchedFoundItem && (
                  <div style={styles.matchedBox}>
                    <p style={styles.matchedTitle}>Matched Found Item</p>
                    <p style={styles.matchedText}>{report.matchedFoundItem.itemName} ({report.matchedFoundItem.category})</p>
                  </div>
                )}
              </div>
            ))}
            {reports.length === 0 && <p style={styles.emptyState}>No reports found yet. Submit a lost item form to get started.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#f2f6ff",
    padding: "40px 18px",
  },
  container: {
    maxWidth: "1180px",
    margin: "0 auto",
    display: "grid",
    gap: "24px",
  },
  header: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-end",
    gap: "20px",
  },
  label: {
    margin: 0,
    color: "#2d6cdf",
    fontWeight: 700,
    letterSpacing: "0.1em",
    textTransform: "uppercase",
    fontSize: "0.9rem",
  },
  title: {
    margin: "8px 0 4px",
    fontSize: "2.4rem",
    color: "#12203f",
  },
  subtitle: {
    margin: 0,
    color: "#4a5e7a",
    maxWidth: "780px",
  },
  content: {
    display: "grid",
    gridTemplateColumns: "1.2fr 0.9fr",
    gap: "24px",
  },
  formCard: {
    background: "#ffffff",
    borderRadius: "24px",
    padding: "28px",
    boxShadow: "0 20px 40px rgba(17, 64, 143, 0.08)",
  },
  listCard: {
    background: "#ffffff",
    borderRadius: "24px",
    padding: "28px",
    boxShadow: "0 20px 40px rgba(17, 64, 143, 0.06)",
    minHeight: "420px",
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "14px",
    marginBottom: "20px",
  },
  cardTitle: {
    margin: 0,
    fontSize: "1.45rem",
    color: "#162b4d",
  },
  cardSubtitle: {
    margin: "6px 0 0",
    color: "#5f6c84",
  },
  helpPill: {
    background: "#eef4ff",
    color: "#224db3",
    borderRadius: "999px",
    padding: "10px 16px",
    fontSize: "0.9rem",
    fontWeight: 700,
  },
  statusCount: {
    color: "#4c6ab0",
    fontWeight: 700,
  },
  formGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "16px",
  },
  input: {
    width: "100%",
    minHeight: "50px",
    borderRadius: "16px",
    border: "1px solid #dbe5f5",
    padding: "14px 16px",
    fontSize: "0.95rem",
    color: "#1f344f",
    background: "#f7faff",
  },
  fileLabel: {
    gridColumn: "1 / -1",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    minHeight: "50px",
    padding: "14px 16px",
    borderRadius: "16px",
    background: "#f7faff",
    border: "1px solid #dbe5f5",
    cursor: "pointer",
    color: "#43506f",
  },
  fileInput: {
    display: "none",
  },
  message: {
    gridColumn: "1 / -1",
    borderRadius: "14px",
    background: "#fff4e2",
    color: "#8b5f12",
    padding: "14px 16px",
    fontWeight: 600,
  },
  submitButton: {
    gridColumn: "1 / -1",
    minHeight: "52px",
    borderRadius: "16px",
    border: "none",
    background: "#1f5ccf",
    color: "white",
    fontWeight: 700,
    cursor: "pointer",
    transition: "transform 0.2s ease",
  },
  itemsGrid: {
    display: "grid",
    gap: "18px",
  },
  itemCard: {
    borderRadius: "20px",
    border: "1px solid #e6eefb",
    padding: "22px",
    background: "#fafcff",
  },
  itemTop: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "12px",
    marginBottom: "12px",
  },
  itemMeta: {
    margin: "8px 0 0",
    color: "#5a6a84",
    fontSize: "0.95rem",
  },
  itemDescription: {
    margin: "12px 0 0",
    color: "#4a5b74",
  },
  itemImage: {
    width: "100%",
    maxHeight: "220px",
    objectFit: "cover",
    borderRadius: "16px",
    marginTop: "14px",
  },
  reportsSection: {
    display: "grid",
    gap: "18px",
  },
  sectionHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "14px",
  },
  sectionTitle: {
    margin: 0,
    fontSize: "1.65rem",
    color: "#162b4d",
  },
  sectionSubtitle: {
    margin: "6px 0 0",
    color: "#596b84",
  },
  refreshButton: {
    minHeight: "46px",
    padding: "0 22px",
    borderRadius: "14px",
    border: "1px solid #c7d5f3",
    background: "white",
    color: "#1f4bb7",
    fontWeight: 700,
    cursor: "pointer",
  },
  reportGrid: {
    display: "grid",
    gap: "18px",
  },
  reportCard: {
    borderRadius: "20px",
    border: "1px solid #dee8f6",
    background: "white",
    padding: "22px",
  },
  reportHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: "18px",
    marginBottom: "14px",
  },
  reportMeta: {
    margin: "6px 0 0",
    color: "#5a6a84",
    fontSize: "0.95rem",
  },
  reportDescription: {
    margin: "14px 0 0",
    color: "#404f66",
    lineHeight: 1.7,
  },
  reportImage: {
    marginTop: "16px",
    width: "100%",
    maxHeight: "220px",
    objectFit: "cover",
    borderRadius: "16px",
  },
  matchedBox: {
    marginTop: "18px",
    padding: "16px",
    borderRadius: "16px",
    background: "#eef7f3",
  },
  matchedTitle: {
    margin: 0,
    color: "#1f5c45",
    fontWeight: 700,
  },
  matchedText: {
    margin: "8px 0 0",
    color: "#3d5a55",
  },
  emptyState: {
    color: "#5f6f84",
    padding: "20px",
    borderRadius: "18px",
    background: "#f4f7fb",
    textAlign: "center",
  },
};

export default LostFound;
