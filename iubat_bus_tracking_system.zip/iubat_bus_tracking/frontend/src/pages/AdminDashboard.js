import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { API_BASE_URL } from "../utils/api";
import "./AdminDashboard.css";

function AdminDashboard() {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingRoute, setEditingRoute] = useState(null);
  const [formData, setFormData] = useState({
    busNo: "",
    routeName: "",
    time: "",
    type: "all"
  });
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      navigate("/admin-login");
      return;
    }
    fetchRoutes();
  }, [navigate]);

  const fetchRoutes = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/routes`);
      const data = response.data.data || response.data;
      setRoutes(Array.isArray(data) ? data : []);
    } catch (error) {
      alert("Failed to fetch routes");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = (route) => {
    setEditingRoute(route._id);
    setFormData({
      busNo: route.busNo,
      routeName: route.routeName,
      time: route.time,
      type: route.type
    });
  };

  const handleSave = async () => {
    const token = localStorage.getItem("adminToken");
    if (!token) {
      alert("Session expired. Please login again.");
      navigate("/admin-login");
      return;
    }

    try {
      const response = await axios.put(
        `${API_BASE_URL}/api/admin/update-route/${editingRoute}`,
        formData,
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      if (response.status === 200) {
        alert(response.data.message || "Route updated successfully!");
        setEditingRoute(null);
        fetchRoutes();
      } else {
        if (response.status === 401 || response.status === 403) {
          alert("Authentication failed. Please login again.");
          localStorage.removeItem("adminToken");
          localStorage.removeItem("admin");
          navigate("/admin-login");
        } else {
          alert(response.data.msg || response.data.error || "Failed to update route");
        }
      }
    } catch (error) {
      alert("Network error");
    }
  };

  const handleCancel = () => {
    setEditingRoute(null);
    setFormData({
      busNo: "",
      routeName: "",
      time: "",
      type: "all"
    });
  };

  const handleLogout = () => {
    localStorage.removeItem("adminToken");
    localStorage.removeItem("admin");
    navigate("/");
  };

  if (loading) {
    return <div className="admin-dashboard">Loading...</div>;
  }

  return (
    <div className="admin-dashboard">
      <div className="admin-header">
        <h1>🛠️ Admin Dashboard</h1>
        <button className="logout-btn" onClick={handleLogout}>
          Logout
        </button>
      </div>

      <div className="routes-section">
        <h2>Manage Routes</h2>

        <div className="routes-grid">
          {routes.map((route) => (
            <div key={route._id} className="route-card">
              {editingRoute === route._id ? (
                <div className="edit-form">
                  <input
                    type="text"
                    placeholder="Bus Number"
                    value={formData.busNo}
                    onChange={(e) => setFormData({...formData, busNo: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Route Name"
                    value={formData.routeName}
                    onChange={(e) => setFormData({...formData, routeName: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Time"
                    value={formData.time}
                    onChange={(e) => setFormData({...formData, time: e.target.value})}
                  />
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                  >
                    <option value="all">All Routes</option>
                    <option value="shuttle">Shuttle Route</option>
                  </select>
                  <div className="edit-buttons">
                    <button onClick={handleSave}>Save</button>
                    <button onClick={handleCancel}>Cancel</button>
                  </div>
                </div>
              ) : (
                <div className="route-info">
                  <h3>{route.routeName}</h3>
                  <p><strong>Bus:</strong> {route.busNo}</p>
                  <p><strong>Time:</strong> {route.time}</p>
                  <p><strong>Type:</strong> {route.type}</p>
                  <button
                    className="edit-btn"
                    onClick={() => handleEdit(route)}
                  >
                    Edit
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;