import { useEffect, useState } from "react";
import axios from "axios";
import "./Schedule.css";
import { API_BASE_URL } from "../utils/api";

function Schedule() {
  const [buses, setBuses] = useState([]);
  const [selectedSchedule, setSelectedSchedule] = useState("Shuttle");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchBuses = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/transport/buses-by-schedule`);
        setBuses(response.data.data || []);
        setError("");
      } catch (err) {
        setError(err.response?.data?.message || "Unable to load bus schedule. Please try again later.");
      } finally {
        setLoading(false);
      }
    };

    fetchBuses();
    const interval = setInterval(fetchBuses, 10000);
    return () => clearInterval(interval);
  }, []);

  const selectedBuses = buses.filter((bus) => bus.schedule === selectedSchedule && bus.status !== "inactive");
  const emptyMessage = `No ${selectedSchedule.toLowerCase()} buses available today.`;

  return (
    <div className="schedule-container">
      <div className="schedule-header">
        <div>
          <p className="schedule-label">Live Route Schedule</p>
          <h1>🚌 Shuttle & Campus Routes</h1>
          <p className="schedule-intro">All route data is served from MongoDB and updated by admin.</p>
        </div>
        <div className="schedule-tabs" role="tablist" aria-label="Schedule categories">
          {["Shuttle", "Morning", "Evening"].map((schedule) => (
            <button
              key={schedule}
              type="button"
              role="tab"
              aria-selected={selectedSchedule === schedule}
              className={selectedSchedule === schedule ? "schedule-tab active" : "schedule-tab"}
              onClick={() => setSelectedSchedule(schedule)}
            >
              {schedule}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="schedule-status">Loading bus schedule...</div>
      ) : error ? (
        <div className="schedule-status error">{error}</div>
      ) : (
        <section className="schedule-card">
          <h2>{selectedSchedule} Buses</h2>
          <div className="table-wrapper">
            <table>
              <thead>
                <tr>
                  <th>Bus ID</th>
                  <th>Bus Number</th>
                  <th>Route Name</th>
                  <th>Time</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {selectedBuses.length === 0 ? (
                  <tr>
                    <td colSpan="5">{emptyMessage}</td>
                  </tr>
                ) : (
                  selectedBuses.map((bus) => (
                    <tr key={bus._id}>
                      <td>{bus.busId}</td>
                      <td>{bus.busNumber}</td>
                      <td>{bus.routeName || bus.route?.routeName || bus.routeId?.routeName || "Route not assigned"}</td>
                      <td>{bus.departureTime || bus.routeId?.time || "Not Fixed"}</td>
                      <td>{bus.status}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}

export default Schedule;