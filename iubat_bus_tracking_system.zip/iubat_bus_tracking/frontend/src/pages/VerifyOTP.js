import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../utils/api";
import "./Login.css";

function VerifyOTP() {
  const location = useLocation();
  const navigate = useNavigate();
  const query = new URLSearchParams(location.search);
  const role = query.get("role") || location.state?.role || "student";
  const identifier = query.get("identifier") || location.state?.identifier || "";

  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!identifier) {
      navigate("/student-login");
    }
  }, [identifier, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!otp.trim()) {
      setError("Please enter the OTP.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/verify-otp`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, identifier, otp: otp.trim() }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.msg || "OTP verification failed.");
      }

      setMessage(data.msg || "OTP verified successfully.");
      navigate(`/reset-password?role=${role}&identifier=${encodeURIComponent(identifier)}`, {
        state: { role, identifier },
      });
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <img src="/iubat.png" alt="IUBAT Logo" style={{ height: "60px", marginBottom: "10px" }} />
          <p style={{ fontSize: "14px", color: "#093C5D", fontWeight: "bold", margin: "0" }}>
            OTP VERIFICATION
          </p>
        </div>

        <h2>📧 Verify OTP</h2>
        <p style={{ color: "#666", marginBottom: "15px" }}>
          Enter the 6-digit code sent to {identifier}.
        </p>

        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Enter 6-digit OTP"
            value={otp}
            onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
            maxLength="6"
          />

          {error ? <p className="auth-message auth-error">{error}</p> : null}
          {message ? <p className="auth-message auth-success">{message}</p> : null}

          <button type="submit" disabled={loading}>
            {loading ? "Verifying..." : "Verify OTP"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default VerifyOTP;
