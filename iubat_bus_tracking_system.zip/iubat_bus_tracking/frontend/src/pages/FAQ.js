import React, { useState } from "react";

const faqs = [
  {
    question: "How can I track my bus?",
    answer:
      "You can use the live bus tracker page or the shuttle tracking section to view real-time bus locations on the map.",
  },
  {
    question: "How often is GPS updated?",
    answer:
      "GPS data is refreshed every 5 seconds to keep the location information as close to real time as possible.",
  },
  {
    question: "How do I report a lost item?",
    answer:
      "Open the Lost & Found page, fill out the form, and submit your item details so the admin can review it.",
  },
  {
    question: "How can I contact transport administration?",
    answer:
      "You can contact the administration through the official transport office details listed on the campus notice board or by visiting the admin section.",
  },
  {
    question: "What should I do if a bus is delayed?",
    answer:
      "Check the Alerts page for the latest notices and follow any route changes or emergency updates posted there.",
  },
];

function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  const toggle = (index) => {
    setOpenIndex(openIndex === index ? -1 : index);
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <h1 style={styles.title}>Frequently Asked Questions</h1>
        <p style={styles.subtitle}>Helpful answers about bus tracking and student services</p>
        <div style={styles.list}>
          {faqs.map((item, index) => (
            <div key={index} style={styles.item}>
              <button style={styles.question} onClick={() => toggle(index)}>
                <span>{item.question}</span>
                <span>{openIndex === index ? "−" : "+"}</span>
              </button>
              {openIndex === index && <p style={styles.answer}>{item.answer}</p>}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#eef5ff",
    padding: "40px 16px",
  },
  container: {
    maxWidth: "980px",
    margin: "0 auto",
    background: "#fff",
    borderRadius: "18px",
    padding: "32px",
    boxShadow: "0 10px 30px rgba(0,0,0,0.08)",
  },
  title: {
    margin: 0,
    fontSize: "2rem",
    color: "#10284d",
  },
  subtitle: {
    margin: "8px 0 24px",
    color: "#5d6b83",
  },
  list: {
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  item: {
    border: "1px solid #e3ecff",
    borderRadius: "12px",
    overflow: "hidden",
  },
  question: {
    width: "100%",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    background: "#f9fbff",
    border: 0,
    padding: "16px 18px",
    fontSize: "1rem",
    fontWeight: 700,
    color: "#10284d",
    cursor: "pointer",
    textAlign: "left",
  },
  answer: {
    margin: 0,
    padding: "0 18px 18px",
    color: "#4a5a73",
    lineHeight: 1.6,
  },
};

export default FAQ;
