import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { API_BASE_URL } from "../utils/api";

function ShuttleDetails() {
  const [selectedRoute, setSelectedRoute] = useState("");
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchRoutes();
    const interval = setInterval(fetchRoutes, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchRoutes = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/transport/buses-by-schedule?schedule=Shuttle`);
      const data = response.data.data || response.data;
      setRoutes(Array.isArray(data) ? data : []);
    } catch (err) {
      setError("Unable to load shuttle routes. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = () => {
    if (!selectedRoute) {
      alert("Please select a route before continuing.");
      return;
    }

    localStorage.setItem("shuttleRoute", selectedRoute);
    navigate("/map");
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#31919e",
        padding: "20px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "520px",
          background: "rgba(255,255,255,0.95)",
          borderRadius: "24px",
          boxShadow: "0 18px 40px rgba(0,0,0,0.15)",
          padding: "30px 24px",
          textAlign: "center",
        }}
      >
        <img
          src="/iubat.png"
          alt="IUBAT logo"
          style={{ width: "90px", marginBottom: "16px" }}
        />
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
            gap: "14px",
            marginBottom: "24px",
          }}
        >
          {loading ? (
            <div>Loading routes...</div>
          ) : error ? (
            <div style={{ color: "#c33" }}>{error}</div>
          ) : routes.length === 0 ? (
            <div style={{ gridColumn: "1 / -1", textAlign: "center" }}>No shuttle routes available yet.</div>
          ) : (
            routes.map((route) => {
              const isActive = selectedRoute === route._id;
              return (
                <button
                  key={route._id}
                  type="button"
                  onClick={() => setSelectedRoute(route._id)}
                  style={{
                    border: "none",
                    borderRadius: "18px",
                    padding: "18px 12px",
                    background: isActive ? "#2e7d32" : "#f1f5f9",
                    color: isActive ? "white" : "#0b2342",
                    cursor: "pointer",
                    minHeight: "120px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "center",
                    alignItems: "center",
                    transition: "transform 0.2s ease, background 0.2s ease",
                  }}
                >
                  <span style={{ fontSize: "28px", marginBottom: "10px" }}>🚌</span>
                  <span style={{ fontSize: "16px", fontWeight: 700, marginBottom: "8px" }}>
                    {route.routeName || route.route?.routeName || "Route not assigned"}
                  </span>
                  <span style={{ fontSize: "0.95rem", lineHeight: "1.5", color: isActive ? "#e6f4e6" : "#4f5f73" }}>
                    Bus {route.busNumber || route.busId} • {route.departureTime || route.route?.time || "Not Fixed"}
                  </span>
                </button>
              );
            })
          )}
        </div>

        <button
          type="button"
          onClick={handleContinue}
          style={{
            width: "100%",
            border: "none",
            borderRadius: "14px",
            background: "#0b2342",
            color: "white",
            fontSize: "16px",
            padding: "14px 0",
            cursor: "pointer",
          }}
        >
          Continue
        </button>
      </div>
    </div>
  );
}

export default ShuttleDetails;
