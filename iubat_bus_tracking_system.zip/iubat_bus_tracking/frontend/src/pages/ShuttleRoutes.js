import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { API_BASE_URL } from "../utils/api";

function ShuttleRoutes() {
  const [routes, setRoutes] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchRoutes();
    const interval = setInterval(fetchRoutes, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchRoutes = async () => {
    try {
      const res = await axios.get(`${API_BASE_URL}/api/transport/buses-by-schedule?schedule=Shuttle`);
      const data = res.data.data || res.data;
      setRoutes(Array.isArray(data) ? data : []);
    } catch (err) {
      setRoutes([]);
    }
  };

  return (
    <div style={{
      padding: "40px",
      textAlign: "center",
      background: "#021A54",
      minHeight: "100vh",
      color: "white"
    }}>

      <h1>🚌 Shuttle Routes</h1>

      <div style={{
        background: "#a6d5d8",
        padding: "30px",
        borderRadius: "20px",
        marginTop: "20px"
      }}>

        {routes.length === 0 ? (
          <p>No shuttle routes added yet</p>
        ) : (
          routes.map((r) => (
            <div key={r._id} style={{
              margin: "15px",
              fontSize: "18px",
              fontWeight: "bold"
            }}>
              🚍 Bus {r.busNumber || r.busId} | {r.routeName || r.route?.routeName || "Route not assigned"} | {r.departureTime || r.route?.time || "Not Fixed"}
            </div>
          ))
        )}

      </div>

      <div style={{
        marginTop: "30px",
        display: "flex",
        gap: "15px",
        justifyContent: "center",
        flexWrap: "wrap"
      }}>
        <button
          onClick={() => navigate("/shuttle-routes")}
          style={{
            padding: "14px 28px",
            background: "#1F8EF1",
            color: "white",
            border: "none",
            borderRadius: "12px",
            cursor: "pointer",
            fontSize: "16px",
            fontWeight: "bold",
            transition: "background 0.3s ease",
          }}
          onMouseEnter={(e) => e.target.style.background = "#1873c7"}
          onMouseLeave={(e) => e.target.style.background = "#1F8EF1"}
        >
          Track Shuttle Routes
        </button>

        <button
          onClick={() => navigate("/shuttle-details")}
          style={{
            marginTop: "0px",
            padding: "14px 28px",
            background: "#2c2c5c",
            color: "white",
            border: "none",
            borderRadius: "12px",
            cursor: "pointer",
            fontSize: "16px",
            transition: "background 0.3s ease",
          }}
          onMouseEnter={(e) => e.target.style.background = "#1a1a3a"}
          onMouseLeave={(e) => e.target.style.background = "#2c2c5c"}
        >
          Continue
        </button>
      </div>

    </div>
  );
}

export default ShuttleRoutes;