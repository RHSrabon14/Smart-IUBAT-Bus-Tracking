import Hero from "../components/Hero";
import Card from "../components/Card";
import "./Home.css";
import { useNavigate } from "react-router-dom";

function Home() {
  const navigate = useNavigate();

  return (
    <div className="home">

      {/* HERO */}
      <Hero />

      {/* TOP CARDS */}
      <div className="main-cards">

        <Card title="Student Login">
          <button onClick={() => navigate("/student-login")}>
            Sign In
          </button>
        </Card>

        <Card title="Faculty Login">
          <button onClick={() => navigate("/faculty-login")}>
            Sign In
          </button>
        </Card>

        <Card title="Live Bus Tracker">
          <p>View bus location</p>
          <button onClick={() => navigate("/map")}>
            Open Map
          </button>
        </Card>

      </div>

      {/* BOTTOM CARDS */}
      <div className="bottom-cards">

        <Card title="Shuttle Info">
          <button onClick={() => navigate("/shuttle")}>
            View
          </button>
        </Card>

        <Card title="Lost & Found">
          <button onClick={() => navigate("/lost-found")}>
            View
          </button>
        </Card>

        <Card title="Alerts">
          <button onClick={() => navigate("/alerts")}>
            View
          </button>
        </Card>

        <Card title="FAQ">
          <button onClick={() => navigate("/faq")}>
            Open
          </button>
        </Card>

      </div>

    </div>
  );
}

export default Home;