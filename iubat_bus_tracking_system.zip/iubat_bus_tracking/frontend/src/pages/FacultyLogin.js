import { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { login, isAuthenticated } from "../utils/auth";
import "./Login.css";

function FacultyLogin() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || "/route-select";

  useEffect(() => {
    if (isAuthenticated()) {
      navigate("/route-select", { replace: true });
    }
  }, [navigate]);

  const handleLogin = () => {
    if (!email || !password) {
      alert("Fill all fields");
      return;
    }

    if (!email.endsWith("@iubat.edu")) {
      alert("Only IUBAT faculty allowed ❌");
      return;
    }

    alert("Faculty Login Success ✅");
    localStorage.setItem("faculty", email);
    login();
    navigate(from, { replace: true });
  };

  return (
    <div className="login-container">

      <div className="login-card">

        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <img src="/iubat.png" alt="IUBAT Logo" style={{ height: "60px", marginBottom: "10px" }} />
          <p style={{ fontSize: "14px", color: "#093C5D", fontWeight: "bold", margin: "0" }}>
            IUBAT- INTERNATIONAL UNIVERSITY OF BUSINESS AGRICULTURE AND TECHNOLOGY
          </p>
        </div>

        <h2>👨‍🏫 Faculty Login</h2>

        <input
          type="email"
          placeholder="Faculty Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <Link to="/forgot-password?role=faculty" className="forgot-link">
          Forgot Password?
        </Link>

        <button onClick={handleLogin}>Sign In</button>

      </div>

    </div>
  );
}

export default FacultyLogin;