import { useEffect, useMemo, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../utils/api";
import "./Login.css";

function ForgotPassword() {
  const location = useLocation();
  const navigate = useNavigate();
  const searchParams = new URLSearchParams(location.search);
  const initialRole = searchParams.get("role") || "student";

  const [role, setRole] = useState(initialRole);
  const [identifier, setIdentifier] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    setRole(initialRole);
  }, [initialRole]);

  const roleLabel = useMemo(() => {
    switch (role) {
      case "faculty":
        return "Faculty";
      case "admin":
        return "Admin";
      default:
        return "Student";
    }
  }, [role]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!identifier.trim()) {
      setError("Please enter your registered email.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(identifier.trim())) {
      setError("Please enter a valid email address.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/forgot-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, identifier: identifier.trim() }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.msg || "Unable to send OTP right now.");
      }

      setMessage(data.msg || "OTP sent successfully.");
      navigate(`/verify-otp?role=${role}&identifier=${encodeURIComponent(identifier.trim())}`, {
        state: { role, identifier: identifier.trim() },
      });
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <img src="/iubat.png" alt="IUBAT Logo" style={{ height: "60px", marginBottom: "10px" }} />
          <p style={{ fontSize: "14px", color: "#093C5D", fontWeight: "bold", margin: "0" }}>
            IUBAT PASSWORD RECOVERY
          </p>
        </div>

        <h2>🔐 Forgot Password</h2>
        <p style={{ color: "#666", marginBottom: "15px" }}>
          Recover your {roleLabel.toLowerCase()} account access.
        </p>

        <form onSubmit={handleSubmit}>
          <select value={role} onChange={(e) => setRole(e.target.value)} className="auth-select">
            <option value="student">Student</option>
            <option value="faculty">Faculty</option>
            <option value="admin">Admin</option>
          </select>

          <input
            type="email"
            placeholder="Registered Email"
            value={identifier}
            onChange={(e) => setIdentifier(e.target.value)}
          />

          {error ? <p className="auth-message auth-error">{error}</p> : null}
          {message ? <p className="auth-message auth-success">{message}</p> : null}

          <button type="submit" disabled={loading}>
            {loading ? "Sending OTP..." : "Send OTP"}
          </button>
        </form>

        <Link to={role === "admin" ? "/admin-login" : role === "faculty" ? "/faculty-login" : "/student-login"} className="forgot-link">
          Back to Login
        </Link>
      </div>
    </div>
  );
}

export default ForgotPassword;
