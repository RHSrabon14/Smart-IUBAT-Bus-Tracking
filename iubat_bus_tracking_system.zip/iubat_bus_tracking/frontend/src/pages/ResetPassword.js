import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../utils/api";
import "./Login.css";

function ResetPassword() {
  const location = useLocation();
  const navigate = useNavigate();
  const query = new URLSearchParams(location.search);
  const role = query.get("role") || location.state?.role || "student";
  const identifier = query.get("identifier") || location.state?.identifier || "";

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  const passwordStrength = () => {
    if (!password) return "";
    if (password.length < 8) return "Weak";
    if (password.length >= 12 && /[A-Z]/.test(password) && /[0-9]/.test(password) && /[^A-Za-z0-9]/.test(password)) {
      return "Strong";
    }
    if (password.length >= 8) return "Medium";
    return "Weak";
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setMessage("");

    if (!password || !confirmPassword) {
      setError("Please fill both password fields.");
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters long.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/reset-password`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, identifier, otp: "", password }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.msg || "Password reset failed.");
      }

      setMessage(data.msg || "Password reset was successful.");
      setTimeout(() => {
        if (role === "admin") {
          navigate("/admin-login");
        } else if (role === "faculty") {
          navigate("/faculty-login");
        } else {
          navigate("/student-login");
        }
      }, 1000);
    } catch (err) {
      setError(err.message || "Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <img src="/iubat.png" alt="IUBAT Logo" style={{ height: "60px", marginBottom: "10px" }} />
          <p style={{ fontSize: "14px", color: "#093C5D", fontWeight: "bold", margin: "0" }}>
            CREATE NEW PASSWORD
          </p>
        </div>

        <h2>🔑 Reset Password</h2>

        <form onSubmit={handleSubmit}>
          <input
            type={showPassword ? "text" : "password"}
            placeholder="New Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <input
            type={showPassword ? "text" : "password"}
            placeholder="Confirm Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
          />

          <div className="password-row">
            <label className="password-toggle">
              <input type="checkbox" checked={showPassword} onChange={() => setShowPassword(!showPassword)} />
              Show Password
            </label>
            {password ? <span className={`strength-${passwordStrength().toLowerCase()}`}>{passwordStrength()}</span> : null}
          </div>

          {error ? <p className="auth-message auth-error">{error}</p> : null}
          {message ? <p className="auth-message auth-success">{message}</p> : null}

          <button type="submit" disabled={loading}>
            {loading ? "Updating..." : "Reset Password"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default ResetPassword;
