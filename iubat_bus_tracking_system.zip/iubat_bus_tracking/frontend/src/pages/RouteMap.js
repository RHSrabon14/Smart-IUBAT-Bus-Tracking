import { useState, useEffect } from "react";
import axios from "axios";
import LiveBusMap from "../components/LiveBusMap";
import { API_BASE_URL } from "../utils/api";

const resolveRouteBusId = (route) => {
  return route?.busId ? String(route.busId).trim() : "";
};

function RouteMap() {
  const [routes, setRoutes] = useState([]);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchRoutes();
  }, []);

  useEffect(() => {
    if (!selectedRoute) {
      setSelectedLocation(null);
      return;
    }

    const busId = resolveRouteBusId(selectedRoute);
    const fetchLocation = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/api/location/${busId}`);
        setSelectedLocation(response.data.data);
      } catch (err) {
        setSelectedLocation(null);
      }
    };

    fetchLocation();
    const interval = setInterval(fetchLocation, 5000);
    return () => clearInterval(interval);
  }, [selectedRoute]);

  const fetchRoutes = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/api/routes`);
      const data = response.data.data || response.data;
      setRoutes(Array.isArray(data) ? data : []);
      setLoading(false);
    } catch (err) {
      setError("Unable to load routes. Please try again.");
      setLoading(false);
    }
  };

  const filteredRoutes = routes.filter((route) =>
    route.routeName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleRouteSelect = (route) => {
    setSelectedRoute(route);
  };

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        <div style={styles.header}>
          <img src="/iubat.png" alt="IUBAT Logo" style={styles.logo} />
          <div>
            <p style={styles.subtitle}>IUBAT Bus Tracking</p>
            <h1 style={styles.title}>Route-wise Bus Tracking</h1>
            <p style={styles.description}>
              Explore all routes, track buses, and view route details in one place.
            </p>
          </div>
        </div>

        <div style={styles.searchContainer}>
          <input
            type="text"
            placeholder="Search routes..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={styles.searchInput}
          />
        </div>

        <div style={styles.mainContent}>
          <div style={styles.routesSection}>
            <div style={styles.routesHeader}>
              <h2 style={styles.sectionTitle}>All Routes</h2>
              <p style={styles.sectionInfo}>Select a route to see live tracking details.</p>
              {loading && <p>Loading routes...</p>}
              {error && <p style={{ color: "red" }}>{error}</p>}
            </div>
            <div style={styles.routesGrid}>
              {filteredRoutes.map((route) => (
                <button
                  key={route._id}
                  onClick={() => handleRouteSelect(route)}
                  style={{
                    ...styles.routeCard,
                    borderColor: selectedRoute && selectedRoute._id === route._id ? "#1F8EF1" : "#e0e0e0",
                    backgroundColor: selectedRoute && selectedRoute._id === route._id ? "#1F8EF1" : "#ffffff",
                    color: selectedRoute && selectedRoute._id === route._id ? "#ffffff" : "#333333",
                  }}
                >
                  <span style={styles.busIcon}>🚌</span>
                  <div>
                    <div style={styles.busNumber}>Bus {route.busNo}</div>
                    <span style={styles.routeName}>{route.routeName}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div style={styles.sidePanel}>
            <div style={styles.mapCard}>
              <div style={styles.mapHeader}>
                <div>
                  <p style={styles.mapLabel}>Map Preview</p>
                  <h3 style={styles.mapTitle}>Route Map</h3>
                </div>
                <span style={styles.mapBadge}>{selectedRoute ? selectedRoute.routeName : "No route selected"}</span>
              </div>
              <div style={styles.mapBox}>
                {selectedRoute ? (
                  <LiveBusMap
                    busId={resolveRouteBusId(selectedRoute)}
                    title={`${selectedRoute.routeName}`}
                    subtitle={`Bus ${selectedRoute.busNo}`}
                  />
                ) : (
                  <div>
                    <p style={styles.mapPlaceholderTitle}>Route map placeholder</p>
                    <p style={styles.mapPlaceholderText}>Pick a route from the left panel to preview the live map.</p>
                  </div>
                )}
              </div>
            </div>

            <div style={styles.detailsPanel}>
              <h3 style={styles.panelTitle}>Route Details</h3>
              <div style={styles.detailRow}>
                <span>Bus Number</span>
                <strong>{selectedRoute ? selectedRoute.busNo : "Select a route"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Route Name</span>
                <strong>{selectedRoute ? selectedRoute.routeName : "Select a route"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Time</span>
                <strong>{selectedRoute ? selectedRoute.time : "N/A"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Stops</span>
                <strong>{selectedRoute ? "8 stops" : "N/A"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Next Departure</span>
                <strong>{selectedRoute ? "5 mins" : "N/A"}</strong>
              </div>
              <div style={styles.detailRow}>
                <span>Direction</span>
                <strong>{selectedRoute ? "Campus inbound" : "N/A"}</strong>
              </div>
            </div>

            <div style={styles.statusPanel}>
              <div style={styles.statusHeader}>
                <h3 style={styles.panelTitle}>Bus Tracking</h3>
                <p style={styles.statusNote}>Live GPS data from backend</p>
              </div>
              <div style={styles.statusCard}>
                <div style={styles.statusItem}>
                  <span>Bus Number</span>
                  <strong>{selectedRoute ? selectedRoute.busNo : "N/A"}</strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Current Location</span>
                  <strong>
                    {selectedLocation && selectedLocation.currentLocation
                      ? `${selectedLocation.currentLocation.latitude.toFixed(4)}, ${selectedLocation.currentLocation.longitude.toFixed(4)}`
                      : selectedRoute
                      ? `${selectedRoute.routeName} area`
                      : "N/A"}
                  </strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Last Update</span>
                  <strong>
                    {selectedLocation && selectedLocation.currentLocation?.timestamp
                      ? new Date(selectedLocation.currentLocation.timestamp).toLocaleTimeString()
                      : "N/A"}
                  </strong>
                </div>
                <div style={styles.statusItem}>
                  <span>Status</span>
                  <strong>{selectedLocation ? "On route" : "Waiting"}</strong>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: {
    minHeight: "100vh",
    backgroundColor: "#eef4fb",
    padding: "24px",
  },
  container: {
    maxWidth: "1320px",
    margin: "0 auto",
    backgroundColor: "#ffffff",
    borderRadius: "24px",
    boxShadow: "0 20px 60px rgba(31, 142, 241, 0.12)",
    padding: "32px",
  },
  header: {
    display: "flex",
    alignItems: "center",
    gap: "20px",
    flexWrap: "wrap",
    marginBottom: "28px",
  },
  logo: {
    width: "90px",
    height: "90px",
    borderRadius: "18px",
    objectFit: "cover",
    border: "2px solid #1F8EF1",
    padding: "8px",
    backgroundColor: "#fff",
  },
  subtitle: {
    margin: 0,
    color: "#1F8EF1",
    fontWeight: 700,
    letterSpacing: "0.08em",
  },
  title: {
    margin: "8px 0 10px",
    fontSize: "2.6rem",
    color: "#162E4D",
  },
  description: {
    margin: 0,
    color: "#4d5c6e",
    maxWidth: "680px",
    lineHeight: 1.6,
  },
  searchContainer: {
    marginBottom: "28px",
    textAlign: "center",
  },
  searchInput: {
    width: "100%",
    maxWidth: "460px",
    padding: "14px 18px",
    borderRadius: "14px",
    border: "1px solid #d9e4f5",
    fontSize: "1rem",
    outline: "none",
    boxShadow: "0 6px 18px rgba(31, 142, 241, 0.08)",
  },
  mainContent: {
    display: "grid",
    gridTemplateColumns: "1.05fr 1fr",
    gap: "28px",
    alignItems: "start",
  },
  routesSection: {
    backgroundColor: "#fbfcff",
    borderRadius: "20px",
    padding: "24px",
    boxShadow: "0 8px 30px rgba(31, 142, 241, 0.08)",
  },
  routesHeader: {
    marginBottom: "18px",
  },
  sectionTitle: {
    margin: 0,
    fontSize: "1.7rem",
    color: "#10284d",
  },
  sectionInfo: {
    margin: "10px 0 0",
    color: "#5f6c7b",
  },
  routesGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: "16px",
  },
  routeCard: {
    border: "2px solid #e0e8f7",
    borderRadius: "18px",
    padding: "22px",
    cursor: "pointer",
    transition: "transform 0.25s ease, border-color 0.25s ease",
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
    justifyContent: "center",
    minHeight: "120px",
    textAlign: "left",
  },
  busIcon: {
    fontSize: "1.9rem",
    marginBottom: "12px",
  },
  busNumber: {
    fontSize: "1.2rem",
    fontWeight: 700,
    marginBottom: "4px",
  },
  routeName: {
    fontSize: "1rem",
    fontWeight: 500,
  },
  sidePanel: {
    display: "grid",
    gap: "22px",
  },
  mapCard: {
    backgroundColor: "#ffffff",
    borderRadius: "22px",
    padding: "22px",
    border: "1px solid #e8eff9",
    boxShadow: "0 14px 35px rgba(31, 142, 241, 0.08)",
  },
  mapHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: "12px",
    alignItems: "flex-start",
    marginBottom: "18px",
  },
  mapLabel: {
    margin: 0,
    fontSize: "0.95rem",
    color: "#1F8EF1",
    fontWeight: 700,
    letterSpacing: "0.04em",
    textTransform: "uppercase",
  },
  mapTitle: {
    margin: "6px 0 0",
    fontSize: "1.4rem",
    color: "#152840",
  },
  mapBadge: {
    backgroundColor: "#eaf5ff",
    color: "#1f6ccb",
    borderRadius: "999px",
    padding: "10px 14px",
    fontSize: "0.9rem",
    fontWeight: 700,
  },
  mapBox: {
    minHeight: "360px",
    borderRadius: "18px",
    backgroundColor: "#f4f8ff",
    border: "1px dashed #c8daf4",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    padding: "28px",
    color: "#243b5b",
  },
  mapPlaceholderTitle: {
    margin: 0,
    fontSize: "1.3rem",
    fontWeight: 700,
  },
  mapPlaceholderText: {
    margin: "10px 0 0",
    color: "#56677f",
  },
  detailsPanel: {
    backgroundColor: "#f7fbff",
    borderRadius: "22px",
    padding: "22px",
    border: "1px solid #e5effa",
  },
  statusPanel: {
    backgroundColor: "#ffffff",
    borderRadius: "22px",
    padding: "22px",
    border: "1px solid #e8eff9",
  },
  panelTitle: {
    margin: "0 0 14px",
    fontSize: "1.25rem",
    color: "#12243a",
  },
  detailRow: {
    display: "flex",
    justifyContent: "space-between",
    gap: "24px",
    marginBottom: "18px",
    color: "#4d5c74",
  },
  statusHeader: {
    marginBottom: "16px",
  },
  statusNote: {
    margin: 0,
    color: "#6b7b92",
    fontSize: "0.95rem",
  },
  statusCard: {
    display: "grid",
    gap: "16px",
    backgroundColor: "#eef5ff",
    borderRadius: "18px",
    padding: "20px",
  },
  statusItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "16px",
    padding: "14px 18px",
    borderRadius: "16px",
    backgroundColor: "#ffffff",
    boxShadow: "0 2px 18px rgba(31, 142, 241, 0.08)",
    color: "#293c5f",
  },
};

export default RouteMap;
