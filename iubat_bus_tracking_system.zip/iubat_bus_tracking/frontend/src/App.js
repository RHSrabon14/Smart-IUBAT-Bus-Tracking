import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import MapPage from "./pages/MapPage";
import Schedule from "./pages/Schedule";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import ProtectedRoute from "./components/ProtectedRoute";

import StudentLogin from "./pages/StudentLogin";
import FacultyLogin from "./pages/FacultyLogin";
import LoginChoice from "./pages/LoginChoice";
import ForgotPassword from "./pages/ForgotPassword";
import VerifyOTP from "./pages/VerifyOTP";
import ResetPassword from "./pages/ResetPassword";

/* ✅ ADMIN */
import AdminLogin from "./pages/AdminLogin";
import AdminPanel from "./pages/AdminPanel";

/* ✅ ROUTE SELECT PAGE */
import RouteSelect from "./pages/RouteSelect";
import RouteMap from "./pages/RouteMap";
import ShuttleDetails from "./pages/ShuttleDetails";

/* ✅ NEW: SHUTTLE ROUTES PAGE */
import ShuttleRoutes from "./pages/ShuttleRoutes";
import ShuttleRouteTracking from "./pages/ShuttleRouteTracking";
import LostFound from "./pages/LostFound";
import Alerts from "./pages/Alerts";
import FAQ from "./pages/FAQ";

function App() {
  return (
    <Router>

      {/* NAVBAR ALWAYS VISIBLE */}
      <Navbar />

      <Routes>

        {/* ================= MAIN PAGES ================= */}
        <Route path="/" element={<Home />} />

        <Route
          path="/map"
          element={
            <ProtectedRoute>
              <MapPage />
            </ProtectedRoute>
          }
        />

        <Route
          path="/schedule"
          element={
            <ProtectedRoute>
              <Schedule />
            </ProtectedRoute>
          }
        />

        {/* ================= LOGIN ================= */}
        <Route path="/login-choice" element={<LoginChoice />} />
        <Route path="/student-login" element={<StudentLogin />} />
        <Route path="/faculty-login" element={<FacultyLogin />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/verify-otp" element={<VerifyOTP />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* ================= ADMIN ================= */}
        <Route path="/admin-login" element={<AdminLogin />} />

        <Route
          path="/admin-dashboard"
          element={
            localStorage.getItem("adminToken")
              ? <AdminPanel />
              : <AdminLogin />
          }
        />

        {/* ================= ROUTE SELECT ================= */}
        <Route
          path="/route-select"
          element={
            <ProtectedRoute>
              <RouteSelect />
            </ProtectedRoute>
          }
        />

        <Route
          path="/route-map"
          element={
            <ProtectedRoute>
              <RouteMap />
            </ProtectedRoute>
          }
        />

        {/* ================= SHUTTLE ROUTES ================= */}
        <Route
          path="/shuttle"
          element={
            <ProtectedRoute>
              <ShuttleRoutes />
            </ProtectedRoute>
          }
        />

        <Route
          path="/shuttle-details"
          element={
            <ProtectedRoute>
              <ShuttleDetails />
            </ProtectedRoute>
          }
        />

        <Route
          path="/shuttle-route-tracking"
          element={
            <ProtectedRoute>
              <ShuttleRouteTracking />
            </ProtectedRoute>
          }
        />

        <Route
          path="/morning-routes"
          element={
            <ProtectedRoute>
              <ShuttleRouteTracking category="Morning" />
            </ProtectedRoute>
          }
        />

        <Route
          path="/evening-routes"
          element={
            <ProtectedRoute>
              <ShuttleRouteTracking category="Evening" />
            </ProtectedRoute>
          }
        />

        <Route
          path="/shuttle-routes"
          element={
            <ProtectedRoute>
              <ShuttleRouteTracking category="Shuttle" />
            </ProtectedRoute>
          }
        />

        <Route path="/lost-found" element={<LostFound />} />
        <Route path="/alerts" element={<Alerts />} />
        <Route path="/faq" element={<FAQ />} />

      </Routes>

      <Footer />

    </Router>
  );
}

export default App;