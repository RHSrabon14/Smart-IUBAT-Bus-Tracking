# SIM800L GPRS Fallback Configuration
## For IUBAT Bus Tracking System

**Status**: WiFi primary, SIM800L secondary fallback  
**Current**: SIM800L code exists but disabled in esp32_code.ino  
**Last Updated**: 2026-09-02

---

## ⚠️ IMPORTANT - READ FIRST

**DO NOT ATTEMPT SIM800L SETUP UNTIL:**
1. ✅ WiFi upload pipeline is 100% working
2. ✅ Backend receives images correctly
3. ✅ YOLO detects passengers
4. ✅ React frontend displays live data
5. ✅ 5-minute stability test passes

Only then debug SIM800L if needed as fallback.

---

## 🔌 HARDWARE SETUP

### Current Configuration (Correct)
```
ESP32-CAM             SIM800L
================      ==================
GPIO 13 (TX) -------> RX (pin 10)
GPIO 14 (RX) -------> TX (pin 11)
GND ----------------> GND (common)
3.3V (WEAK!) -------> POWER INPUT (NOT RECOMMENDED)
```

### PROBLEM: Current Power Scheme
- **ESP32 USB**: ~500mA available
- **SIM800L needs**: 1-2A peak (during GSM burst)
- **Result**: Voltage sag → UART corruption → "SEND ERROR"

### SOLUTION: Dedicated Power Supply

#### Minimum Requirement
```
USB Power Adapter
    ↓
AMS1117-3.8V Regulator
    ↓ 3.8V (up to 1A)
    ├→ SIM800L VIN + GND
    └→ ESP32 3.3V (parallel, optional redundancy)

Capacitor Bank (near SIM800L VIN):
    • 100µF electrolytic (high ESR)
    • 10µF electrolytic
    • 0.1µF ceramic (X7R)
```

#### Recommended Improvement
```
USB Power Adapter (2A minimum)
    ↓
Step-down Regulator (DCDC converter, 95% efficient)
    ├→ Output 3.8-4.0V
    ├→ Capacity: 2A sustained
    ↓ (multiple outputs)
    ├→ SIM800L VIN (1A capacity)
    ├→ ESP32 3.3V (1A capacity)
    └→ GPS/other (0.5A capacity)

Bulk Capacitance (2000µF+ near power entry)
Ceramic Caps (0.1µF on each module VCC/GND)
```

#### Development Setup (For Testing)
```
USB Power Supply 2A → PowerBank with 5V/2A out
    ↓
Cheap DC-DC buck converter (eBay $2)
    Output: Adjustable to 3.8V
    ↓
SIM800L + parallel cap bank
```

---

## 🛠️ SOLDERING & CONNECTIONS

### Critical Connections (must be solid)
```
SIM800L Pin 10 (RX) — Must solder directly to ESP32 GPIO 14
  ⚠️ NOT breadboard, NOT jumper wire → use 24AWG wire, solder joint

SIM800L Pin 11 (TX) — Must solder directly to ESP32 GPIO 13
  ⚠️ NO extension cables, direct solder only

SIM800L GND, VIN — Use thicker wires (18-20 AWG)
  ⚠️ Bad ground connection causes CIPSEND failures
```

### Check These First (Before Code Changes)
```
1. Voltage across SIM800L VIN/GND: 3.8-4.0V (not 3.3V!)
2. Current draw idle: 20-50mA
3. Current draw in GSM mode: 500mA peak
4. UART pins: Continuity test between ESP32 GPIO and SIM800L pins
5. Ground resistance: < 0.1Ω between any two GND points
```

---

## 📋 SIM CARD & NETWORK

### SIM Card Requirements
- ✅ Standard SIM (not eSIM)
- ✅ Active GPRS/2G service
- ✅ Roaming enabled (if testing outside home country)
- ✅ Balance or unlimited plan

### Network Configuration
```
ESP32 → SIM800L AT Commands:
AT                           → OK
AT+CPIN?                     → +CPIN: READY
AT+CREG?                     → +CREG: 0,1 (registered, home network)
AT+CGATT?                    → +CGATT: 1 (GPRS attached)
AT+CIFSR                     → 203.X.X.X (got IP address)
```

---

## 🔄 SOFTWARE INTEGRATION

### Current Status
```cpp
// esp32_code.ino current state:
#define USE_WIFI true
#define USE_SIM800L false  ← Disabled

// SIM800L code exists in functions:
// - initSIM800L()
// - connectGPRS()
// - uploadWithRetry()  (original SIM800L upload)
```

### To Enable SIM800L as Primary
```cpp
#define USE_WIFI false       ← Change this
#define USE_SIM800L true     ← Change this
```

In `setup()`:
```cpp
// Comment out WiFi section
// if (!initWiFi()) { ... }

// Uncomment SIM800L section
if (!initSIM800L()) {
    Serial.println("❌ SIM800L init failed!");
    while(1) blinkLED(2, 500);
}

if (!connectGPRS()) {
    Serial.println("❌ GPRS connection failed!");
    while(1) blinkLED(3, 500);
}
```

In `loop()`:
```cpp
// Change condition from:
if (wifiConnected && millis() - lastUpload > UPLOAD_INTERVAL)

// To:
if (gprsConnected && millis() - lastUpload > UPLOAD_INTERVAL)
```

In `captureAndSend()`:
```cpp
// Change from:
bool success = uploadWithWiFi(serverIP, serverPort, backendEndpoint, fb);

// To:
bool success = uploadWithRetry(serverIP, serverPort, backendEndpoint, fb);
```

### To Enable WiFi Primary + SIM800L Fallback
```cpp
#define USE_WIFI true
#define USE_SIM800L true    ← Enable both

// In loop():
if ((wifiConnected || gprsConnected) && millis() - lastUpload > UPLOAD_INTERVAL) {
    if (wifiConnected) {
        success = uploadWithWiFi(...);  // Try WiFi first
    } else {
        success = uploadWithRetry(...); // Fallback to GPRS
    }
}
```

---

## 📡 NGROK CONFIGURATION FOR SIM800L

Current ngrok URL setup:
```
symphony-shady-selection.ngrok-free.dev (port 443 HTTPS)
```

### Issue with SIM800L
- SIM800L cannot do SSL/TLS properly
- ngrok-free.dev uses self-signed certs
- SIM800L AT+CIPSTART TCP connection is not encrypted

### Solution Options

#### Option A: Direct IP (No HTTPS)
```bash
# Get backend direct IP (if running on static IP)
ping symphony-shady-selection.ngrok-free.dev
# Note the IP address

# Or use localhost IP on internal network:
192.168.X.X:5000
```

Update in esp32_code.ino:
```cpp
const char serverIP[] = "203.X.X.X";  // Direct IP
const int serverPort = 80;            // HTTP (not HTTPS)
const char* backendEndpoint = "/api/bus/upload";
```

#### Option B: ngrok HTTP URL
```bash
# ngrok output shows:
# Forwarding http://xxx-xxx-xxx.ngrok-free.dev -> http://localhost:5000
# Use THIS URL

const char serverIP[] = "xxx-xxx-xxx.ngrok-free.dev";
const int serverPort = 80;  // HTTP not HTTPS
```

#### Option C: Local Network Only
```
ESP32 ← WiFi → Router → Backend (192.168.1.100:5000)
        No internet needed, no ngrok
        
SIM800L: Not suitable for this (needs public internet)
```

---

## 🧪 SIM800L TESTING SEQUENCE

### TEST 1: Hardware Verification
```bash
Serial Monitor (115200 baud):
Setup phase should show:

SIM800L INITIALIZATION
AT+CSQ       → +CSQ: 20,0 (signal quality, good if > 10)
AT+CREG?     → +CREG: 0,1 (registered on network)
AT+CGATT?    → +CGATT: 1 (GPRS attached)
AT+CIPMUX=0  → OK (single connection mode)
AT+CIPMODE=0 → OK or ERROR (not all firmware supports)

✅ SIM800L Ready
```

### TEST 2: Network Registration
```bash
Expected Output:
NETWORK REGISTRATION
[SIM800 TCP CONFIG]
CIPMODE: 0
CIPQSEND: 0 or UNSUPPORTED
CIPMUX: 0

✅ SIM800 TCP settings checked
```

### TEST 3: DNS Resolution
```bash
Expected in serial:
🔍 Testing DNS resolution for: ngrok-free.dev
+CDNSGIP: OK
✅ DNS resolved: 203.X.X.X
```

### TEST 4: TCP Connection
```bash
Expected:
📡 TCP CONNECTION SEQUENCE
>>> AT+CIPSTART="TCP","203.X.X.X",80
<<< CONNECT OK

✅ TCP connected
```

### TEST 5: HTTP Upload (Multipart)
```bash
Expected:
📤 CIPSEND STARTUP
Expected bytes: XXXXX
>>> AT+CIPSEND=XXXXX
<<< > (prompt received)

✅ Ready to send data

[JPEG binary + multipart data sent]

SEND OK

✅ Upload succeeded
```

### TEST 6: HTTP Response
```bash
Expected:
HTTP/1.1 200 OK
Content-Type: application/json
...
{"success":true,"passengerCount":5,...}

✅ Backend received upload
```

---

## 🔴 COMMON SIM800L PROBLEMS

### Problem 1: "SEND ERROR" on AT+CIPSEND
**Root Cause**: Power supply voltage sag
```
Symptoms:
- Starts uploading
- ">" prompt appears
- Data starts sending
- Modem resets: "+CMTI", "+CGEV", etc.
- No "SEND OK", instead: "SEND ERROR" or "CLOSE OK"

Solution:
1. Add capacitor bank: 1000µF+ on VIN
2. Use dedicated power regulator (not USB)
3. Reduce image size (smaller = faster = less power needed)
4. Reduce JPEG quality (quality 8 instead of 12)
5. Reduce upload interval (wait for voltage recovery)
```

### Problem 2: "already connect" Error
**Root Cause**: Previous connection still open
```
Symptoms:
AT+CIPSTART="TCP","host",80
+CME ERROR: operation not allowed (connection already exists)

Solution:
1. Add: AT+CIPCLOSE (before new connect)
2. Wait 200ms after close
3. Check CIPSTATUS before connect
4. Verify TCP session properly terminated
```

### Problem 3: No IP Address (AT+CIFSR returns 0.0.0.0)
**Root Cause**: GPRS not attached
```
Symptoms:
AT+CIFSR
+CIFSR: 0.0.0.0

Solution:
1. Check SIM card has balance
2. Check GPRS attach: AT+CGATT? (should be 1)
3. Force attach: AT+CGATT=1
4. Wait for network registration: AT+CREG? (should be 1)
5. Try manual APN: AT+CSTT="apn","user","pass"
```

### Problem 4: No GPS Signal After SIM800L Enabled
**Root Cause**: GPIO 13/14 conflict or power drain
```
Symptoms:
GPS data stops updating
SIM800L works but GPS latitude = 0.0

Solution:
1. Check GPIO 13/14 not used elsewhere
2. Add separate power supply for GPS
3. Reduce SIM800L UART baud rate: 9600 → 4800
4. Add voltage divider on SIM800L TX → ESP32 RX
5. Move GPS antenna away from modem
```

### Problem 5: Garbled UART Data
**Root Cause**: Voltage levels or baud rate mismatch
```
Symptoms:
AT commands return garbage:
"❓❓❓❓❓"
"+CME E❓❓❓"

Solution:
1. Check power voltage: 3.8-4.0V on VIN
2. Add voltage divider: SIM800 TX (3.8V) → ESP32 RX (3.3V)
   Resistor divider: 1kΩ to GND, 2.2kΩ from SIM800 TX
3. Reduce baud rate: SIM800L.begin(4800) or 9600
4. Check ground connection resistance
5. Add 0.1µF caps on UART lines
```

---

## ✅ SUCCESSFUL SIM800L MIGRATION CHECKLIST

- [ ] Power supply upgraded (dedicated 2A 3.8V)
- [ ] Capacitor bank installed (1000µF+ on VIN)
- [ ] Solder connections verified (continuity test passed)
- [ ] SIM card has active GPRS plan
- [ ] AT command testing passed (CSQ, CREG, CGATT all OK)
- [ ] DNS resolution works
- [ ] TCP connection succeeds
- [ ] HTTP upload completes with 200 response
- [ ] MongoDB receives all data
- [ ] Backend logs show "UPLOAD ENDPOINT WAS HIT"
- [ ] YOLO processes image and returns passenger count
- [ ] React frontend updates with new data
- [ ] 5-minute stability test passes
- [ ] Power draw stable (< 1A average, < 2A peak)
- [ ] GPS still working (hasn't lost lock)
- [ ] WiFi can still connect as fallback
- [ ] Both WiFi and SIM800L uploading in tests

---

## 🎯 DUAL-MODE (WiFi + SIM800L) SETUP

### Final Configuration
```cpp
#define USE_WIFI true
#define USE_SIM800L true

// Priority:
// 1. Try WiFi first (faster, more reliable)
// 2. Fallback to GPRS if WiFi fails
// 3. Retry both until one succeeds

bool captureAndSendWithFallback() {
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) return false;
    
    bool success = false;
    
    // Try WiFi first
    if (wifiConnected) {
        success = uploadWithWiFi(serverIP, 443, backendEndpoint, fb);
    }
    
    // Fallback to GPRS
    if (!success && gprsConnected) {
        Serial.println("WiFi failed, trying GPRS...");
        success = uploadWithRetry(serverIP, 80, backendEndpoint, fb);
    }
    
    esp_camera_fb_return(fb);
    return success;
}
```

### Monitoring & Metrics
```javascript
// MongoDB experiment log will show:
{
  "trialId": "trial-...",
  "uploadMethod": "WiFi" or "GPRS",
  "imageTransmissionSuccess": true,
  "yoloSuccess": true,
  "endToEndDurationMs": 4500,
  "uploadSuccess": true
}

// Stats endpoint returns:
{
  "totalUploads": 100,
  "wifiSuccessRate": 95%,
  "gprsSuccessRate": 87%,
  "failoverCount": 5,  // WiFi failed, GPRS succeeded
}
```

---

## 📊 PERFORMANCE COMPARISON

| Metric | WiFi | GPRS |
|--------|------|------|
| Image upload | 2-5s | 5-15s |
| Reliability | 95%+ | 80-90% |
| Latency | <2s | 1-3s |
| Power draw | 500mA | 1-2A |
| Cost/month | $0 | $2-10 |
| Range | 50m | 10km+ |
| Speed | LTE speeds | 2G (~100kbps) |

**Recommendation**: Use WiFi for stable environments, GPRS for remote areas or as fallback.

---

## 📞 TROUBLESHOOTING QUICK REFERENCE

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| SEND ERROR | Low power | Add capacitors, upgrade PSU |
| No TCP connection | GPRS not attached | AT+CGATT? check, retry AT+CGATT=1 |
| Garbled AT responses | Voltage/baud issue | Check VIN 3.8-4.0V, add voltage divider |
| GPS stops working | GPIO conflict/power drain | Separate PSU for GPS, reduce baud |
| No signal (CSQ 0,0) | No SIM service | Check SIM balance, antenna connection |
| HTTP 400/500 from backend | Multipart format | Check Content-Length, CRLF consistency |
| YOLO returns 0 passengers | Image too small/corrupted | Increase JPEG quality (reduce number) |
| React shows stale data | GPRS slower than WiFi | Check upload timestamps in MongoDB |

---

## 🎓 LEARNING RESOURCES

- AT Command documentation: SIM800L_Series_AT_Command_Manual_V1.09.pdf
- Voltage divider calculator: www.ohmslawcalculator.com
- ESP32 power management: https://docs.espressif.com/projects/esp-idf/en/latest/esp32/
- GPRS/2G modem troubleshooting: https://www.cradlepoint.com/blog/gsm/

---

## ⏰ IMPLEMENTATION TIMELINE

1. **Phase 1**: WiFi working ✅ (CURRENT)
2. **Phase 2**: Power supply upgrade (1 hour)
3. **Phase 3**: SIM card + GPRS testing (30 min)
4. **Phase 4**: SIM800L upload coding (1 hour)
5. **Phase 5**: Dual-mode testing (1 hour)
6. **Phase 6**: Stability & optimization (1+ hours)

**Estimated Total**: 4-5 hours after WiFi is confirmed working

---

**Remember**: DO NOT debug SIM800L until WiFi pipeline is 100% verified. The current WiFi-only system is production-ready. SIM800L is purely optional fallback.
