# IUBAT Bus Tracking System - Database Design

## MongoDB Collections

### 1. Buses Collection
```javascript
{
  _id: ObjectId,
  busId: "BUS_001", // Unique identifier
  busNumber: "Dhaka-01",
  driverName: "John Doe",
  capacity: 50,
  status: "active", // active, inactive, maintenance
  currentLocation: {
    latitude: 23.7937,
    longitude: 90.4066,
    timestamp: ISODate("2024-01-01T10:00:00Z")
  },
  createdAt: ISODate("2024-01-01T00:00:00Z"),
  updatedAt: ISODate("2024-01-01T10:00:00Z")
}
```

**Indexes:**
- `{ busId: 1 }` (unique)
- `{ status: 1 }`

### 2. ShuttleRoutes Collection (formerly Routes)
```javascript
{
  _id: ObjectId,
  busNo: "BUS_001",
  routeName: "IUBAT to Uttara",
  time: "08:00 AM",
  type: "shuttle", // shuttle, all
  createdAt: ISODate("2024-01-01T00:00:00Z"),
  updatedAt: ISODate("2024-01-01T10:00:00Z")
}
```

**Indexes:**
- `{ type: 1 }`
- `{ createdAt: -1 }`

### 3. Locations Collection
```javascript
{
  _id: ObjectId,
  busId: "BUS_001",
  latitude: 23.7937,
  longitude: 90.4066,
  timestamp: ISODate("2024-01-01T10:00:00Z"),
  speed: 45.5, // km/h
  accuracy: 5.0, // HDOP
  createdAt: ISODate("2024-01-01T10:00:00Z")
}
```

**Indexes:**
- `{ busId: 1, timestamp: -1 }` (compound index for efficient queries)
- `{ timestamp: -1 }`

### 4. Admins Collection
```javascript
{
  _id: ObjectId,
  username: "admin",
  email: "admin@iubat.edu",
  password: "<bcrypt-hash>", // bcrypt hashed
  createdAt: ISODate("2024-01-01T00:00:00Z")
}
```

### 5. Students Collection
```javascript
{
  _id: ObjectId,
  studentId: "STU001",
  name: "Jane Doe",
  email: "jane@iubat.edu",
  password: "<bcrypt-hash>", // bcrypt hashed
  department: "CSE",
  createdAt: ISODate("2024-01-01T00:00:00Z")
}
```

### 6. Faculty Collection
```javascript
{
  _id: ObjectId,
  facultyId: "FAC001",
  name: "Dr. Smith",
  email: "smith@iubat.edu",
  password: "<bcrypt-hash>", // bcrypt hashed
  department: "CSE",
  createdAt: ISODate("2024-01-01T00:00:00Z")
}
```

## Relationships

- **Bus ↔ Location**: One-to-many (one bus has many location updates)
- **Bus ↔ ShuttleRoute**: Many-to-one (many buses can serve one route)
- **Admin → All Collections**: Admin can manage all data
- **Student/Faculty → Routes**: Read-only access to routes

## Indexing Strategy

1. **Location queries**: Compound index on `(busId, timestamp)` for fast location history retrieval
2. **Active buses**: Index on `status` for filtering active buses
3. **Route types**: Index on `type` for filtering shuttle vs all routes
4. **Authentication**: Index on `email` for login queries

## Data Validation

- Bus IDs must be unique
- GPS coordinates must be valid numbers
- Timestamps must be valid ISO dates
- Passwords are hashed using bcrypt
- Required fields are enforced at schema level

## Example Documents

### Sample Bus Document
```javascript
{
  "_id": ObjectId("507f1f77bcf86cd799439011"),
  "busId": "BUS_001",
  "busNumber": "Dhaka Metro-01",
  "driverName": "Ahmed Rahman",
  "capacity": 45,
  "status": "active",
  "currentLocation": {
    "latitude": 23.7937,
    "longitude": 90.4066,
    "timestamp": ISODate("2024-01-15T08:30:00Z")
  },
  "createdAt": ISODate("2024-01-01T00:00:00Z"),
  "updatedAt": ISODate("2024-01-15T08:30:00Z")
}
```

### Sample Location Document
```javascript
{
  "_id": ObjectId("507f1f77bcf86cd799439012"),
  "busId": "BUS_001",
  "latitude": 23.7937,
  "longitude": 90.4066,
  "timestamp": ISODate("2024-01-15T08:30:00Z"),
  "speed": 35.2,
  "accuracy": 3.5,
  "createdAt": ISODate("2024-01-15T08:30:00Z")
}
```

### Sample Shuttle Route Document
```javascript
{
  "_id": ObjectId("507f1f77bcf86cd799439013"),
  "busNo": "BUS_001",
  "routeName": "IUBAT Campus to Uttara",
  "time": "07:30 AM - 08:30 AM",
  "type": "shuttle",
  "createdAt": ISODate("2024-01-01T00:00:00Z"),
  "updatedAt": ISODate("2024-01-01T00:00:00Z")
}
```