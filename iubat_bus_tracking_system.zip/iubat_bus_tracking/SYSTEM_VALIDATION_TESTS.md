# IUBAT Bus Tracking System - Comprehensive System Validation

## Complete End-to-End Testing Protocol

**Last Updated**: 2026-09-02  
**System Status**: Ready for Integration Testing  
**Test Duration**: ~15 minutes full test

---

## 🎯 PRE-TEST CHECKLIST

Before running any tests, verify:

- [ ] All services configured (see ENVIRONMENT_SETUP.md)
- [ ] MongoDB running or Atlas connected
- [ ] Backend npm install completed
- [ ] YOLO Python environment activated
- [ ] ngrok tunnel active
- [ ] ESP32 uploaded with latest code
- [ ] Serial monitor ready at 115200 baud
- [ ] All 5 terminals open and ready

---

## 📝 UNIT TESTS (Isolated Component Verification)

### TEST 1.1: MongoDB Connection
**Location**: Run in terminal
```bash
mongosh
```
**Expected Output**:
```
test> 
```
**Action**:
```javascript
use iubat_bus_tracking
db.buses.countDocuments()
```
**Expected Result**: Returns `0` or higher (integer)  
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```bash
# Windows
mongod
# macOS
brew services start mongodb-community
# Linux
sudo systemctl start mongodb
```

---

### TEST 1.2: Backend HTTP Server
**Location**: Terminal running `npm start`
**Expected Output on startup**:
```
✅ MongoDB connected to: [MongoDB URL redacted]
✅ Server listening on port 5000
```
**Verify**: Open `http://localhost:5000/api/bus/data` in browser  
**Expected Response**:
```json
{
  "success": true,
  "data": []
}
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```bash
# Check port conflict
netstat -ano | findstr :5000
# Kill if needed
taskkill /PID xxxx /F
# Check MongoDB connection in backend logs
```

---

### TEST 1.3: YOLO Server
**Location**: Terminal running `python yolo_server.py`
**Expected Output on startup**:
```
📥 Loading YOLO AI model...
✅ YOLO model loaded successfully!
Running on http://0.0.0.0:5001
```
**Verify**: Call from another terminal
```bash
curl -X GET http://localhost:5001/
```
**Expected Response**: Flask default page or 404 (indicates server is running)  
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```bash
# Test YOLO import
python -c "from ultralytics import YOLO; print('OK')"
# If fails: pip install -r backend/yolo_server/requirements.txt
# Check port conflict
netstat -ano | findstr :5001
```

---

### TEST 1.4: ngrok Tunnel
**Location**: Terminal running `ngrok http 5000`
**Expected Output**:
```
Session Status                online
Account                       username
Version                       3.x.x
Web Interface                 http://127.0.0.1:4040
Forwarding                    https://xxx-xxx-xxx.ngrok-free.dev -> http://localhost:5000
Forwarding                    http://xxx-xxx-xxx.ngrok-free.dev -> http://localhost:5000
```
**Verify**: Open in browser: `https://xxx-xxx-xxx.ngrok-free.dev/api/bus/data`  
**Expected Response**:
```json
{
  "success": true,
  "data": []
}
```
**Status**: ✅ PASS / ❌ FAIL

**Update esp32_code.ino** with the HTTPS URL from output above.

---

### TEST 1.5: WiFi Network
**Expected**: SSID `[YOUR_WIFI_SSID]` is broadcasting  
**Action**: Check WiFi networks on ESP32 computer or phone  
**Expected Result**: "Admin" appears in list  
**Status**: ✅ PASS / ❌ FAIL

---

## 🔌 HARDWARE TESTS (ESP32-CAM)

### TEST 2.1: Serial Connection
**Action**: Connect ESP32 via USB, open serial monitor
```
COM Port: COMx (check Device Manager)
Baud Rate: 115200
```
**Expected Output**:
```
✅ GPS initialized
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```
- Check USB cable (data cable, not power-only)
- Check COM port number (Device Manager)
- Try different baud rates: 74880, 115200, 921600
- Check Arduino IDE board selection: AI Thinker ESP32-CAM
```

---

### TEST 2.2: GPS Fix
**Time**: Wait 10-30 seconds after serial connection  
**Expected Output** (in serial monitor):
```
📍 GPS DATA
📍 Latitude:  23.888138°
📍 Longitude: 90.390167°
📏 Altitude:  X.X m
🚗 Speed:     X.X km/h
🛰️  Satellites: 6+
✅ GPS Fixed: YES
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```
- GPS needs open sky view or window access
- May take 30-60 seconds for first fix
- Check GPS module is powered (LED blink?)
- Verify pins: RX=15, TX=16 (check solder joints)
- Test with GPS test code: examples/GpsTest
```

---

### TEST 2.3: Camera Capture
**Expected Output** (after 30 seconds):
```
📷 Initializing camera...
✅ Camera ready!
===== CAMERA CAPTURE =====
✅ Image captured: XXXX bytes
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```
- Camera must be connected (40-pin ribbon, silver contacts facing down)
- Check OV3660 lens cap removed
- Try camera examples from esp-idf
- Verify camera power (3.3V on pin)
```

---

### TEST 2.4: WiFi Connection
**Expected Output** (serial monitor):
```
📡 WiFi connecting to Admin...
✅ WiFi CONNECTED
📡 WiFi IP Address: 192.168.X.X
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
```
- Verify SSID is "[YOUR_WIFI_SSID]" (case-sensitive)
- Verify password is "[YOUR_WIFI_PASSWORD]"

- [ ] ESP32 connects to WiFi SSID "[YOUR_WIFI_SSID]"
```

---

## 📤 INTEGRATION TESTS (Component Interaction)

### TEST 3.1: WiFi HTTPS Upload
**Trigger**: Watch serial monitor for automatic upload (every 30 seconds)  
**Expected Serial Output**:
```
===== WiFi HTTPS UPLOAD SEQUENCE =====
Connected: YES (HTTPS established)
Bytes Sent: XXXX
===== ACTUAL SERVER RESPONSE =====
{"success":true,"passengerCount":X,...}
✅ HTTP 200-299 OK - Upload successful!
👥 PASSENGER COUNT: X
```
**Status**: ✅ PASS / ❌ FAIL

**Verify in Backend Logs**:
```
🔥🔥🔥 UPLOAD ENDPOINT WAS HIT! 🔥🔥🔥
📥 Received from ESP32-CAM:
   Bus ID: BUS-001
   Image: BUS-001_TIMESTAMP.jpg
   GPS: 23.888138, 90.390167
✅ Data saved to MongoDB
```
**Debug if FAIL** (HTTP error codes):
- **HTTP 400**: Field name mismatch → Check multipart form fields match backend schema
- **HTTP 404**: Endpoint not found → Verify ngrok URL and path `/api/bus/upload`
- **HTTP 500**: Backend error → Check backend logs for exception
- **No response**: Network issue → Verify WiFi connected, ngrok active
- **HTTPS fails**: Certificate error → Verify WiFiClientSecure.setInsecure() is called

---

### TEST 3.2: File Upload Verification
**Location**: Backend directory
```bash
ls backend/uploads/bus-images/
# Should show: BUS-001_TIMESTAMP.jpg
```
**Action**: Check file properties
```bash
ls -lh backend/uploads/bus-images/BUS-001_*.jpg
# Should show size between 5KB and 100KB
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
- Check directory permissions: `chmod 755 backend/uploads/bus-images/`
- Verify multer configuration in server.js
- Check disk space available

---

### TEST 3.3: YOLO Processing
**Location**: Backend console and YOLO server console  
**Expected Backend Log**:
```
🔄 Sending to YOLO for detection...
   YOLO URL: http://localhost:5001/detect
✅ YOLO Response received
   Passenger Count: X
   Total Detections: X
```
**Expected YOLO Console Output**:
```
📸 New image received!
💾 Image saved: uploads/capture_TIMESTAMP.jpg
🔍 Running YOLO detection...
👥 People detected: X
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
- YOLO server not running: `python yolo_server.py`
- Connection refused: Check YOLO_SERVER_URL in backend (.env or code)
- Model not loaded: Check yolov8n.pt exists in yolo_server directory
- Memory error: Verify 4GB+ available RAM
- Timeout: YOLO taking too long, reduce image size or increase timeout to 60s

---

### TEST 3.4: MongoDB Document Creation
**Location**: MongoDB Compass or mongosh  
**Action**: Query after upload
```javascript
use iubat_bus_tracking

// Check BusData collection
db.busdatas.findOne({ busId: "BUS-001" }, { sort: { createdAt: -1 } })

// Check Bus collection  
db.buses.findOne({ busId: "BUS-001" })

// Check Location collection
db.locations.findOne({ busId: "BUS-001" }, { sort: { timestamp: -1 } })
```
**Expected BusData Document**:
```json
{
  "_id": ObjectId(...),
  "busId": "BUS-001",
  "routeId": "ROUTE-01",
  "passengerCount": 5,        ← Updated by YOLO
  "latitude": 23.888138,
  "longitude": 90.390167,
  "speed": 1.3,
  "satellites": 6,
  "gpsFixed": true,
  "imagePath": "./uploads/bus-images/BUS-001_1693648800000.jpg",
  "imageUrl": "/uploads/bus-images/BUS-001_1693648800000.jpg",
  "imageSize": 12345,
  "processing": false,        ← Was true during processing
  "createdAt": ISODate(...),
  "updatedAt": ISODate(...)
}
```
**Expected Bus Document**:
```json
{
  "_id": ObjectId(...),
  "busId": "BUS-001",
  "busNumber": "BUS-001",
  "status": "active",
  "currentLocation": {
    "latitude": 23.888138,
    "longitude": 90.390167,
    "timestamp": ISODate(...)
  },
  "currentSpeed": 1.3,
  "currentPassengerCount": 5, ← Latest YOLO count
  "satellites": 6,
  "gpsFixed": true,
  "lastUpdated": ISODate(...),
  ...
}
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
- No documents: Check backend logs for save errors
- passengerCount is 0: YOLO failed, check YOLO server
- processing is still true: Check YOLO error response
- stale timestamp: Check ESP32 clock/UTC conversion

---

## 🌐 FRONTEND TESTS (React Display)

### TEST 4.1: API Response
**Action**: Open browser → `http://localhost:5000/api/location/BUS-001`  
**Expected Response**:
```json
{
  "success": true,
  "data": {
    "busId": "BUS-001",
    "busNumber": "BUS-001",
    "routeName": null,
    "status": "active",
    "currentLocation": {
      "latitude": 23.888138,
      "longitude": 90.390167,
      "timestamp": "2026-09-02T10:30:00.000Z"
    },
    "currentSpeed": 1.3,
    "currentPassengerCount": 5,  ← Latest
    "satellites": 6,
    "gpsFixed": true,
    "departureTime": "07:30",
    "eta": null
  }
}
```
**Status**: ✅ PASS / ❌ FAIL

**Debug if FAIL**:
- 404: Bus document not created, upload didn't complete
- null values: Check Bus model fields match schema
- stale passenger count: YOLO processing failed

---

### TEST 4.2: React Component Render
**Location**: `http://localhost:3000`  
**Action**: Navigate to live tracking page  
**Expected Display**:
```
[Leaflet Map with marker at 23.888138, 90.390167]

Bus ID: BUS-001
Route: ROUTE-01 (or null if not mapped)
Passengers: 5
Speed: 1.3 km/h
GPS Fixed: YES
Satellites: 6
Last Updated: 5 seconds ago (auto-updates)
```
**Status**: ✅ PASS / ❌ FAIL

**Visual Elements to Verify**:
- ✅ Map container loads (not white/blank)
- ✅ Marker appears at correct coordinates
- ✅ Popup shows bus information
- ✅ Circle radius marker shows (blue circle)
- ✅ "Last Updated" changes every polling interval
- ✅ No console errors (press F12)

**Debug if FAIL**:
- Blank map: Check Leaflet CSS loaded
- No marker: Check API response returned coordinates
- Stale data: Check polling interval (should be 5 seconds)
- CORS error in console: Check backend CORS settings

---

### TEST 4.3: Polling Update Verification
**Action**: Watch React for 2 minutes  
**Expected Behavior**:
```
T=0s:  Load shows: Last Updated: 2 minutes ago
T=5s:  Shows: Last Updated: 1 minute ago
T=10s: Shows: Last Updated: 57 seconds ago
...
T=30s: New upload from ESP32
T=35s: React shows: Last Updated: 5 seconds ago (NEW data)
```
**Status**: ✅ PASS / ❌ FAIL (if polling stops or updates stall)

**Debug if FAIL**:
- Polling not working: Check React useEffect interval cleanup
- Data not updating: Check backend returns new timestamp
- CORS blocked: Check browser console network tab

---

## 🔄 EXTENDED TESTS (System Stability)

### TEST 5.1: Continuous Polling (5 minutes)
**Duration**: 5 minutes  
**Expected**: 10 uploads from ESP32 (every 30 seconds)  
**Verify**:
```bash
# Count documents in BusData for BUS-001
db.busdatas.countDocuments({ busId: "BUS-001" })
# Should increase by 1 every 30 seconds

# Verify all have passenger counts
db.busdatas.find({ busId: "BUS-001" }, { passengerCount: 1 }).sort({ createdAt: -1 }).limit(10)
# All should have passengerCount: X (not missing/null)
```
**Expected Results**:
- No crashes in any console
- Backend responds to all requests
- YOLO processes every image
- MongoDB saves all documents
- React updates every polling interval
- No memory leaks (RAM usage stable)

**Status**: ✅ PASS / ❌ FAIL

---

### TEST 5.2: Error Recovery
**Action**: Simulate failure, verify recovery  

**Scenario A**: Stop MongoDB
```
Expected: 
- Backend logs: "MongoDB connection lost"
- Next upload gets 500 error
- Frontend shows "No live data available"
Action: Restart MongoDB → system recovers
Expected: Next upload succeeds, data returns
```

**Scenario B**: Stop YOLO Server
```
Expected:
- Backend logs: "YOLO connection refused"
- Data uploaded but passengerCount = 0
- Response includes yoloError message
- Frontend shows passengerCount: 0
Action: Restart YOLO → system recovers
Expected: Next upload gets real passenger count
```

**Scenario C**: Stop Backend
```
Expected:
- ESP32: "Could not connect to backend"
- Frontend: "Unable to load GPS data"
Action: Restart backend → system recovers
Expected: Next ESP32 upload succeeds
```

**Status**: ✅ PASS / ❌ FAIL (recovery works)

---

## 🎯 PERFORMANCE TESTS

### TEST 6.1: Latency Measurement
**Expected Timing Breakdown**:

| Phase | Expected | Max Acceptable |
|-------|----------|-----------------|
| Camera capture | 200-500ms | 1000ms |
| WiFi connect | 1-2s | 5s |
| Image upload | 2-5s | 10s |
| YOLO processing | 1-3s | 5s |
| MongoDB save | 50-200ms | 1000ms |
| Total end-to-end | 4-11s | 20s |

**Measure**:
```javascript
// In backend logs, find:
// "uploadStartTime" and "endToEndDurationMs"
// or use BusExperimentLog.find().sort({ createdAt: -1 })
```

**Status**: ✅ PASS / ❌ FAIL (if consistently exceeds max)

---

### TEST 6.2: Image Quality
**Expected**:
- QVGA (320×240) compression with quality 12
- File size: 5-30 KB (smaller = faster upload)
- YOLO can reliably detect people

**Verify**:
```bash
# Check file sizes
ls -lh backend/uploads/bus-images/BUS-001_*.jpg | tail -5
# Average should be ~10-15 KB
```

**Status**: ✅ PASS / ❌ FAIL

---

## ✅ SYSTEM ACCEPTANCE CHECKLIST

Mark each as PASS/FAIL after testing:

### Core Functionality
- [ ] ESP32 compiles without errors
- [ ] ESP32 gets GPS fix (satellites > 3, gpsFixed=true)
- [ ] ESP32 connects to WiFi SSID "Admin"
- [ ] ESP32 establishes HTTPS connection
- [ ] ESP32 sends multipart form-data correctly
- [ ] Image file arrives at backend
- [ ] Backend receives GPS metadata accurately
- [ ] YOLO server responds with passenger count
- [ ] MongoDB stores BusData document
- [ ] Bus collection updates with latest data
- [ ] Location collection receives GPS history

### Frontend Integration
- [ ] React loads without errors (F12 console clear)
- [ ] Live tracking page displays
- [ ] Map shows bus marker at correct location
- [ ] Passenger count displays (not hardcoded/always 0)
- [ ] Speed displays correctly
- [ ] GPS status shows correct value
- [ ] Satellite count displays
- [ ] Last update time shows and refreshes
- [ ] Polling updates every 5 seconds
- [ ] Multi-update (5+ uploads) shows changing values

### Error Handling
- [ ] Missing image handled gracefully
- [ ] YOLO failure doesn't crash backend
- [ ] Backend returns error messages clearly
- [ ] Frontend shows "No data available" not stale data
- [ ] All error messages are descriptive
- [ ] No silent failures or empty responses

### System Stability
- [ ] 5-minute continuous test passes
- [ ] No memory leaks (RAM stable)
- [ ] Error recovery works (restart services)
- [ ] No hardcoded values in live display
- [ ] No duplicate ESP32 sketches active
- [ ] All unique timestamps (not replayed data)

### Documentation
- [ ] Setup guide completed
- [ ] Environment variables documented
- [ ] ngrok configuration recorded
- [ ] Troubleshooting procedures available
- [ ] API response examples captured
- [ ] Database schema verified

### Next Steps Documented
- [ ] SIM800L power requirements documented
- [ ] Fallback mechanism outlined
- [ ] Hardware improvements noted
- [ ] Performance optimization opportunities listed

---

## 📊 QUICK PASS/FAIL SUMMARY

```
✅ = All tests passed → SYSTEM READY
⚠️  = Some warnings but functional → PROCEED WITH CAUTION
❌ = Critical failures → HALT AND TROUBLESHOOT

Unit Tests:        [  ]
Hardware Tests:    [  ]
Integration Tests: [  ]
Frontend Tests:    [  ]
Stability Tests:   [  ]
Performance Tests: [  ]

OVERALL: [  ] READY FOR PRODUCTION
```

---

## 📞 DEBUGGING RESOURCES

If tests fail, check:
1. **Serial Monitor**: ESP32 diagnostics
2. **Backend Console**: `npm start` output
3. **YOLO Console**: `python yolo_server.py` output
4. **MongoDB**: `db.busdatas.find().sort({ createdAt: -1 })`
5. **Browser Console**: F12 → Console tab
6. **Network Tab**: F12 → Network → see API calls
7. **ngrok Dashboard**: http://localhost:4040 → inspect traffic
8. **Linux/Mac logs**: `tail -f /var/log/mongodb.log`

Collect all 8 outputs and cross-reference for the issue.

---

**Test Complete!** Save this checklist and run it before each major deployment.
