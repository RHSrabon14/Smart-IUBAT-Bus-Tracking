# SIM800L CTRL+Z Fix - Testing & Verification Guide

## 📋 Pre-Upload Checklist

- [ ] **Backup original code**: Save esp32_code.ino.bak
- [ ] **Check board selection**: AI Thinker ESP32-CAM in Arduino IDE
- [ ] **Verify port**: COM3/COM4 (or your USB port)
- [ ] **Check baud rate**: 115200
- [ ] **SIM card inserted**: Into SIM800L module
- [ ] **GPRS plan active**: With "gpinternet" APN access
- [ ] **GPS antenna connected**: To NEO-6M
- [ ] **Outdoor location ready**: For GPS fix (needs clear sky)

---

## 🚀 Upload & Initial Test

### Step 1: Compile & Upload
1. Open **Arduino IDE**
2. Open **File → Open → esp32_code.ino**
3. Select **Tools → Board → AI Thinker ESP32-CAM**
4. Select **Tools → Port → COM3** (or your port)
5. Click **Sketch → Upload**
6. Wait for "Hard resetting via RTS pin..."

### Step 2: Open Serial Monitor
1. **Tools → Serial Monitor**
2. **Set baud rate to 115200** (bottom right)
3. You should see startup messages within 5 seconds

### Step 3: Look for Initial Output
```
═══════════════════════════════════════
🚌 IUBAT BUS TRACKING SYSTEM
📝 IEEE PAPER DATA COLLECTION
═══════════════════════════════════════
📡 Initializing GPS...
✅ GPS initialized
📱 Initializing SIM800L...
✅ SIM800L ready!
🌐 Connecting to GPRS...
```

**If you see these messages**: ✅ Upload successful

**If you see "❌ SIM800L not responding!"**: 
- Check SIM800L UART connections (pins 13/14)
- Check power supply to SIM800L
- Try pressing SIM800L reset button

---

## 📡 Connectivity Test Phase

### Expected Messages (in this order):

```
🌐 Connecting to GPRS...
   Attaching to GPRS...
   Setting APN: gpinternet
   Bringing up GPRS...
   IP: 10.45.XXX.XXX
✅ GPRS Internet connection ready!
```

**Wait up to 2 minutes** for GPRS connection.

### GPS Acquisition (parallel)

While waiting for GPRS, GPS should be acquiring:
```
✅ System READY!
🚌 Bus: BUS-001
🌐 Server: symphony-shady-selection.ngrok-free.dev
📸 Camera: WORKING ✅
📍 GPS: Searching...
```

**After 30-60 seconds** (outdoors with clear sky):
```
═══════════════════════════════════════
📍 LIVE GPS DATA
═══════════════════════════════════════
📅 Date: 29/08/26
🕐 Time: 14:35:22
📍 Latitude:  23.730156°
📍 Longitude: 90.410234°
📏 Altitude:  25.5 m
🛰️ Satellites: 12
📊 Quality:   1
🚗 Speed: 0.0 km/h
📍 Google Maps: https://maps.google.com/?q=23.730156,90.410234
═══════════════════════════════════════
```

**Quality > 0 and Satellites ≥ 4** means ✅ GPS FIXED

---

## 🎯 Upload Test Phase (The Critical Fix Test)

### Trigger Manual Upload
1. Wait for both GPRS and GPS to show ✅
2. At 30-second interval (or wait up to 30 seconds from startup)
3. You'll see:

```
📸 Capturing image...
✅ Image: 8192 bytes
─────────────────────────────────────────
📍 Latitude:  23.730156°
📍 Longitude: 90.410234°
📏 Altitude:  25.5 m
🚗 Speed: 0.0 km/h
🛰️ Satellites: 12
📊 GPS Fixed: YES ✅
─────────────────────────────────────────

📤 Upload attempt 1/3
```

### Watch For These Messages (IN ORDER):

#### ✅ Step 1: GPRS Ready
```
🔄 Re-establishing GPRS connection...
   IP: 10.45.XXX.XXX
✅ GPRS Internet connection ready!
```

#### ✅ Step 2: TCP Connection
```
📡 Connecting: symphony-shady-selection.ngrok-free.dev:80
✅ CONNECT OK
```

#### ✅ Step 3: Size Calculation
```
📦 Multipart body size: 512 bytes
🖼️  Image size: 8192 bytes
📦 Closing boundary: 52 bytes
📋 HTTP Content-Length: 8756 bytes
📤 Total TCP bytes to send: 8904 bytes
```

#### ✅ Step 4: CIPSEND Ready
```
📤 Sending: AT+CIPSEND=8904
✅ Received '>' prompt
```

#### ✅ Step 5: Data Transmission
```
📤 Sending HTTP request headers...
📤 Sending multipart form data...
📤 Sending image data (8192 bytes)...
✅ Image sent: 8192 bytes
📤 Sending multipart closing boundary...
📤 Sending CTRL+Z (0x1A)...
```

#### 🔴 CRITICAL CHECK: SEND OK Response
```
📥 Waiting for SEND OK...
✅ SEND OK received!
```

**If you DON'T see "✅ SEND OK received!"**:
- This means the CTRL+Z fix isn't working
- Check you uploaded the corrected code
- Try manual reset: Press RST button on ESP32
- Re-upload the code

#### ✅ Step 6: HTTP Response
```
📥 Waiting for HTTP response...
[HTTP RESPONSE]
HTTP/1.1 200 OK
Server: ngrok
Content-Type: application/json
Content-Length: 42

{"success":true,"passengerCount":24}
```

#### ✅ Step 7: Success!
```
✅ Upload successful!
⏱️ Upload time: 8.5 seconds
📊 Server Response: {"success":true,"passengerCount":24}
👥 PASSENGER COUNT: 24
✅ Image uploaded successfully!
📍 GPS Location sent to backend!
```

---

## 📊 Success Criteria

### ✅ Minimum Success (Code is Working)
1. See "✅ CONNECT OK" (TCP connection successful)
2. See "✅ SEND OK received!" (CTRL+Z fix working)
3. See "HTTP/1.1 200 OK" (Backend accepts upload)

### ✅ Complete Success (Full System Working)
1. Image file appears in `/backend/uploads/bus-images/`
2. Passenger count appears: "👥 PASSENGER COUNT: X"
3. New record created in MongoDB with GPS coordinates
4. Upload repeats every 30 seconds

### ✅ Perfect Success (Production Ready)
1. All above criteria met
2. No watchdog timeout errors
3. No "PSRAM ID read error"
4. Consistent uploads over 1+ hour

---

## ❌ Troubleshooting

### Issue: "❌ TCP Connection failed!"

**Cause**: Cannot reach ngrok tunnel

**Solutions**:
1. Check ngrok is running: `ngrok http 5000`
2. Verify URL in esp32_code.ino matches ngrok output
3. Check internet connection
4. Wait 30 seconds and retry

```cpp
// Line 37-38 - update if your ngrok URL changed
const char serverIP[] = "symphony-shady-selection.ngrok-free.dev";
const int serverPort = 80;
```

---

### Issue: "❌ No '>' prompt from SIM800L"

**Cause**: CIPSEND command not processed

**Solutions**:
1. Check SIM800L serial connection (pins 13/14)
2. Try lower baud rate (9600 should be correct)
3. Power cycle SIM800L:
   - Unplug USB from ESP32 (5 seconds)
   - Plug back in
   - Wait for SIM800L to initialize

---

### Issue: "❌ No SEND OK received!" OR "❌ SEND FAIL"

**Cause**: Old code (CTRL+Z not being sent)

**Solution**: Verify you're running the FIXED version:
```cpp
// Line ~642 - should contain:
Serial.println("📤 Sending CTRL+Z (0x1A)...");
SerialAT.write((uint8_t)0x1A);
delay(200);
```

If missing, re-upload the corrected esp32_code.ino

---

### Issue: "HTTP 400 Bad Request"

**Cause**: Multipart format invalid

**Check**:
1. Is backend expecting field name `image`? (upload.single('image'))
2. Are all required fields present?
   - busId, routeId, latitude, longitude, altitude
   - speed, satellites, gpsFixed, date, time, image

**Verify in backend** [server.js](../backend/server.js):
```javascript
router.post('/upload', upload.single('image'), (req, res) => {
    // Field name must be 'image'
```

---

### Issue: "Guru Meditation Error: Interrupt wdt timeout on CPU1"

**Cause**: Long blocking loops without yield()

**Solution**: Code already fixed with yield() calls
- If you still see this, check you uploaded the new code
- Press RST button to reboot
- Try again

---

### Issue: "PSRAM ID read error: 0xffffffff"

**Cause**: PSRAM not available (expected on this board)

**Solution**: Already handled in code:
```cpp
#define CONFIG_SPIRAM_SUPPORT 0  // Disable PSRAM
config.fb_location = CAMERA_FB_IN_DRAM;  // Use DRAM instead
```

This error is normal and not a problem.

---

## 🔍 Detailed Debug Output

To capture full debug output for analysis:

1. Open Serial Monitor
2. Right-click → Copy All
3. Save to test_output.txt
4. Look for these critical sequences:

### ✅ Good Flow:
```
AT+CIPSEND=8904
> 
✅ Received '>' prompt
✅ SEND OK received!
HTTP/1.1 200 OK
```

### ❌ Bad Flow (Old Code):
```
AT+CIPSEND=8904
> 
✅ Received '>' prompt
(long pause)
❌ SEND ERROR
(or timeout waiting for SEND OK)
```

---

## 📈 Performance Expectations

| Metric | Expected | Range |
|--------|----------|-------|
| GPRS connection time | 10-30 sec | 5-60 sec |
| GPS fix time | 20-60 sec | Outdoor only |
| Image capture time | <1 sec | 0.5-2 sec |
| Upload time | 8-15 sec | 5-30 sec |
| Total cycle | ~45 sec | Cold start |
| Repeat cycle | ~30 sec | Warm start |

---

## ✅ Verification Checklist

### Immediate (First 2 minutes):
- [ ] Serial output appears
- [ ] SIM800L initializes (✅ shown)
- [ ] GPRS connects (IP address shown)
- [ ] GPS searches for fix

### After 1-2 minutes (with GPS fix):
- [ ] Upload attempt starts
- [ ] CONNECT OK received
- [ ] Data sent (image bytes count shown)
- [ ] SEND OK received ← **KEY INDICATOR OF FIX**
- [ ] HTTP 200 OK received

### After upload:
- [ ] Passenger count displayed
- [ ] No error messages
- [ ] System returns to idle

### Optional (Full integration test):
- [ ] Backend server shows image file received
- [ ] MongoDB document created
- [ ] YOLO passenger detection runs
- [ ] Count accurate

---

## 📞 Support

If upload still fails after verifying all steps:

1. **Check esp32_code.ino line 642-644**:
   ```cpp
   Serial.println("📤 Sending CTRL+Z (0x1A)...");
   SerialAT.write((uint8_t)0x1A);
   delay(200);
   ```
   Must be present and not commented out

2. **Check Serial Monitor shows "✅ SEND OK received!"**
   - If not, CTRL+Z not being sent or not working

3. **Verify ngrok tunnel is running**:
   ```bash
   ngrok http 5000
   ```

4. **Check Node.js backend is running**:
   ```bash
   cd backend && npm start
   ```

5. **Verify MongoDB is accessible**

---

## 🎓 Understanding the Fix

**Why CTRL+Z was critical:**

SIM800L has two transmission modes:
1. `AT+CIPSEND` → Wait for > → Send data + CTRL+Z → SEND OK
2. `AT+CIPSEND=<length>` → Wait for > → Send exactly N bytes + CTRL+Z → SEND OK

**Old code**: Sent data but no CTRL+Z → SIM800L hung → Timeout → SEND ERROR

**New code**: Sends data → Sends CTRL+Z (0x1A) → SIM800L responds SEND OK → Upload succeeds

This single character (0x1A = 26 decimal) was the missing piece!

---

## 🚀 Next Steps After Success

1. **Field Testing**: Test in actual bus routes
2. **Passenger Count Accuracy**: Verify YOLO detection is accurate  
3. **Backend Dashboard**: Monitor fleet data
4. **Database Analysis**: Check GPS logs and timing

**Congratulations on fixing the ESP32-CAM system!** 🎉
