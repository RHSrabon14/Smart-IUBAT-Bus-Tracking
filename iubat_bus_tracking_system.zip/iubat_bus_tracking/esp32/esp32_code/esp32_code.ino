/*
 * MPU6050 - Gyroscope & Accelerometer Test
 * SDA=GPIO25, SCL=GPIO26
 */

#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

Adafruit_MPU6050 mpu;

void setup() {
  Serial.begin(115200);
  delay(2000);
  
  Serial.println("========================================");
  Serial.println("MPU6050 GYROSCOPE + ACCELEROMETER TEST");
  Serial.println("========================================\n");
  
  // Initialize I2C
  Wire.begin(25, 26);
  
  // Initialize MPU6050
  if (!mpu.begin(0x68, &Wire)) {
    Serial.println("❌ MPU6050 NOT FOUND!");
    Serial.println("\nCheck:");
    Serial.println("  1. VCC → 3.3V");
    Serial.println("  2. GND → GND");
    Serial.println("  3. SDA → GPIO25");
    Serial.println("  4. SCL → GPIO26");
    Serial.println("  5. AD0 → GND (MUST connect!)");
    while (1) delay(100);
  }
  
  // Configure MPU6050
  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  
  Serial.println("✅ MPU6050 FOUND!\n");
  Serial.println("Reading sensor data...\n");
  Serial.println("========================================\n");
  delay(1000);
}

void loop() {
  sensors_event_t accel, gyro, temp;
  mpu.getEvent(&accel, &gyro, &temp);
  
  // ACCELEROMETER (m/s²)
  Serial.println("📊 ACCELEROMETER:");
  Serial.print("  X: ");
  Serial.print(accel.acceleration.x, 2);
  Serial.print(" m/s²  |  Y: ");
  Serial.print(accel.acceleration.y, 2);
  Serial.print(" m/s²  |  Z: ");
  Serial.print(accel.acceleration.z, 2);
  Serial.println(" m/s²");
  
  // GYROSCOPE (rad/s → deg/s)
  Serial.println("🔄 GYROSCOPE:");
  Serial.print("  X: ");
  Serial.print(gyro.gyro.x * 57.2958, 2);
  Serial.print(" °/s  |  Y: ");
  Serial.print(gyro.gyro.y * 57.2958, 2);
  Serial.print(" °/s  |  Z: ");
  Serial.print(gyro.gyro.z * 57.2958, 2);
  Serial.println(" °/s");
  
  // TEMPERATURE
  Serial.println("🌡️ TEMPERATURE:");
  Serial.print("  ");
  Serial.print(temp.temperature, 1);
  Serial.println(" °C");
  
  Serial.println("----------------------------------------\n");
  
  delay(500);
}