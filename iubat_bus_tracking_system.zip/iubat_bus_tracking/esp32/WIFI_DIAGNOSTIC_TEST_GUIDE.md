# WiFi Diagnostic Test Guide

## 🎯 PURPOSE

This Wi-Fi diagnostic test mode temporarily bypasses the SIM800L modem to isolate whether your bus tracking system's upload failures are caused by:

- ❌ **SIM800L Hardware** (defective modem)
- ❌ **SIM800L Power Supply** (insufficient current during transmission)
- ❌ **GPRS/AT Commands** (modem protocol issues)
- ✅ **ESP32-CAM Code** (image capture and upload logic)
- ✅ **Backend API** (Node.js endpoint and field handling)
- ✅ **Multipart Form-Data** (format and byte accounting)

## 📋 WHAT CHANGED IN esp32_code.ino

### New Additions (NOT removals)
```cpp
#include <WiFi.h>
#include <HTTPClient.h>

#define WIFI_SSID "[YOUR_WIFI_SSID]"
#define WIFI_PASSWORD "[YOUR_WIFI_PASSWORD]"
#define USE_WIFI_MODE 1  // 1 = WiFi test, 0 = SIM800L
```

### Disabled (Commented Out for Testing)
```cpp
// HardwareSerial SerialAT(1);  // SIM800L UART disabled
// initSIM800L()  // SIM800L init disabled
// connectGPRS()  // GPRS connection disabled
// uploadWithRetry()  // SIM800L upload disabled
```

### New Functions Added
```cpp
initWiFi()           // Connect to WiFi network
checkWiFiStatus()    // Monitor WiFi connection status
printWiFiStatus()    // Print WiFi info
uploadWithWiFi()     // Upload via HTTPClient instead of AT commands
```

### Modified Functions
```cpp
setup()              // Now initializes WiFi instead of SIM800L
loop()               // Now checks WiFi status and uses WiFi upload
captureAndSend()     // Now uses uploadWithWiFi()
```

**Important**: All SIM800L code remains in the file (commented out). You can easily switch back by uncommenting it.

---

## 🔧 BACKEND COMPATIBILITY

### API Endpoint
- **Method**: `POST`
- **URL**: `http://symphony-shady-selection.ngrok-free.dev/api/bus/upload`
- **Path**: `/api/bus/upload`

### Form Fields (Must Match Exactly)
```
busId              = "BUS-001"
routeId            = "ROUTE-01"
latitude           = GPS latitude (6 decimal places)
longitude          = GPS longitude (6 decimal places)
altitude           = GPS altitude in meters
speed              = GPS speed in km/h
satellites         = Number of GPS satellites
gpsFixed           = "true" or "false"
date               = GPS date (DD/MM/YYYY)
time               = GPS time (HH:MM:SS)
image              = JPEG image file (binary)
```

### Expected Response
```json
{
  "success": true,
  "passengerCount": 5,
  "busId": "BUS-001",
  "routeId": "ROUTE-01",
  "data": { ... }
}
```

---

## 📡 WIFI CREDENTIALS

```
SSID:     [YOUR_WIFI_SSID]
Password: [YOUR_WIFI_PASSWORD]
```

These are hardcoded in esp32_code.ino:
```cpp
#define WIFI_SSID "[YOUR_WIFI_SSID]"
#define WIFI_PASSWORD "[YOUR_WIFI_PASSWORD]"
```

**Make sure your WiFi router is ON and broadcasting "[YOUR_WIFI_SSID]" SSID.**

---

## 🚀 HOW TO RUN THE TEST

### Step 1: Ensure WiFi is Available
```bash
# On your computer or phone:
# Check that "[YOUR_WIFI_SSID]" WiFi network is available
# Make sure you know the password: [YOUR_WIFI_PASSWORD]
```

### Step 2: Upload Modified Code to ESP32-CAM
```bash
Arduino IDE:
├─ Open: esp32_code.ino
├─ Select Board: "AI Thinker ESP32-CAM"
├─ Select Port: COM3 (or your port)
├─ Click: Upload
└─ Wait for: "Uploading... Done!"
```

### Step 3: Open Serial Monitor
```bash
Arduino IDE:
├─ Tools → Serial Monitor
├─ Baud Rate: 115200
├─ Line Ending: Both NL & CR
└─ Click: Reset button on ESP32 (if needed)
```

### Step 4: Watch Serial Output
```
═══════════════════════════════════════
🚌 IUBAT BUS TRACKING SYSTEM
📝 WiFi DIAGNOSTIC TEST MODE
═══════════════════════════════════════

📡 INITIALIZING Wi-Fi CONNECTION
🔗 Connecting to WiFi: Admin
.....

✅ WiFi CONNECTED!
═══════════════════════════════════════
📍 IP Address: 192.168.x.x
🔗 SSID: Admin
📶 Signal Strength (RSSI): -50 dBm
═══════════════════════════════════════

📡 Initializing GPS...
✅ GPS initialized

📸 Camera: WORKING ✅
📡 WiFi: CONNECTED ✅

[Every 10 seconds]:
═══════════════════════════════════════
📍 GPS FIX: YES / NO
📅 Date: DD/MM/YYYY
🕐 Time: HH:MM:SS
📍 Latitude:  XX.XXXXXX°
📍 Longitude: XX.XXXXXX°
📏 Altitude:  XXX.X m
🛰️  Satellites: XX
═══════════════════════════════════════

[Every 30 seconds if GPS fixed AND WiFi connected]:
═══════════════════════════════════════
📷 CAMERA CAPTURE
═══════════════════════════════════════
✅ Image captured: XXXX bytes

📍 GPS DATA
📍 Latitude:  XX.XXXXXX°
📍 Longitude: XX.XXXXXX°
📏 Altitude:  XXX.X m
🚗 Speed:     X.X km/h
🛰️  Satellites: XX

📷 CAMERA
✅ Image captured successfully
📊 Image size: XXXX bytes

═══════════════════════════════════════
📤 WiFi UPLOAD SEQUENCE
═══════════════════════════════════════

📍 Backend URL: http://symphony-shady-selection.ngrok-free.dev/api/bus/upload
📝 Endpoint: /api/bus/upload

🔗 Connecting to backend...
📤 Sending multipart/form-data...

================================================
MULTIPART FORM-DATA DEBUG
================================================
Prefix length: XXX
Image length: XXXX
Ending length: XX
Total Content-Length: XXXX
================================================

📥 HTTP Response Code: 200

================================================
HTTP RESPONSE BODY
================================================
{"success":true,"passengerCount":5,"busId":"BUS-001","routeId":"ROUTE-01", ...}
================================================

✅ HTTP 200 OK - Upload successful!

📊 Parsing JSON response...
{"success":true,"passengerCount":5, ...}

👥 PASSENGER COUNT: 5

✅ Image uploaded successfully!
📍 GPS Location sent to backend!
```

---

## 📊 EXPECTED SERIAL OUTPUT EXAMPLES

### Success Case (WiFi Upload Works)
```
✅ WiFi CONNECTED!
IP Address: 192.168.1.100
Signal Strength (RSSI): -45 dBm

📍 GPS FIX: YES
Latitude: 23.812345°
Longitude: 90.345678°
Satellites: 12

📤 WiFi UPLOAD SEQUENCE
🔗 Connecting to backend...
📤 Sending multipart/form-data...

📥 HTTP Response Code: 200
✅ HTTP 200 OK - Upload successful!
👥 PASSENGER COUNT: 5
✅ Image uploaded successfully!
```

### Failure Case #1: WiFi Cannot Connect
```
🔗 Connecting to WiFi: Admin
.................

❌ WiFi CONNECTION FAILED!
Status: 1
```
**Diagnosis**: WiFi router not broadcasting "[YOUR_WIFI_SSID]" or incorrect password

- "[YOUR_WIFI_SSID]" SSID not broadcasting

2. Verify SSID is "[YOUR_WIFI_SSID]"
3. Verify password is "[YOUR_WIFI_PASSWORD]"

### Failure Case #2: WiFi Connected but GPS Fails
```
✅ WiFi CONNECTED!
IP Address: 192.168.1.100

📍 GPS FIX: NO
⚠️ No GPS fix, waiting for satellite lock...
```
**Diagnosis**: GPS receiver not getting satellite lock (needs outdoor location with clear sky)

### Failure Case #3: WiFi Connected but Upload Fails
```
✅ WiFi CONNECTED!
📍 GPS FIX: YES

📤 WiFi UPLOAD SEQUENCE
🔗 Connecting to backend...

📥 HTTP Response Code: 400
❌ HTTP Error Code: 400
Response: Bad Request
```
**Diagnosis**: 
- Check multipart field names match backend
- Verify ngrok tunnel is still active
- Check Content-Length calculation

### Failure Case #4: Backend Returns Error
```
📥 HTTP Response Code: 200
Response: {"error": "busId field missing"}
```
**Diagnosis**: Form field name mismatch with backend

---

## 🔍 TROUBLESHOOTING

### Problem: "WiFi CONNECTION FAILED"
```
Cause: 
- WiFi router not on
- "Admin" SSID not broadcasting
- Wrong password

Solution:
1. Turn on WiFi router
2. Verify SSID is "Admin"
3. Verify password is "sabbir1234"
4. Check no typos in #define lines
```

### Problem: "No GPS fix, waiting for satellite lock"
```
Cause:
- GPS module needs outdoor location
- Too many buildings blocking signal
- GPS module not connected properly

Solution:
1. Go outside (away from buildings)
2. Wait 30-60 seconds for lock
3. Check GPS receiver wiring
4. Ensure NEO-6M antenna is on
```

### Problem: "HTTP Response Code: 400"
```
Cause:
- Multipart form field names wrong
- Backend expects different field name for image
- Content-Length miscalculated

Solution:
1. Check backend code for exact field names
2. Verify image field name is "image" (not "photo")
3. Print multipart body and verify format
```

### Problem: "HTTP Response Code: 404"
```
Cause:
- Wrong endpoint path
- ngrok URL changed

Solution:
1. Verify endpoint is `/api/bus/upload`
2. Check ngrok tunnel is still running
3. Verify URL in code matches backend
```

### Problem: "HTTP Response Code: 500"
```
Cause:
- Backend server error
- MongoDB connection failed
- YOLO server not running

Solution:
1. Check backend logs: npm start
2. Verify MongoDB is running
3. Check YOLO server is running
4. Look for JavaScript errors
```

---

## 📈 DIAGNOSTIC FLOWCHART

```
START
  ↓
┌─────────────────────────────────┐
│ Can WiFi connect to "[YOUR_WIFI_SSID]"?    │
└─────────────────────────────────┘
  ├─ NO → Fix WiFi router (see above)
  ├─ YES ↓
       ┌─────────────────────────────────┐
       │ Can GPS get satellite fix?      │
       └─────────────────────────────────┘
       ├─ NO → Go outside with antenna
       ├─ YES ↓
            ┌──────────────────────────────────┐
            │ HTTP POST to /api/bus/upload?    │
            └──────────────────────────────────┘
            ├─ NO → Check endpoint URL
            ├─ HTTP 400 → Check form field names
            ├─ HTTP 404 → Check ngrok is running
            ├─ HTTP 500 → Check backend logs
            ├─ YES ↓
                 ┌───────────────────────────────┐
                 │ Backend receives image file?  │
                 └───────────────────────────────┘
                 ├─ NO → Check multipart format
                 ├─ YES ↓
                      ┌─────────────────────────────┐
                      │ YOLO detects passengers?    │
                      └─────────────────────────────┘
                      ├─ NO → Check YOLO server
                      ├─ YES ↓
                           ┌───────────────────────┐
                           │ ✅ WiFi TEST SUCCESS! │
                           │ SIM800L is the issue  │
                           └───────────────────────┘
```

---

## ✅ WHAT SUCCESS MEANS

If WiFi uploads work successfully:

```
✅ ESP32-CAM camera works
✅ Image JPEG encoding works
✅ Multipart/form-data format is correct
✅ Backend API endpoint works
✅ MongoDB saves data correctly
✅ YOLO detection works
✅ React website displays passenger count

❌ PROBLEM IDENTIFIED:
   SIM800L hardware, power supply, or GPRS connection
   is the REAL root cause of your upload failures.
```

**Next Steps if WiFi Works**:
1. Verify SIM800L power supply has AMS1117-3.8V regulator
2. Measure voltage on Vbat during transmission (must stay > 3.5V)
3. Consider using external 2A power supply for SIM800L
4. Uncomment SIM800L code and test with better power

---

## ❌ WHAT FAILURE MEANS

If WiFi uploads also fail:

```
❌ Problem is NOT SIM800L hardware

Possible issues:
1. Multipart form field names wrong
2. Backend endpoint URL incorrect
3. ngrok tunnel not active
4. Backend middleware not working
5. Camera image buffer corrupted
6. HTTP header format incorrect
```

**Next Steps if WiFi Fails**:
1. Check backend logs: `npm start`
2. Verify MongoDB connection
3. Test YOLO server: `python yolo_server.py`
4. Print raw HTTP request for debugging
5. Check browser shows upload in Network tab

---

## 🔄 SWITCHING BACK TO SIM800L

When ready to test with SIM800L again:

```cpp
// UNCOMMENT these lines:
HardwareSerial SerialAT(1);
bool initSIM800L() { ... }
bool connectGPRS() { ... }
bool uploadWithRetry() { ... }

// COMMENT these lines:
#define USE_WIFI_MODE 1  // Change to 0
// if (!initWiFi())
// checkWiFiStatus()
// uploadWithWiFi()

// RESTORE setup() to use initSIM800L() and connectGPRS()
// RESTORE loop() to use gprsConnected check
```

All SIM800L code remains in the file - just commented out for this test.

---

## 📌 IMPORTANT NOTES

1. **This is a TEST, not production**: You are temporarily using WiFi to diagnose the issue
2. **No files were deleted**: All SIM800L code remains (commented)
3. **Backend endpoint is identical**: Same `/api/bus/upload` endpoint
4. **Multipart format is identical**: Same field names and structure
5. **Only transport changed**: WiFi instead of GPRS/AT commands
6. **Easily reversible**: Just uncomment SIM800L code to switch back

---

## 🎯 EXPECTED TEST RESULTS

### Scenario 1: WiFi Works, SIM800L Fails
```
Conclusion: SIM800L power supply is the problem
Solution: Add AMS1117-3.8V regulator with capacitors
```

### Scenario 2: WiFi Works, SIM800L Also Works Now
```
Conclusion: Code is fine, likely was temporary issue
Solution: Monitor SEND ERROR for pattern
```

### Scenario 3: WiFi Fails, SIM800L Also Fails
```
Conclusion: Backend or field names are wrong
Solution: Check backend code matches form fields
```

### Scenario 4: WiFi Fails, SIM800L Works
```
Conclusion: WiFi or network configuration issue
Solution: Check WiFi credentials and ngrok URL
```

---

## 📞 GETTING HELP

When reporting the test results, include:

```
Serial Monitor Output:
- WiFi connection status
- HTTP response code
- Passenger count received
- Any error messages

Backend Logs:
- Did endpoint get called?
- Did image get saved?
- Did YOLO run?
- Did MongoDB update?

Browser:
- Does bus appear on map?
- Does passenger count show?
- Any Network tab errors?
```

---

## 🏁 NEXT STEPS

1. **Run this WiFi diagnostic test** - takes 5-10 minutes
2. **Note the exact HTTP response code** - identifies the problem
3. **Check backend logs** - see if image was received
4. **Report results** - tells us whether SIM800L or code is the issue
5. **Fix the root cause** - either power supply or code change
6. **Switch back to SIM800L** - uncomment the commented code
7. **Test full system** - verify it works in production

Good luck with your diagnostic testing! 🚀
