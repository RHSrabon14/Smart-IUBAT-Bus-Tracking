# ESP32-CAM Upload Test Checklist

## Pre-Upload Verification
- [ ] Code compiles without errors
- [ ] Serial Monitor baud rate set to 115200
- [ ] ESP32-CAM USB connected
- [ ] SIM card inserted in SIM800L
- [ ] Backend ngrok tunnel running
- [ ] Phone hotspot ready (or other GPRS network)

## Upload & Monitor

### Step 1: Flash and Wait for Initialization
```
Serial Monitor shows:
✅ SIM800L ready!
✅ GPRS Internet connection ready!
```

### Step 2: Watch TCP Cleanup Sequence
```
Watch for:
🧹 Cleaning up TCP connection state...
   Sending: AT+CIPCLOSE
   Response: CLOSED
✅ TCP cleanup complete
```

### Step 3: Watch CIPMUX Setup
```
Watch for:
⚙️ Setting single connection mode (AT+CIPMUX=0)...
   [AT+CIPMUX=0 RESPONSE]
   OK
   Verifying: AT+CIPMUX?
   [AT+CIPMUX? RESPONSE]
   +CIPMUX: 0
   OK
✅ CIPMUX=0 verified
```

### Step 4: Watch TCP Connection
```
Watch for:
📡 TCP Connection
   [CIPSTART RESPONSE - RAW]
   OK
   CONNECT OK
✅ TCP Connected
```

### Step 5: Watch CIPSEND
```
Watch for:
📤 AT+CIPSEND Command
Declared bytes: XXXX
   [CIPSEND RESPONSE - RAW]
   >
✅ CIPSEND accepted - Ready to send data
```

### Step 6: Watch Data Transfer
```
Watch for:
📤 Sending HTTP request headers...
   → Sent XXX bytes
📤 Sending multipart form data...
   → Sent XXX bytes
📤 Sending image data (XXXX bytes)...
   → Chunk 1: sent 256 bytes
   → Chunk 2: sent 256 bytes
   ...
✅ Image sent: XXXX bytes
📤 Sending multipart closing boundary...
   → Sent XXX bytes

═══════════════════════════════════════
Expected bytes (AT+CIPSEND value):  XXXX
Actual bytes sent:                 XXXX
✅ BYTE COUNT MATCHES!
═══════════════════════════════════════
```

### Step 7: Watch Response
```
Watch for:
✅ SEND OK received!

[HTTP RESPONSE - RAW]
HTTP/1.1 200 OK
...
{"success":true,"passengerCount":XX}

✅ HTTP 200 OK
👥 PASSENGER COUNT: XX
✅ Image uploaded successfully!
```

## Success Indicators
- [ ] All colored checkmarks (✅) appear in sequence
- [ ] No ❌ errors
- [ ] No `+CME ERROR` messages
- [ ] No truncated responses
- [ ] Byte count matches expected
- [ ] HTTP 200 OK received
- [ ] Backend responds with passenger count

## If Something Goes Wrong

### CME ERROR: operation not allowed
→ TCP connection still active when CIPMUX=0 was sent
→ Run CIPCLOSE first
→ Check cleanupTCPConnection() is being called

### No '>' prompt after CIPSEND
→ CIPMUX not properly set
→ Check AT+CIPMUX? returns "+CIPMUX: 0"
→ Retry cleanupTCPConnection()

### Byte count mismatch
→ Image not sent completely
→ Check image buffer size (fb->len)
→ Verify no data loss in UART transmission
→ Add delays between chunks if needed

### HTTP 401 or 403
→ Backend authentication issue
→ Not related to SEND ERROR fix
→ Check busId, routeId, etc. in request

### Timeout waiting for response
→ Connection closed by backend
→ Check ngrok tunnel still active
→ Check backend server logs
→ Try shorter image (lower quality) first

## Performance Baseline
- Image capture: 1-2 seconds
- GPRS connection: 3-5 seconds
- TCP connection: 1-2 seconds
- Data transfer (8KB image): 5-8 seconds
- Total time: 10-18 seconds

If taking much longer, check:
1. GPRS signal strength (check AT+CSQ response)
2. Backend response time
3. Image size (try smaller resolution)

## Next Steps After Success
1. ✅ Verify multiple uploads work consistently
2. ✅ Test with poor signal conditions (GPRS less stable)
3. ✅ Add error recovery (current code has 3 retries)
4. ✅ Monitor passenger count updates
5. ✅ Test GPS location accuracy
6. ✅ Deploy to production bus tracking system
