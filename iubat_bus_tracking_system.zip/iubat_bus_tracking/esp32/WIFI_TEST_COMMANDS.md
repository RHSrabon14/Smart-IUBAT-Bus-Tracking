# WiFi Diagnostic Test - Command Reference

## 🔧 BEFORE TEST: Startup Commands

```bash
# Terminal 1: Start MongoDB (if not already running)
mongosh

# Terminal 2: Start Backend
cd backend
npm start
# Wait for: 🚀 Server running on port 80

# Terminal 3: Start YOLO Server  
cd backend/yolo_server
python yolo_server.py
# Wait for: Running on http://0.0.0.0:5001

# Terminal 4: Start ngrok (if not already running)
ngrok http 80
# Note the URL like: https://abc123.ngrok-free.dev

# Terminal 5: Frontend (optional, for manual testing)
cd frontend
npm start
# Wait for: Compiled successfully!

# Terminal 6: Arduino IDE
# Open esp32_code.ino
# Select Board: AI Thinker ESP32-CAM
# Select Port: COM3 (or your port)
# Click Upload
```

---

## 📡 DURING TEST: Serial Monitor

```bash
# Arduino IDE Tools → Serial Monitor
Baud Rate: 115200
Line Ending: Both NL & CR
Autoscroll: ON

# Watch for these messages:
✅ WiFi CONNECTED!
✅ GPS FIX: YES
✅ HTTP Response Code: 200
```

---

## 📊 AFTER UPLOAD: Verification Commands

```bash
# Terminal: Check image was saved
ls -lh backend/uploads/bus-images/
# Should see recent file: BUS-001_XXXXXXXXXX.jpg
# File size: 3000-5000 bytes (typical JPEG)

# Terminal: Check MongoDB saved data
mongosh
use iubat
db.busdatas.find({busId: "BUS-001"}).sort({_id:-1}).limit(1)
# Should see: busId, latitude, longitude, passengerCount

# Terminal: Check Bus location updated
db.buses.findOne({busId: "BUS-001"})
# Should see: currentLocation, currentPassengerCount

# Terminal: Check GPS history
db.locations.find({busId: "BUS-001"}).sort({_id:-1}).limit(5)
# Should see recent GPS locations
```

---

## 🌐 BACKEND DEBUGGING

```bash
# Terminal with npm start running
# Should see in logs:

🔥🔥🔥 UPLOAD ENDPOINT WAS HIT! 🔥🔥🔥

📥 Received from ESP32-CAM:
   Bus ID: BUS-001
   Image: BUS-001_XXXXXXXXXX.jpg
   Image Size: XXXX
   GPS: XX.XXXXXX, YY.YYYYYY
   Speed: XX.X
   Satellites: XX

✅ Data saved to MongoDB (processing)
🔄 Sending to YOLO for detection...
✅ YOLO Response received
   Passenger Count: X
✅ Updated passenger count: X
```

---

## 🎯 TEST EXECUTION CHECKLIST

```bash
PRE-TEST SETUP:
[ ] WiFi router is ON
[ ] "Admin" SSID is visible
[ ] MongoDB is running (mongosh responds)
[ ] Backend is running (npm start, port 80)
[ ] YOLO server is running (python yolo_server.py)
[ ] ngrok tunnel is active (http://127.0.0.1:4040)
[ ] Frontend is running (localhost:3000, optional)
[ ] ESP32-CAM has power
[ ] Camera lens is clean
[ ] GPS antenna is outside

UPLOAD PROCESS:
[ ] Arduino IDE opened with esp32_code.ino
[ ] Board selected: AI Thinker ESP32-CAM
[ ] Port selected: COM3 (or your port)
[ ] Code compiled successfully
[ ] Code uploaded successfully
[ ] Serial Monitor opened at 115200 baud

DURING TEST:
[ ] Serial Monitor shows "WiFi CONNECTED"
[ ] Serial Monitor shows "GPS FIX: YES" (wait up to 60s)
[ ] Serial Monitor shows image capture
[ ] Serial Monitor shows "HTTP Response Code: 200"
[ ] Serial Monitor shows "PASSENGER COUNT: X"
[ ] Backend logs show "UPLOAD ENDPOINT WAS HIT"
[ ] Backend logs show "✅ Data saved to MongoDB"
[ ] File appeared in backend/uploads/bus-images/

POST-TEST VERIFICATION:
[ ] MongoDB has new BusData document
[ ] Bus.currentPassengerCount is updated
[ ] Location history shows GPS coordinates
[ ] Frontend map shows red bus marker (optional)
[ ] Marker popup shows passenger count (optional)
```

---

## 🔍 DIAGNOSTIC QUERIES

```bash
# Check latest upload in MongoDB
mongosh
use iubat
db.busdatas.find().sort({_id:-1}).limit(1).pretty()

# Check Bus collection
db.buses.findOne({busId: "BUS-001"})

# Check Location history (last 10)
db.locations.find({busId: "BUS-001"}).sort({_id:-1}).limit(10).pretty()

# Count uploads
db.busdatas.countDocuments()

# Check YOLO success rate
db.busdatas.countDocuments({passengerCount: {$gte: 0}})

# Find uploads without passenger count (YOLO failed)
db.busdatas.find({passengerCount: -1}).pretty()

# Check timestamps to see if processing is working
db.busdatas.find({busId: "BUS-001"}).sort({_id:-1}).limit(1).forEach(doc => {
  print("Upload time: " + doc.timestamp);
  print("Processing: " + doc.processing);
  print("Passenger count: " + doc.passengerCount);
})
```

---

## 🐛 TROUBLESHOOTING COMMANDS

```bash
# Check if backend is listening on port 80
netstat -an | grep ":80"
# or
lsof -i :80

# Check if YOLO is running on port 5001  
netstat -an | grep ":5001"
# or
curl http://localhost:5001/

# Check if ngrok tunnel is active
curl http://localhost:4040/api/tunnels

# Check WiFi signal from ESP32 (in Serial Monitor)
Look for: "Signal Strength (RSSI): -XX dBm"
# Good: -30 to -70 dBm
# Bad: -80 to -100 dBm

# Test backend endpoint manually
curl -X POST http://localhost/api/bus/upload \
  -F "busId=BUS-001" \
  -F "latitude=23.8" \
  -F "longitude=90.3" \
  -F "image=@test.jpg"

# Check if ngrok is forwarding correctly
curl -H "Host: symphony-shady-selection.ngrok-free.dev" \
  http://localhost:80/api/bus/upload
```

---

## 📋 FORM FIELDS VERIFICATION

```bash
# Print what esp32_code.ino sends (from Serial Monitor):
Multipart form fields:
- busId: BUS-001
- routeId: ROUTE-01
- latitude: 23.812345
- longitude: 90.345678
- altitude: 100.5
- speed: 25.5
- satellites: 12
- gpsFixed: true
- date: 15/09/2025
- time: 14:30:45
- image: [JPEG binary data]

# Compare with backend expectations (server.js line 195):
req.body.busId
req.body.routeId
req.body.latitude
req.body.longitude
req.body.altitude
req.body.speed
req.body.satellites
req.body.gpsFixed
req.body.date
req.body.time
req.file (image)

# If any field is missing or wrong name: HTTP 400
```

---

## 📈 PERFORMANCE METRICS

```bash
# Time from image capture to HTTP response:
# Look in Serial Monitor for timestamps
# Calculate: HTTP Response Time - Image Capture Time
# Expected: 5-10 seconds

# WiFi Signal Strength: 
# Good: -30 to -50 dBm
# Acceptable: -50 to -70 dBm  
# Poor: -70 to -100 dBm (will cause failures)

# Image file size:
# Expected: 3000-5000 bytes (QVGA JPEG quality 12)
# Too large: May cause timeout
# Too small: Camera not working

# GPS acquisition time:
# Expected: 30-60 seconds (first time)
# Faster: 5-10 seconds (with DGPS)
# Slower: >60 seconds (indoor, bad location)
```

---

## 🎯 EXPECTED SUCCESS SEQUENCE

```
T+0s:   "✅ WiFi CONNECTED!"
T+10s:  "📍 GPS FIX: YES"
T+30s:  "📸 Capturing image..." 
T+32s:  "✅ Image: 3456 bytes"
T+33s:  "📤 WiFi UPLOAD SEQUENCE"
T+34s:  "🔗 Connecting to backend..."
T+35s:  "📤 Sending multipart/form-data..."
T+36s:  "📥 HTTP Response Code: 200"
T+37s:  "✅ HTTP 200 OK - Upload successful!"
T+38s:  "📊 Parsing JSON response..."
T+39s:  "👥 PASSENGER COUNT: 5"
T+40s:  "✅ Image uploaded successfully!"
T+60s:  [Cycle repeats]
```

---

## 🔄 SWITCHING BACK TO SIM800L

```bash
# Edit esp32_code.ino to switch back:

1. Uncomment line with HardwareSerial SerialAT(1);
2. Uncomment initSIM800L() function
3. Uncomment connectGPRS() function  
4. Uncomment uploadWithRetry() function
5. Uncomment all AT command helper functions
6. In setup(), change: initWiFi() → initSIM800L()
7. In setup(), uncomment: connectGPRS()
8. In loop(), change: wifiConnected → gprsConnected
9. In captureAndSend(), change: uploadWithWiFi() → uploadWithRetry()
10. Recompile and upload

# All code remains in file - just toggle comments
```

---

## 💾 SAVING TEST RESULTS

```bash
# Save serial monitor output
# Arduino IDE: Sketch → Export Compiled Binary
# or copy from Serial Monitor and save to file

# Save backend logs
# Copy terminal output to: test_results_backend.txt

# Save MongoDB state
mongosh < queries.js > mongodb_results.txt

# Archive test files
mkdir wifi_test_results
cp backend/uploads/bus-images/* wifi_test_results/
cp test_results_backend.txt wifi_test_results/
cp mongodb_results.txt wifi_test_results/
zip -r wifi_test_results.zip wifi_test_results/
```

---

## 📞 REPORTING RESULTS

When you have test results, provide:

```
Test Environment:
- WiFi Signal Strength: -XX dBm
- Backend Status: Running
- YOLO Status: Running
- ngrok Status: Active

Test Results:
- WiFi Connection: SUCCESS / FAILURE
- GPS Lock: SUCCESS / FAILURE  
- Image Upload: SUCCESS / FAILURE
- HTTP Response Code: 200 / XXX
- Passenger Count: X / Not received
- Backend Received File: YES / NO
- MongoDB Updated: YES / NO
- Frontend Updated: YES / NO

Serial Monitor Output: [paste relevant lines]
Backend Log Output: [paste relevant lines]
Error Messages: [list any errors]
Timestamp: [when test was run]
```

---

## 🎊 QUICK REFERENCE SUMMARY

| Task | Command | Expected Result |
|------|---------|-----------------|
| Check WiFi | Serial Monitor | "✅ WiFi CONNECTED" |
| Check GPS | Serial Monitor | "📍 GPS FIX: YES" |
| Check Upload | Serial Monitor | "HTTP Response Code: 200" |
| Check Backend | npm logs | "UPLOAD ENDPOINT WAS HIT" |
| Check File | ls uploads/bus-images | Recent .jpg file |
| Check MongoDB | mongosh query | BusData with image |
| Check YOLO | Backend logs | "PASSENGER COUNT: X" |
| Check Frontend | Browser map | Red marker appears |

---

Ready to test! Run through the startup commands and follow the checklist. 🚀
