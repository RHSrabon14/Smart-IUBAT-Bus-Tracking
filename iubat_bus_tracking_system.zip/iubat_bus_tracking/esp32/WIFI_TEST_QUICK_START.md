# WiFi Diagnostic Test - Quick Start

## ✅ WHAT I CHANGED

Modified **ONLY** `esp32_code.ino`:

### Added Libraries
```cpp
#include <WiFi.h>
#include <HTTPClient.h>
```

### Added WiFi Configuration
```cpp
#define WIFI_SSID "[YOUR_WIFI_SSID]"
#define WIFI_PASSWORD "[YOUR_WIFI_PASSWORD]"
#define USE_WIFI_MODE 1
```

### New Functions
- `initWiFi()` - Connect to WiFi
- `checkWiFiStatus()` - Monitor connection
- `printWiFiStatus()` - Display WiFi info
- `uploadWithWiFi()` - Upload via HTTP instead of SIM800L

### What's Commented Out (Not Deleted!)
- SIM800L UART initialization
- `initSIM800L()` function
- `connectGPRS()` function  
- `uploadWithRetry()` function (SIM800L version)
- All AT command functions remain in file

### What's Enabled
- WiFi connection in `setup()`
- WiFi upload in `captureAndSend()`
- WiFi status checking in `loop()`

---

## 📍 BACKEND ENDPOINT

```
POST /api/bus/upload
Host: symphony-shady-selection.ngrok-free.dev
```

### Exact Field Names (From Backend Code)
```
busId
routeId
latitude
longitude
altitude
speed
satellites
gpsFixed
date
time
image              ← FILE FIELD (must be named "image" exactly)
```

---

## 🎯 TEST PROCEDURE

### 1. Verify WiFi is ON
```
Router should broadcast "[YOUR_WIFI_SSID]" network
Password: [YOUR_WIFI_PASSWORD]
```

### 2. Upload Code
```
Arduino IDE → Upload esp32_code.ino
Board: AI Thinker ESP32-CAM
Port: COM3 (or your port)
```

### 3. Open Serial Monitor
```
Baud Rate: 115200
Line Ending: Both NL & CR
```

### 4. Watch for Output
```
✅ WiFi CONNECTED!
IP Address: 192.168.x.x
Signal Strength: -XX dBm

📍 GPS FIX: YES / NO
Latitude: XX.XXXXXX°
Longitude: XX.XXXXXX°

📤 WiFi UPLOAD SEQUENCE
HTTP Response Code: 200
👥 PASSENGER COUNT: X
✅ Image uploaded successfully!
```

---

## 🔍 DIAGNOSTIC RESULTS

### If WiFi Upload Works ✅
```
CONCLUSION: Camera, code, backend, YOLO, and MongoDB all work
PROBLEM: SIM800L hardware, power supply, or GPRS connection
SOLUTION: Fix SIM800L power with AMS1117-3.8V regulator
```

### If WiFi Upload Fails ❌
```
CONCLUSION: Issue is NOT SIM800L
PROBLEM: Multipart format, backend field names, or ngrok
SOLUTION: Check backend logs, verify field names match
```

---

## 🔧 CHECKING EACH COMPONENT

### Backend Received Image?
```bash
cd backend
ls uploads/bus-images/
# Should see BUS-001_XXXXXXXXXX.jpg file
```

### Backend Logs Show Upload?
```bash
cd backend
npm start
# Should see:
# 🔥🔥🔥 UPLOAD ENDPOINT WAS HIT! 🔥🔥🔥
# ✅ Data saved to MongoDB
# 👥 PASSENGER COUNT: X
```

### YOLO Server Running?
```bash
cd backend/yolo_server
python yolo_server.py
# Should see listening on localhost:5001
```

### Frontend Shows Bus?
```
Open browser to http://localhost:3000/bus-tracking
Should see red marker on map
Should show passenger count in marker popup
```

---

## 🎯 EXPECTED HTTP RESPONSES

### Success (HTTP 200)
```json
{
  "success": true,
  "passengerCount": 5,
  "busId": "BUS-001",
  "routeId": "ROUTE-01",
  "data": { ... }
}
```

### Bad Request (HTTP 400)
```
Cause: Wrong field names
Solution: Verify busId, latitude, longitude, etc.
```

### Not Found (HTTP 404)
```
Cause: Wrong endpoint path
Solution: Check it's /api/bus/upload
```

### Server Error (HTTP 500)
```
Cause: Backend crashed or MongoDB failed
Solution: Check backend logs
```

---

## 🔄 AFTER TESTING

### If Successful: Back to SIM800L
1. Uncomment all SIM800L code
2. Update `setup()` to call `initSIM800L()`
3. Update `loop()` to use `gprsConnected`
4. Call `uploadWithRetry()` instead of `uploadWithWiFi()`
5. Upload code again
6. Test with better SIM800L power supply

### If Failed: Investigate Backend
1. Check backend logs
2. Verify all field names match exactly
3. Test with curl/Postman
4. Check MongoDB is running
5. Check YOLO server is running
6. Test ngrok tunnel is active

---

## 📊 COMPLETE FORM FIELDS

Your code sends these exact fields to backend:

| Field | Value | Source |
|-------|-------|--------|
| busId | "BUS-001" | Hardcoded #define |
| routeId | "ROUTE-01" | Hardcoded #define |
| latitude | GPS latitude | NEO-6M GPS module |
| longitude | GPS longitude | NEO-6M GPS module |
| altitude | GPS altitude | NEO-6M GPS module |
| speed | GPS speed | NEO-6M GPS module |
| satellites | Satellite count | NEO-6M GPS module |
| gpsFixed | "true"/"false" | GPS fix status |
| date | DD/MM/YYYY | GPS date |
| time | HH:MM:SS | GPS UTC time |
| image | JPEG bytes | ESP32-CAM camera |

---

## ⚡ QUICK TEST (5 minutes)

```bash
# Terminal 1: Backend
cd backend
npm start

# Terminal 2: ESP32 Serial Monitor
Arduino IDE → Serial Monitor → 115200 baud

# Terminal 3: Monitor uploads
cd backend/uploads/bus-images
ls -lh
# Wait 30 seconds for upload...
# Check if new file appears

# Terminal 4: Check MongoDB
mongosh
use iubat
db.busdatas.find().sort({_id:-1}).limit(1)
# Should see latest upload with passengerCount
```

---

## 🚨 COMMON MISTAKES

❌ Wrong WiFi SSID
```
Code has: "Admin"
Your router broadcasts: "admin" (lowercase)
→ Won't connect!
```

❌ Backend not running
```
You didn't execute: npm start
→ HTTP 404 or connection refused
```

❌ ngrok tunnel down
```
ngrok process crashed or expired
→ HTTP 404 or timeout
```

❌ YOLO server not running
```
Backend tries to send to localhost:5001
→ YOLO detection fails
```

❌ MongoDB not running
```
Backend tries to save to database
→ HTTP 500 error
```

✅ Check all three are running before testing!

---

## 📋 FORM FIELD CHECKLIST

Backend expects these exact names (case-sensitive):

- [ ] busId (not BusID, not bus_id)
- [ ] routeId (not RouteID, not route_id)
- [ ] latitude (not lat, not Latitude)
- [ ] longitude (not lon, not lng, not Longitude)
- [ ] altitude (not alt, not Altitude)
- [ ] speed (not Speed)
- [ ] satellites (not sats, not Satellites)
- [ ] gpsFixed (not gps_fixed, not GPSFixed)
- [ ] date (not Date)
- [ ] time (not Time)
- [ ] image (not photo, not Image, not img)

All 11 fields must match exactly or backend returns 400 Bad Request!

---

## 🎯 FINAL TEST CHECKLIST

Before running test:
- [ ] WiFi router is ON with "[YOUR_WIFI_SSID]" SSID visible
- [ ] Backend is running: `npm start`
- [ ] YOLO server is running: `python yolo_server.py`
- [ ] MongoDB is running
- [ ] ngrok tunnel is active
- [ ] ESP32-CAM has power
- [ ] Camera lens is clean
- [ ] GPS antenna is outside with clear sky
- [ ] Serial monitor baud rate is 115200

After uploading code:
- [ ] Serial monitor shows "WiFi CONNECTED"
- [ ] Serial monitor shows "GPS FIX: YES" after 30-60 seconds
- [ ] Backend logs show "UPLOAD ENDPOINT WAS HIT"
- [ ] Backend logs show "✅ Data saved to MongoDB"
- [ ] File appears in `backend/uploads/bus-images/`
- [ ] YOLO detection runs and returns passenger count
- [ ] Frontend map shows red bus marker
- [ ] Passenger count displays on marker

---

## 🏁 RESULTS TEMPLATE

Copy this and fill it out:

```
WiFi Diagnostic Test Results
============================

Test Date: _______________
Test Duration: ___ minutes

WiFi Connection: YES / NO
IP Address: _______________
Signal Strength: ___ dBm

GPS Lock Achieved: YES / NO
Time to Lock: ___ seconds
Latitude: _______________
Longitude: _______________
Satellites: ___

Upload Attempt: YES / NO
HTTP Response Code: ___
Passenger Count Received: ___ / None

Backend Received Image: YES / NO
Image File: _______________

YOLO Detection: YES / NO
Count Returned: ___

Frontend Shows Bus: YES / NO
Passenger Count Visible: YES / NO

Overall Result: SUCCESS / FAILURE

Conclusion:
───────────

```

---

**Upload the modified esp32_code.ino and start testing!** 🚀

If WiFi works: SIM800L/power is the problem ⚡
If WiFi fails: Backend/field names are the problem 🔧
