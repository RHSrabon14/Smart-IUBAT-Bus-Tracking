require('dotenv').config();
const mongoose = require('mongoose');
const Bus = require('./models/Bus');
(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    const doc = await Bus.findOneAndUpdate(
      { busId: 'BUS-001' },
      {
        $set: {
          busNumber: 'BUS-001',
          status: 'active',
          currentLocation: {
            latitude: 23.7937,
            longitude: 90.4066,
            timestamp: new Date()
          },
          currentSpeed: 14.5,
          currentPassengerCount: 0,
          satellites: 7,
          gpsFixed: true,
          lastUpdated: new Date()
        }
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    console.log('Bus upsert result:', doc);
  } catch (error) {
    console.error('Error:', error);
  } finally {
    await mongoose.disconnect();
  }
})();
