require("dotenv").config();
const mongoose = require("mongoose");
const Bus = require("./models/Bus");
const ShuttleRoute = require("./models/ShuttleRoute");
const MorningRoute = require("./models/MorningRoute");
const EveningRoute = require("./models/EveningRoute");

const routeCode = "ROUTE-01";
const busId = "BUS-001";

async function ensureRouteMapping() {
  await mongoose.connect(process.env.MONGO_URI);

  let route = await ShuttleRoute.findOne({ routeId: routeCode });
  let routeModel = "ShuttleRoute";

  if (!route) {
    route = await MorningRoute.findOne({ routeId: routeCode });
    routeModel = "MorningRoute";
  }

  if (!route) {
    route = await EveningRoute.findOne({ routeId: routeCode });
    routeModel = "EveningRoute";
  }

  if (!route) {
    route = await ShuttleRoute.create({
      busNo: busId,
      busId,
      routeId: routeCode,
      routeName: "Campus To Mirpure10",
      time: "06:45",
      type: "shuttle",
    });
    routeModel = "ShuttleRoute";
    console.log(`Created ${routeCode} -> ${route.routeName}`);
  } else {
    console.log(`Using existing ${routeCode} -> ${route.routeName}`);
  }

  const bus = await Bus.findOneAndUpdate(
    { busId },
    {
      $set: {
        routeCode,
        routeName: route.routeName,
        routeId: route._id,
        routeModel,
      },
      $setOnInsert: {
        busNumber: busId,
      },
    },
    { new: true, upsert: true, setDefaultsOnInsert: true }
  );

  console.log(`Mapped ${bus.busId} -> ${bus.routeCode} -> ${bus.routeName}`);
}

ensureRouteMapping()
  .catch((error) => {
    console.error("Unable to ensure route mapping:", error.message);
    process.exitCode = 1;
  })
  .finally(() => mongoose.disconnect());