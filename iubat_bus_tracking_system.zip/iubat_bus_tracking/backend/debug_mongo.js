require('dotenv').config();
const mongoose = require('mongoose');
const Bus = require('./models/Bus');
const Location = require('./models/Location');
const BusData = require('./models/BusData');

(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('=== BUS DATA COUNT ===');
    console.log(await BusData.countDocuments());
    console.log('=== LATEST BUS DATA ===');
    const latestBusData = await BusData.findOne().sort({ createdAt: -1 }).lean();
    console.log(latestBusData);
    console.log('=== BUSES ===');
    const buses = await Bus.find({}).select('busId busNumber currentPassengerCount currentLocation gpsFixed satellites').lean();
    console.log(buses);
    console.log('=== LOCATIONS ===');
    const locations = await Location.find({}).limit(20).lean();
    console.log(locations);
  } catch (error) {
    console.error(error);
  } finally {
    await mongoose.disconnect();
  }
})();
