const nodemailer = require("nodemailer");

const mailHost = process.env.MAIL_HOST;
const mailPort = Number(process.env.MAIL_PORT || 587);
const mailUser = process.env.MAIL_USER;
const mailPass = process.env.MAIL_PASS;
const mailSecure = process.env.MAIL_SECURE === "true";
const mailFrom = process.env.MAIL_FROM || mailUser;

if (!mailHost || !mailUser || !mailPass) {
  console.warn("Warning: Mail service is not fully configured. Forgot/reset password email will fail until MAIL_HOST, MAIL_USER, and MAIL_PASS are set.");
}

const transporter = mailHost && mailUser && mailPass
  ? nodemailer.createTransport({
      host: mailHost,
      port: mailPort,
      secure: mailSecure,
      auth: {
        user: mailUser,
        pass: mailPass,
      },
    })
  : null;

const sendResetOtp = async ({ to, otp, role }) => {
  if (!mailHost || !mailUser || !mailPass || !transporter) {
    console.log(`[email] OTP for ${to} (${role}): ${otp}`);
    return { sent: false, reason: "mail-not-configured" };
  }

  const subject = `IUBAT Bus Tracking - ${role} password reset OTP`;
  const text = `Your password reset OTP is ${otp}. It will expire in 15 minutes.`;
  const html = `
    <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #202124;">
      <h2>IUBAT Bus Tracking Password Reset</h2>
      <p>Your ${role} account password reset request was received.</p>
      <p><strong>OTP:</strong> ${otp}</p>
      <p>This code expires in 15 minutes.</p>
      <p>If you did not request this, please ignore this message.</p>
    </div>
  `;

  await transporter.sendMail({
    from: mailFrom,
    to,
    subject,
    text,
    html,
  });
};

module.exports = {
  sendResetOtp,
};
