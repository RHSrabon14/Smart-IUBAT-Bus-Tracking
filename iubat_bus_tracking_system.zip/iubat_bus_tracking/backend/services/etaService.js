const formatEtaTime = (date) => {
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const period = hours >= 12 ? "PM" : "AM";
  const normalizedHour = hours % 12 || 12;
  return `${normalizedHour}:${String(minutes).padStart(2, "0")} ${period}`;
};

const toMinutes = (value) => {
  if (!value) return null;

  const normalizedValue = String(value).trim().toUpperCase();
  const match = normalizedValue.match(/^(\d{1,2}):(\d{2})(?:\s?(AM|PM))?$/);

  if (!match) {
    return null;
  }

  let hour = Number(match[1]);
  const minute = Number(match[2]);
  const period = match[3];

  if (period === "PM" && hour < 12) {
    hour += 12;
  }

  if (period === "AM" && hour === 12) {
    hour = 0;
  }

  return hour * 60 + minute;
};

const haversineDistanceKm = (fromLat, fromLon, toLat, toLon) => {
  const toRadians = (value) => (value * Math.PI) / 180;
  const earthRadiusKm = 6371;

  const dLat = toRadians(toLat - fromLat);
  const dLon = toRadians(toLon - fromLon);
  const lat1 = toRadians(fromLat);
  const lat2 = toRadians(toLat);

  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLon / 2) ** 2;
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return earthRadiusKm * c;
};

const calculateEta = ({ currentLocation, speedKmph, departureTime, route = {}, now = new Date() }) => {
  const destinationLatitude = Number(route.destinationLatitude);
  const destinationLongitude = Number(route.destinationLongitude);
  const routeDistanceKm = Number(route.distanceKm || route.estimatedDistanceKm || 0);
  const fallbackSpeed = Number(speedKmph) > 0 ? Number(speedKmph) : 25;

  let remainingDistanceKm = routeDistanceKm;

  if (
    currentLocation?.latitude !== undefined &&
    currentLocation?.longitude !== undefined &&
    Number.isFinite(destinationLatitude) &&
    Number.isFinite(destinationLongitude)
  ) {
    remainingDistanceKm = haversineDistanceKm(
      Number(currentLocation.latitude),
      Number(currentLocation.longitude),
      destinationLatitude,
      destinationLongitude,
    );
  }

  const safeDistance = Math.max(0, Number(remainingDistanceKm) || 0);
  const remainingTimeMinutes = Math.max(1, Math.round((safeDistance / fallbackSpeed) * 60));
  const etaDate = new Date(now.getTime() + remainingTimeMinutes * 60000);

  const departureMinutes = toMinutes(departureTime);
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const delayMinutes = departureMinutes !== null ? Math.max(0, currentMinutes - departureMinutes) : 0;

  return {
    estimatedArrivalTime: formatEtaTime(etaDate),
    remainingDistanceKm: Number(safeDistance.toFixed(1)),
    remainingTimeMinutes,
    delayMinutes,
    speedKmph: Number(fallbackSpeed.toFixed(1)),
  };
};

module.exports = {
  calculateEta,
  formatEtaTime,
};
