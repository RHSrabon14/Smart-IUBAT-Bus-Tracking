const Bus = require("../models/Bus");
const ShuttleRoute = require("../models/ShuttleRoute");
const MorningRoute = require("../models/MorningRoute");
const EveningRoute = require("../models/EveningRoute");

const routeModels = [ShuttleRoute, MorningRoute, EveningRoute];

const findRouteByCode = async (routeCode) => {
  if (!routeCode) return null;

  for (const RouteModel of routeModels) {
    const route = await RouteModel.findOne({ routeId: routeCode }).lean();
    if (route) return { ...route, routeModel: RouteModel.modelName };
  }

  return null;
};

const resolveRouteForBus = async (bus) => {
  if (!bus) return null;

  const route = bus.routeCode ? await findRouteByCode(bus.routeCode) : null;
  if (route) return route;

  if (bus.routeId && bus.routeModel) {
    const RouteModel = { ShuttleRoute, MorningRoute, EveningRoute }[bus.routeModel];
    if (RouteModel) return RouteModel.findById(bus.routeId).lean();
  }

  return null;
};

const applyRouteMappingToBus = async (busId, routeCode) => {
  if (!busId || !routeCode) return null;

  const route = await findRouteByCode(routeCode);
  if (!route) return null;

  return Bus.findOneAndUpdate(
    { busId },
    {
      $set: {
        routeCode,
        routeName: route.routeName,
        routeId: route._id,
        routeModel: route.routeModel,
      },
    },
    { new: true }
  );
};

module.exports = {
  findRouteByCode,
  resolveRouteForBus,
  applyRouteMappingToBus,
};