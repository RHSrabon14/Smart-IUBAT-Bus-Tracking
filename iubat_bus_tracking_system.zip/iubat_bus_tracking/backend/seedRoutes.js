const mongoose = require("mongoose");
const Route = require("./models/Route");

require("dotenv").config();

const routesData = [
  { "busNo": "11", "routeName": "Rajendrapur", "time": "5:40 PM", "type": "all" },
  { "busNo": "14", "routeName": "Gabtoli, Savar, Nabinagar, Dhamrai", "time": "5:40 PM", "type": "all" },
  { "busNo": "12", "routeName": "Ashulia, CMB, Bismail, Palli Bidyut, Dhamrai", "time": "5:40 PM", "type": "all" },
  { "busNo": "21", "routeName": "Kalshi, Mirpur 10, Mirpur 02, Mirpur 01", "time": "5:40 PM", "type": "all" },
  { "busNo": "36", "routeName": "Kalshi, Mirpur 10, Shewrapara, Agargaon", "time": "5:40 PM", "type": "all" },
  { "busNo": "23", "routeName": "Signboard", "time": "5:40 PM", "type": "all" },
  { "busNo": "24", "routeName": "Chandra", "time": "5:40 PM", "type": "all" },
  { "busNo": "25", "routeName": "Notun Bazar, Badda, Rampura, Motijheel, Tikatoli, Signboard", "time": "5:40 PM", "type": "all" },
  { "busNo": "31", "routeName": "Khilgaon, Mugdha, Jatrabari", "time": "5:40 PM", "type": "all" },
  { "busNo": "26", "routeName": "Kaliaganj, Pachdona, Narsingdi", "time": "5:40 PM", "type": "all" },
  { "busNo": "27", "routeName": "Razbari", "time": "5:40 PM", "type": "all" },
  { "busNo": "33", "routeName": "Shimultali", "time": "5:40 PM", "type": "all" },
  { "busNo": "30", "routeName": "Mawna", "time": "5:40 PM", "type": "all" },
  { "busNo": "34", "routeName": "Konabari, Mouchak", "time": "5:40 PM", "type": "all" },
  { "busNo": "32", "routeName": "Khilkhet, Mohakhali, Shishumela", "time": "5:40 PM", "type": "all" },
  { "busNo": "35", "routeName": "Mohammadpur, City College", "time": "5:40 PM", "type": "all" }
];

async function seedRoutes() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("✅ Connected to MongoDB");

    // Clear existing routes with type "all"
    await Route.deleteMany({ type: "all" });
    console.log("🗑️ Cleared existing 'all' type routes");

    // Insert new routes
    await Route.insertMany(routesData);
    console.log("✅ Added 16 routes to database");

    console.log("🎉 Seeding completed!");
  } catch (error) {
    console.error("❌ Error seeding routes:", error);
  } finally {
    mongoose.connection.close();
  }
}

seedRoutes();