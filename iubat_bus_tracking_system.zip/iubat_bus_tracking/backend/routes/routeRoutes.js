const express = require("express");
const router = express.Router();
const Route = require("../models/ShuttleRoute");
const { verifyAdmin } = require("../middleware/authMiddleware");

/* GET all routes (public) */
router.get("/", async (req, res) => {
  try {
    const data = await Route.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/* ADD route (admin only) */
router.post("/", verifyAdmin, async (req, res) => {
  try {
    const { busNo, routeName, time, type } = req.body;

    if (!busNo || !routeName || !time || !type) {
      return res.status(400).json({ msg: "Please provide busNo, routeName, time, and type" });
    }

    const newRoute = new Route({
      busNo,
      routeName,
      time,
      type,
    });

    await newRoute.save();
    res.status(201).json({ message: "Route added", route: newRoute });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* DELETE route (admin only) */
router.delete("/:id", verifyAdmin, async (req, res) => {
  try {
    const route = await Route.findByIdAndDelete(req.params.id);
    if (!route) {
      return res.status(404).json({ msg: "Route not found" });
    }
    res.json({ message: "Route deleted" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* UPDATE route (admin only) */
router.put("/:id", verifyAdmin, async (req, res) => {
  try {
    const { busNo, routeName, time, type } = req.body;

    if (!busNo || !routeName || !time || !type) {
      return res.status(400).json({ msg: "Please provide busNo, routeName, time, and type" });
    }

    const updatedRoute = await Route.findByIdAndUpdate(
      req.params.id,
      { busNo, routeName, time, type },
      { new: true }
    );

    if (!updatedRoute) {
      return res.status(404).json({ msg: "Route not found" });
    }

    res.json({ message: "Route updated", route: updatedRoute });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;