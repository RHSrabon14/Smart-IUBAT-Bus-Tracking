const express = require("express");
const router = express.Router();
const Admin = require("../models/Admin");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const {
  updateRoute,
  deleteRoute,
  addRoute,
  getAllRoutes,
  addBus,
  getAllBuses,
} = require("../controllers/adminController");
const {
  getDashboardSummary,
  addBus: addTransportBus,
  updateBus,
  deleteBus,
  listBuses,
  addDriver,
  listDrivers,
  updateDriver,
  deleteDriver,
  assignDriver,
  addRoute: addTransportRoute,
  listRoutes,
  updateRoute: updateTransportRoute,
  deleteRoute: deleteTransportRoute,
  uploadPassengerCount,
  uploadGPS,
  createAlert,
  listAlerts,
  addMaintenance,
  listMaintenance,
  listLiveTracking,
} = require("../controllers/transportController");

// ADMIN LOGIN
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const admin = await Admin.findOne({ email });

    if (!admin) {
      return res.status(400).json({ msg: "Invalid Email" });
    }

    const isMatch = await bcrypt.compare(password, admin.password);

    if (!isMatch) {
      return res.status(400).json({ msg: "Wrong Password" });
    }

    // Create JWT token
    const token = jwt.sign(
      { id: admin._id, role: "admin" },
      process.env.JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.json({ msg: "Login Successful", token, admin: { _id: admin._id, email: admin.email, username: admin.username } });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Route Management
router.post("/add-route", addRoute);
router.put("/update-route/:id", updateRoute);
router.delete("/delete-route/:id", deleteRoute);
router.get("/routes", getAllRoutes);

// Bus Management
router.post("/add-bus", addBus);
router.get("/buses", getAllBuses);

// Extended transport management
router.get("/dashboard", getDashboardSummary);
router.get("/transport-buses", listBuses);
router.post("/buses", (req, res, next) => {
  console.log("[POST /api/admin/buses] request", req.body);
  return addTransportBus(req, res, next);
});
router.put("/buses/:id", updateBus);
router.delete("/buses/:id", deleteBus);

router.get("/drivers", listDrivers);
router.post("/drivers", addDriver);
router.put("/drivers/:id", updateDriver);
router.delete("/drivers/:id", deleteDriver);
router.post("/drivers/assign", assignDriver);

router.get("/all-routes", listRoutes);
router.post("/routes", addTransportRoute);
router.put("/routes/:id", updateTransportRoute);
router.delete("/routes/:id", deleteTransportRoute);

router.post("/passenger-count", uploadPassengerCount);
router.post("/gps", uploadGPS);
router.post("/alerts", createAlert);
router.get("/alerts", listAlerts);
router.post("/maintenance", addMaintenance);
router.get("/maintenance", listMaintenance);
router.get("/live-tracking", listLiveTracking);

module.exports = router;