const express = require("express");
const router = express.Router();
const { verifyAdmin } = require("../middleware/authMiddleware");
const {
  getDashboardSummary,
  addBus,
  updateBus,
  deleteBus,
  listBuses,
  listBusesBySchedule,
  addDriver,
  listDrivers,
  updateDriver,
  deleteDriver,
  assignDriver,
  addRoute,
  listRoutes,
  updateRoute,
  deleteRoute,
  uploadPassengerCount,
  listPassengers,
  uploadGPS,
  createAlert,
  listAlerts,
  addMaintenance,
  listMaintenance,
  listLiveTracking,
  getTracking,
} = require("../controllers/transportController");

router.get("/dashboard", verifyAdmin, getDashboardSummary);
router.get("/buses", listBuses);
router.get("/buses-by-schedule", listBusesBySchedule);
router.post("/buses", verifyAdmin, addBus);
router.put("/buses/:id", verifyAdmin, updateBus);
router.delete("/buses/:id", verifyAdmin, deleteBus);

router.get("/drivers", listDrivers);
router.post("/drivers", verifyAdmin, addDriver);
router.put("/drivers/:id", verifyAdmin, updateDriver);
router.delete("/drivers/:id", verifyAdmin, deleteDriver);
router.post("/drivers/assign", verifyAdmin, assignDriver);

router.get("/routes", listRoutes);
router.post("/routes", verifyAdmin, addRoute);
router.put("/routes/:id", verifyAdmin, updateRoute);
router.delete("/routes/:id", verifyAdmin, deleteRoute);

router.post("/passenger-count", uploadPassengerCount);
router.get("/passengers", listPassengers);
router.get("/tracking/:busId", getTracking);
router.post("/gps", uploadGPS);
router.post("/alerts", verifyAdmin, createAlert);
router.get("/alerts", listAlerts);
router.post("/maintenance", verifyAdmin, addMaintenance);
router.get("/maintenance", listMaintenance);
router.get("/live-tracking", listLiveTracking);

module.exports = router;
