const express = require("express");
const multer = require("multer");
const path = require("path");
const router = express.Router();
const { verifyAdmin } = require("../middleware/authMiddleware");
const {
  getLostItems,
  createLostItem,
  updateLostItem,
  deleteLostItem,
  getFoundItems,
  createFoundItem,
  updateFoundItem,
  deleteFoundItem,
  matchItem,
  markReadyForCollection,
  markReturned,
} = require("../controllers/lostFoundController");

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, path.join(__dirname, "..", "uploads"));
  },
  filename: (req, file, cb) => {
    const timestamp = Date.now();
    const safeName = file.originalname.replace(/[^a-zA-Z0-9\.\-_]/g, "_");
    cb(null, `${timestamp}-${safeName}`);
  },
});

const upload = multer({ storage });

router.get("/lostitems", getLostItems);
router.post("/lostitems", upload.single("image"), createLostItem);
router.put("/lostitems/:id", upload.single("image"), updateLostItem);
router.delete("/lostitems/:id", deleteLostItem);

router.get("/founditems", getFoundItems);
router.post("/founditems", verifyAdmin, upload.single("image"), createFoundItem);
router.put("/founditems/:id", verifyAdmin, upload.single("image"), updateFoundItem);
router.delete("/founditems/:id", verifyAdmin, deleteFoundItem);

router.post("/match", verifyAdmin, matchItem);
router.put("/lostitems/:id/ready", verifyAdmin, markReadyForCollection);
router.put("/lostitems/:id/returned", verifyAdmin, markReturned);

module.exports = router;
