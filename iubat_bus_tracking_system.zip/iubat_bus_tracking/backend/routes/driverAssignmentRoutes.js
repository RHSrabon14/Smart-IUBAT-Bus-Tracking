const express = require("express");
const router = express.Router();
const { verifyAdmin } = require("../middleware/authMiddleware");
const {
  createAssignment,
  listAssignments,
  listAssignmentsBySchedule,
  getDashboardStats,
} = require("../controllers/driverAssignmentController");

router.get(["/", ""], listAssignments);
router.get("/stats", getDashboardStats);
router.get("/schedule/:scheduleType", listAssignmentsBySchedule);
router.post(["/", ""], verifyAdmin, createAssignment);

module.exports = router;
