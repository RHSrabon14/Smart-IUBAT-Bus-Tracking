const express = require("express");
const router = express.Router();
const { createPerformance, listPerformance, getPerformanceSummary } = require("../controllers/performanceController");

router.post("/", createPerformance);
router.get("/", listPerformance);
router.get("/summary", getPerformanceSummary);

module.exports = router;
