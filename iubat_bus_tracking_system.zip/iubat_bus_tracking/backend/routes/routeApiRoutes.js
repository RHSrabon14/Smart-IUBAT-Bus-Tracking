const express = require("express");
const router = express.Router();
const { verifyAdmin } = require("../middleware/authMiddleware");
const {
  listMorningRoutes,
  createMorningRoute,
  updateMorningRoute,
  deleteMorningRoute,
  listEveningRoutes,
  createEveningRoute,
  updateEveningRoute,
  deleteEveningRoute,
  listShuttleRoutes,
  createShuttleRoute,
  updateShuttleRoute,
  deleteShuttleRoute,
  listDrivers,
  listBuses,
} = require("../controllers/routeApiController");

router.get("/morning", listMorningRoutes);
router.post("/morning", verifyAdmin, createMorningRoute);
router.put("/morning/:id", verifyAdmin, updateMorningRoute);
router.delete("/morning/:id", verifyAdmin, deleteMorningRoute);

router.get("/evening", listEveningRoutes);
router.post("/evening", verifyAdmin, createEveningRoute);
router.put("/evening/:id", verifyAdmin, updateEveningRoute);
router.delete("/evening/:id", verifyAdmin, deleteEveningRoute);

router.get("/shuttle", listShuttleRoutes);
router.post("/shuttle", verifyAdmin, createShuttleRoute);
router.put("/shuttle/:id", verifyAdmin, updateShuttleRoute);
router.delete("/shuttle/:id", verifyAdmin, deleteShuttleRoute);

router.get("/drivers", listDrivers);
router.get("/buses", listBuses);

module.exports = router;
