const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const router = express.Router();

// ===========================
// Configure Multer for Image Uploads
// ===========================
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = './uploads/bus-images';
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const timestamp = Date.now();
        const busId = req.body.busId || 'unknown';
        cb(null, `${busId}_${timestamp}.jpg`);
    }
});

const upload = multer({
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// ===========================
// In-memory storage (replace with MongoDB if needed)
// ===========================
let busDataStore = [];
const MAX_STORED = 1000;

// ===========================
// POST /api/bus/upload
// Receives data from ESP32-CAM
// ===========================
router.post('/upload', upload.single('image'), async (req, res) => {
    try {
        console.log('\n📥 Received bus data:');
        console.log('   Bus ID:', req.body.busId || 'Unknown');
        console.log('   Route:', req.body.routeId || 'Unknown');
        console.log('   Image size:', req.file ? req.file.size : 'No image');
        console.log('   Passengers:', req.body.passengerCount || 0);
        console.log('   GPS:', req.body.latitude, req.body.longitude);

        // Extract data from request
        const busData = {
            busId: req.body.busId || 'BUS-001',
            routeId: req.body.routeId || 'ROUTE-01',
            passengerCount: parseInt(req.body.passengerCount) || 0,
            latitude: parseFloat(req.body.latitude) || 0,
            longitude: parseFloat(req.body.longitude) || 0,
            speed: parseFloat(req.body.speed) || 0,
            satellites: parseInt(req.body.satellites) || 0,
            gpsFixed: req.body.gpsFixed === 'true',
            timestamp: new Date().toISOString(),
            imagePath: req.file ? req.file.path : null,
            imageUrl: req.file ? `/uploads/bus-images/${req.file.filename}` : null,
            imageSize: req.file ? req.file.size : 0
        };

        // ===========================
        // Store in memory (for testing)
        // ===========================
        busDataStore.push(busData);
        if (busDataStore.length > MAX_STORED) {
            busDataStore.shift();
        }

        // ===========================
        // If you want to store in MongoDB:
        // Uncomment this section
        // ===========================
        /*
        const BusData = require('../models/BusData');
        const savedData = await BusData.create(busData);
        console.log('   ✅ Saved to MongoDB:', savedData._id);
        */

        console.log('✅ Data saved successfully!');
        console.log(`   📍 Location: ${busData.latitude}, ${busData.longitude}`);
        console.log(`   👥 Passengers: ${busData.passengerCount}`);
        console.log(`   🖼️ Image: ${busData.imageSize} bytes`);
        console.log(`   📊 Total records: ${busDataStore.length}`);

        res.status(200).json({
            success: true,
            message: 'Bus data uploaded successfully',
            data: busData
        });

    } catch (error) {
        console.error('❌ Upload error:', error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ===========================
// GET /api/bus/latest/:busId
// Get latest data for a specific bus
// ===========================
router.get('/latest/:busId', (req, res) => {
    try {
        const busId = req.params.busId;
        const latest = busDataStore.filter(d => d.busId === busId).pop();

        if (latest) {
            res.json({
                success: true,
                data: latest
            });
        } else {
            res.status(404).json({
                success: false,
                message: 'No data found for this bus'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ===========================
// GET /api/bus/data
// Get all bus data (with optional limit)
// ===========================
router.get('/data', (req, res) => {
    try {
        const limit = parseInt(req.query.limit) || 20;
        const busId = req.query.busId;
        
        let data = busDataStore;
        if (busId) {
            data = data.filter(d => d.busId === busId);
        }
        
        const result = data.slice(-limit).reverse();

        res.json({
            success: true,
            data: result,
            count: result.length,
            total: data.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ===========================
// GET /api/bus/stats/:busId
// Get statistics for a bus
// ===========================
router.get('/stats/:busId', (req, res) => {
    try {
        const busId = req.params.busId;
        const data = busDataStore.filter(d => d.busId === busId);

        if (data.length === 0) {
            return res.json({
                success: true,
                busId: busId,
                totalReports: 0,
                averagePassengers: 0,
                lastUpdate: null
            });
        }

        const avgPassengers = data.reduce((sum, d) => sum + d.passengerCount, 0) / data.length;
        const latest = data[data.length - 1];

        res.json({
            success: true,
            busId: busId,
            totalReports: data.length,
            averagePassengers: Math.round(avgPassengers),
            lastUpdate: latest.timestamp,
            lastLocation: {
                latitude: latest.latitude,
                longitude: latest.longitude
            },
            lastPassengerCount: latest.passengerCount
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ===========================
// GET /api/bus/health
// Health check endpoint
// ===========================
router.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        records: busDataStore.length,
        uptime: process.uptime()
    });
});

// ===========================
// DELETE /api/bus/clear
// Clear all data (for testing)
// ===========================
router.delete('/clear', (req, res) => {
    busDataStore = [];
    res.json({
        success: true,
        message: 'All bus data cleared'
    });
});

module.exports = router;