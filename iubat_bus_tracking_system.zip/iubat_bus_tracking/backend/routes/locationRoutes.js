const express = require("express");
const router = express.Router();
const {
  updateLocation,
  getBusLocation,
  getAllBusLocations,
  getLocationHistory
} = require("../controllers/locationController");

// POST /api/location/update - Receive GPS coordinates from ESP32
router.post("/update", updateLocation);

// GET /api/location/history/:busId - Get location history
router.get("/history/:busId", getLocationHistory);

// GET /api/location/all - Get live data for all buses
router.get("/all", getAllBusLocations);

// GET /api/location/:busId - Get single bus live location
router.get("/:busId", getBusLocation);

module.exports = router;