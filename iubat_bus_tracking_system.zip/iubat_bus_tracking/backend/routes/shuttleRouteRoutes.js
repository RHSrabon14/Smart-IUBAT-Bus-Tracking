const express = require("express");
const router = express.Router();
const {
  getShuttleRoutes,
  getShuttleRoute
} = require("../controllers/shuttleRouteController");

// GET /api/shuttle-routes - Get all shuttle routes dynamically
router.get("/", getShuttleRoutes);

// GET /api/shuttle-routes/:id - Get single shuttle route
router.get("/:id", getShuttleRoute);

module.exports = router;