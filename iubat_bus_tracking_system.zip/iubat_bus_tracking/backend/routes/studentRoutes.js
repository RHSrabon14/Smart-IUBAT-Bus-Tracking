const express = require("express");
const router = express.Router();
const Student = require("../models/Student");
const bcrypt = require("bcryptjs");

// LOGIN
router.post("/login", async (req, res) => {
  const { studentId, password } = req.body;

  try {
    const student = await Student.findOne({ studentId });

    if (!student) {
      return res.status(400).json({ msg: "Invalid Student ID" });
    }

    const isMatch = await bcrypt.compare(password, student.password);

    if (!isMatch) {
      return res.status(400).json({ msg: "Wrong Password" });
    }

    res.json({ msg: "Login Successful", student });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;