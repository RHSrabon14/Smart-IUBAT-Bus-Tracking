const express = require("express");
const router = express.Router();
const Faculty = require("../models/Faculty");
const bcrypt = require("bcryptjs");

// LOGIN
router.post("/login", async (req, res) => {
  const { email, password } = req.body;

  try {
    const faculty = await Faculty.findOne({ email });

    if (!faculty) {
      return res.status(400).json({ msg: "Invalid Email" });
    }

    const isMatch = await bcrypt.compare(password, faculty.password);

    if (!isMatch) {
      return res.status(400).json({ msg: "Wrong Password" });
    }

    res.json({ msg: "Login Successful", faculty });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;