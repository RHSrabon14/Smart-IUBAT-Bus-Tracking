﻿from PIL import Image
import requests
import json

img_path = r'D:\iubat_bus_tracking\backend\uploads\bus-images\test_upload_001.jpg'
Image.new('RGB', (10, 10), 'red').save(img_path, format='JPEG')

coords = [
    ('23.7937','90.4066','14.5','7','true'),
    ('23.7942','90.4072','16.0','8','true'),
    ('23.7950','90.4081','18.5','9','true'),
]

for i, (lat, lon, speed, sats, fixed) in enumerate(coords, 1):
    with open(img_path, 'rb') as f:
        files = {'image': ('cam.jpg', f, 'image/jpeg')}
        data = {
            'busId': 'BUS-001',
            'routeId': 'ROUTE-01',
            'latitude': lat,
            'longitude': lon,
            'speed': speed,
            'satellites': sats,
            'gpsFixed': fixed,
        }
        r = requests.post('http://localhost:5000/api/bus/upload', files=files, data=data, timeout=40)
        print(f'UPLOAD {i} STATUS {r.status_code}')
        print(r.text)

r = requests.get('http://localhost:5000/api/location/BUS-001', timeout=20)
print('GET LOCATION STATUS', r.status_code)
print(r.text)
