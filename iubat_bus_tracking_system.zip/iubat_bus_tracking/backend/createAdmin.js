require("dotenv").config();
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const Admin = require("./models/Admin");

const { ADMIN_USERNAME, ADMIN_EMAIL, ADMIN_PASSWORD, MONGO_URI } = process.env;

if (!MONGO_URI || !ADMIN_USERNAME || !ADMIN_EMAIL || !ADMIN_PASSWORD) {
  console.error("Set MONGO_URI, ADMIN_USERNAME, ADMIN_EMAIL, and ADMIN_PASSWORD in backend/.env before creating the admin.");
  process.exit(1);
}

// Connect to MongoDB
mongoose.connect(MONGO_URI)
  .then(async () => {
    console.log("✅ Connected to MongoDB");

    // Check if admin already exists
    const existingAdmin = await Admin.findOne({ email: ADMIN_EMAIL });

    if (existingAdmin) {
      console.log("❌ Admin already exists");
      process.exit(0);
    }

    // Create admin user
    const hashedPassword = await bcrypt.hash(ADMIN_PASSWORD, 10);

    const admin = new Admin({
      username: ADMIN_USERNAME,
      email: ADMIN_EMAIL,
      password: hashedPassword
    });

    await admin.save();

    console.log("✅ Admin user created successfully!");
    console.log(`📧 Email: ${ADMIN_EMAIL}`);

    process.exit(0);
  })
  .catch((err) => {
    console.log("❌ MongoDB Error:", err.message);
    process.exit(1);
  });