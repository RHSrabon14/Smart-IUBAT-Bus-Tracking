require("dotenv").config();

const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const axios = require("axios");
const FormData = require("form-data");
const BusExperimentLog = require("./models/BusExperimentLog");
const { applyRouteMappingToBus } = require("./services/routeMappingService");

const calculateAbsoluteCountError = (groundTruth, yoloPassengerCount) => {
    if (groundTruth === null || groundTruth === undefined || yoloPassengerCount === null || yoloPassengerCount === undefined) {
        return null;
    }

    return Math.abs(Number(groundTruth) - Number(yoloPassengerCount));
};

const app = express();

// =============================================
// MIDDLEWARE
// =============================================
app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Increase timeout for large uploads
app.use((req, res, next) => {
    req.setTimeout(60000);
    res.setTimeout(60000);
    next();
});

// =============================================
// MULTER CONFIGURATION - For Image Uploads
// =============================================
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const dir = './uploads/bus-images';
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const timestamp = Date.now();
        const busId = req.body.busId || 'unknown';
        cb(null, `${busId}_${timestamp}.jpg`);
    }
});

const upload = multer({
    storage: storage,
    limits: { 
        fileSize: 10 * 1024 * 1024,
        fieldSize: 10 * 1024 * 1024
    }
});

// =============================================
// ROUTES IMPORT
// =============================================
const studentRoutes = require("./routes/studentRoutes");
const facultyRoutes = require("./routes/facultyRoutes");
const routeRoutes = require("./routes/routeRoutes");
const routeApiRoutes = require("./routes/routeApiRoutes");
const driverAssignmentRoutes = require("./routes/driverAssignmentRoutes");
const lostFoundRoutes = require("./routes/lostFoundRoutes");
const adminRoutes = require("./routes/adminRoutes");
const authRoutes = require("./routes/authRoutes");
const locationRoutes = require("./routes/locationRoutes");
const shuttleRouteRoutes = require("./routes/shuttleRouteRoutes");
const transportRoutes = require("./routes/transportRoutes");
const performanceRoutes = require("./routes/performanceRoutes");

const buildExperimentRecord = (req) => {
    const busId = req.body.busId || 'BUS-001';
    const routeId = req.body.routeId || 'ROUTE-01';
    const latitude = parseFloat(req.body.latitude) || 0;
    const longitude = parseFloat(req.body.longitude) || 0;
    const speed = parseFloat(req.body.speed) || 0;
    const satellites = parseInt(req.body.satellites, 10) || 0;
    const gpsFixed = req.body.gpsFixed === 'true' || req.body.gpsFixed === true || req.body.gpsFixed === 1;

    return {
        trialId: `trial-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        busId,
        routeId,
        serverReceivedAt: new Date(),
        imageFileName: req.file ? req.file.filename : null,
        imageFileId: req.file ? req.file.filename : null,
        imageSizeBytes: req.file ? req.file.size : 0,
        imageReceivedAt: req.file ? new Date() : null,
        imageStorageCompletedAt: null,
        imageStorageDurationMs: null,
        latitude,
        longitude,
        speed,
        satellites,
        gpsFixed,
        yoloRequestStartedAt: null,
        yoloResponseAt: null,
        yoloProcessingDurationMs: null,
        yoloPassengerCount: null,
        processingDurationMs: null,
        endToEndDurationMs: null,
        uploadSuccess: false,
        imageTransmissionSuccess: !!req.file,
        yoloSuccess: false,
        httpStatusCode: null,
        errorMessage: null,
        groundTruthPassengerCount: null,
        absoluteCountError: null,
    };
};

const saveExperimentRecord = async (record) => {
    if (!record || !record.trialId) {
        return null;
    }

    record.absoluteCountError = calculateAbsoluteCountError(
        record.groundTruthPassengerCount,
        record.yoloPassengerCount
    );

    try {
        const doc = await BusExperimentLog.create(record);
        console.log('📊 EXPERIMENTAL RECORD');
        console.log('Trial ID:', doc.trialId);
        console.log('Bus:', doc.busId);
        console.log('Image size:', doc.imageSizeBytes, 'bytes');
        console.log('Image received:', doc.imageReceivedAt);
        console.log('Image storage time:', doc.imageStorageDurationMs, 'ms');
        console.log('GPS:', doc.latitude, doc.longitude);
        console.log('Satellites:', doc.satellites);
        console.log('GPS fixed:', doc.gpsFixed);
        console.log('YOLO count:', doc.yoloPassengerCount);
        console.log('YOLO processing time:', doc.yoloProcessingDurationMs, 'ms');
        console.log('End-to-end time:', doc.endToEndDurationMs, 'ms');
        console.log('Upload success:', doc.uploadSuccess ? 'YES' : 'NO');
        console.log('YOLO success:', doc.yoloSuccess ? 'YES' : 'NO');
        return doc;
    } catch (error) {
        console.error('❌ Experimental log save failed:', error.message);
        return null;
    }
};

// =============================================
// ROUTES USE
// =============================================
app.use("/api/students", studentRoutes);
app.use("/api/faculty", facultyRoutes);
app.use("/api/routes", routeRoutes);
app.use("/api/routes", routeApiRoutes);
app.use("/api", lostFoundRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/location", locationRoutes);
app.use("/api/shuttle-routes", shuttleRouteRoutes);
app.use("/api/transport", transportRoutes);
app.use("/api/assignments", driverAssignmentRoutes);
app.use("/api/performance", performanceRoutes);

// =============================================
// BUS TRACKING ROUTES
// =============================================

// =============================================
// POST /api/bus/upload
// Receives image + GPS data from ESP32-CAM
// =============================================
app.post("/api/bus/upload", upload.single('image'), async (req, res) => {
    // 🔥 DEBUG LINE - TO SEE IF ENDPOINT IS HIT
    console.log('🔥🔥🔥 UPLOAD ENDPOINT WAS HIT! 🔥🔥🔥');
    
    const uploadStartTime = Date.now();
    const experimentRecord = buildExperimentRecord(req);

    try {
        console.log('\n📥 Received from ESP32-CAM:');
        console.log('   Bus ID:', req.body.busId || 'Unknown');
        console.log('   Image:', req.file ? req.file.filename : 'No image');
        console.log('   Image Size:', req.file ? req.file.size : 0);
        console.log('   GPS:', req.body.latitude, req.body.longitude);
        console.log('   Speed:', req.body.speed || 0);
        console.log('   Satellites:', req.body.satellites || 0);

        // =============================================
        // STEP 1: Save Image
        // =============================================
        const imagePath = req.file ? req.file.path : null;
        const imageUrl = req.file ? `/uploads/bus-images/${req.file.filename}` : null;
        if (req.file && imagePath && fs.existsSync(imagePath)) {
            experimentRecord.imageStorageCompletedAt = new Date();
            experimentRecord.imageReceivedAt = experimentRecord.imageReceivedAt || new Date();
            experimentRecord.imageStorageDurationMs = Math.max(0, experimentRecord.imageStorageCompletedAt.getTime() - experimentRecord.imageReceivedAt.getTime());
            experimentRecord.imageTransmissionSuccess = true;
        }

        // =============================================
        // STEP 2: Create Bus Data Object
        // =============================================
        const busData = {
            busId: req.body.busId || 'BUS-001',
            routeId: req.body.routeId || 'ROUTE-01',
            passengerCount: 0, // Will be updated by YOLO
            latitude: parseFloat(req.body.latitude) || 0,
            longitude: parseFloat(req.body.longitude) || 0,
            speed: parseFloat(req.body.speed) || 0,
            satellites: parseInt(req.body.satellites) || 0,
            gpsFixed: req.body.gpsFixed === 'true' || req.body.gpsFixed === true,
            imagePath: imagePath,
            imageUrl: imageUrl,
            imageSize: req.file ? req.file.size : 0,
            timestamp: new Date().toISOString(),
            processing: true // YOLO is processing
        };

        // =============================================
        // STEP 3: Save to MongoDB (BusData) and update Location/Bus
        // =============================================
        const BusData = require('./models/BusData');
        const Bus = require('./models/Bus');
        const Location = require('./models/Location');

        const savedData = await BusData.create(busData);
        console.log('✅ Data saved to MongoDB (processing):', savedData._id);

        const gpsTimestamp = new Date(busData.timestamp);
        const gpsFixedValue = !!(req.body.gpsFixed === 'true' || req.body.gpsFixed === true || req.body.gpsFixed === 1);

        console.log('📍 Updating live bus location');
        console.log('🚌 Bus ID:', busData.busId);
        console.log('📍 Latitude:', busData.latitude);
        console.log('📍 Longitude:', busData.longitude);
        console.log('🚗 Speed:', busData.speed || 0);
        console.log('🛰️ Satellites:', busData.satellites || 0);
        console.log('📊 GPS Fixed:', gpsFixedValue);

        // Create a location history record for the live GPS feed
        try {
            const locationRecord = await Location.create({
                busId: busData.busId,
                latitude: busData.latitude,
                longitude: busData.longitude,
                timestamp: gpsTimestamp,
                speed: busData.speed || 0,
                satellites: busData.satellites || 0,
                gpsFixed: gpsFixedValue,
            });
            console.log('✅ Location history saved:', busData.busId, locationRecord._id);
        } catch (locErr) {
            console.error('❌ Location save failed:', locErr.message);
        }

        // Update Bus current location and passenger count (so frontend can read)
        try {
            const updatedBus = await Bus.findOneAndUpdate(
                { busId: busData.busId },
                {
                    $set: {
                        busNumber: busData.busId,
                        status: 'active',
                        currentLocation: {
                            latitude: busData.latitude,
                            longitude: busData.longitude,
                            timestamp: gpsTimestamp
                        },
                        currentSpeed: busData.speed || 0,
                        currentPassengerCount: busData.passengerCount || 0,
                        satellites: busData.satellites || 0,
                        gpsFixed: gpsFixedValue,
                        lastUpdated: new Date()
                    }
                },
                { upsert: true, new: true, setDefaultsOnInsert: true }
            );
            await applyRouteMappingToBus(busData.busId, busData.routeId);
            console.log('✅ Bus document updated:', updatedBus ? updatedBus.busId : busData.busId);
        } catch (busErr) {
            console.error('❌ Bus update failed:', busErr.message);
        }

        // =============================================
        // STEP 4: Call YOLO Server for Detection (if image present)
        // =============================================
        if (imagePath && fs.existsSync(imagePath)) {
            console.log('🔄 Sending to YOLO for detection...');
            
            const formData = new FormData();
            formData.append('image', fs.createReadStream(imagePath));
            formData.append('busId', req.body.busId || 'BUS-001');
            formData.append('latitude', req.body.latitude || 0);
            formData.append('longitude', req.body.longitude || 0);
            
            try {
                // Call YOLO Server (use environment variable or default)
                const yoloUrl = process.env.YOLO_SERVER_URL || 'http://localhost:5001';
                console.log(`   YOLO URL: ${yoloUrl}/detect`);
                
                experimentRecord.yoloRequestStartedAt = new Date();
                const yoloResponse = await axios.post(
                    `${yoloUrl}/detect`,
                    formData,
                    {
                        headers: {
                            ...formData.getHeaders(),
                            'Content-Type': 'multipart/form-data'
                        },
                        timeout: 30000 // 30 second timeout
                    }
                );
                experimentRecord.yoloResponseAt = new Date();
                experimentRecord.yoloProcessingDurationMs = Math.max(0, experimentRecord.yoloResponseAt.getTime() - experimentRecord.yoloRequestStartedAt.getTime());
                
                console.log('✅ YOLO Response received');
                console.log('   Passenger Count:', yoloResponse.data.passengerCount || 0);
                console.log('   Total Detections:', yoloResponse.data.totalDetections || 0);
                
                // =============================================
                // STEP 5: Update MongoDB with Passenger Count
                // =============================================
                const passengerCount = yoloResponse.data.passengerCount || 0;
                
                await BusData.findByIdAndUpdate(savedData._id, {
                    passengerCount: passengerCount,
                    processing: false,
                    detections: yoloResponse.data.detections || [],
                    totalDetections: yoloResponse.data.totalDetections || 0,
                    yoloTimestamp: yoloResponse.data.timestamp || new Date().toISOString()
                });

                // Update Bus current passenger count
                try {
                    await Bus.findOneAndUpdate(
                        { busId: busData.busId },
                        { $set: { currentPassengerCount: passengerCount, lastUpdated: new Date() } },
                        { new: true }
                    );
                } catch (busUpdateErr) {
                    console.warn('⚠️ Failed to update Bus passenger count:', busUpdateErr.message);
                }
                
                console.log(`✅ Updated passenger count: ${passengerCount}`);
                experimentRecord.yoloPassengerCount = passengerCount;
                experimentRecord.yoloSuccess = true;
                experimentRecord.uploadSuccess = true;
                experimentRecord.httpStatusCode = 200;
                experimentRecord.processingDurationMs = Date.now() - uploadStartTime;
                experimentRecord.endToEndDurationMs = experimentRecord.processingDurationMs;
                
                // =============================================
                // STEP 6: Send Response Back to ESP32
                // Include passengerCount at root for ESP32 parsing
                // =============================================
                res.status(200).json({
                    success: true,
                    passengerCount: passengerCount,
                    busId: busData.busId,
                    routeId: busData.routeId || null,
                    message: 'Bus data uploaded and processed',
                    data: {
                        ...busData,
                        passengerCount: passengerCount,
                        processing: false
                    }
                });
                await saveExperimentRecord(experimentRecord);
                
            } catch (yoloError) {
                console.error('❌ YOLO Error:', yoloError.message);
                if (yoloError.response) {
                    console.error('   Response Status:', yoloError.response.status);
                    console.error('   Response Data:', yoloError.response.data);
                }
                
                // Mark as failed but keep data
                await BusData.findByIdAndUpdate(savedData._id, {
                    processing: false,
                    error: yoloError.message
                });

                // Ensure Bus record has processing false
                try {
                    await Bus.findOneAndUpdate(
                        { busId: busData.busId },
                        { $set: { lastUpdated: new Date() } },
                        { new: true }
                    );
                } catch (busErr) {
                    console.warn('⚠️ Failed to update Bus after YOLO error:', busErr.message);
                }
                
                experimentRecord.errorMessage = yoloError.message;
                experimentRecord.uploadSuccess = true;
                experimentRecord.httpStatusCode = 200;
                experimentRecord.processingDurationMs = Date.now() - uploadStartTime;
                experimentRecord.endToEndDurationMs = experimentRecord.processingDurationMs;
                experimentRecord.yoloSuccess = false;
                
                // Return 200 so ESP32 still gets a response, include passengerCount as 0
                res.status(200).json({
                    success: true,
                    passengerCount: 0,
                    busId: busData.busId,
                    routeId: busData.routeId || null,
                    message: 'Data saved but YOLO processing failed',
                    data: busData,
                    yoloError: yoloError.message
                });
                await saveExperimentRecord(experimentRecord);
            }
        } else {
            // No image, just return data
            await BusData.findByIdAndUpdate(savedData._id, {
                processing: false
            });

            // Update Bus passenger count (if provided by ESP32) and lastUpdated
            try {
                await Bus.findOneAndUpdate(
                    { busId: busData.busId },
                    { $set: { currentPassengerCount: busData.passengerCount || 0, lastUpdated: new Date() } },
                    { upsert: true, new: true }
                );
            } catch (busErr) {
                console.warn('⚠️ Failed to update Bus record (no image):', busErr.message);
            }
            
            experimentRecord.uploadSuccess = true;
            experimentRecord.httpStatusCode = 200;
            experimentRecord.processingDurationMs = Date.now() - uploadStartTime;
            experimentRecord.endToEndDurationMs = experimentRecord.processingDurationMs;
            res.status(200).json({
                success: true,
                passengerCount: busData.passengerCount || 0,
                busId: busData.busId,
                routeId: busData.routeId || null,
                message: 'Bus data saved (no image)',
                data: busData
            });
            await saveExperimentRecord(experimentRecord);
        }
        
    } catch (error) {
        experimentRecord.errorMessage = error.message;
        experimentRecord.httpStatusCode = 500;
        experimentRecord.processingDurationMs = Date.now() - uploadStartTime;
        experimentRecord.endToEndDurationMs = experimentRecord.processingDurationMs;
        console.error('❌ Error:', error.message);
        res.status(500).json({
            success: false,
            error: error.message
        });
        await saveExperimentRecord(experimentRecord);
    }
});

app.get('/api/experiments', async (req, res) => {
    try {
        const busId = req.query.busId;
        const query = busId ? { busId } : {};
        const records = await BusExperimentLog.find(query).sort({ createdAt: -1 }).lean();
        res.status(200).json({ success: true, count: records.length, data: records });
    } catch (error) {
        console.error('❌ Error fetching experiments:', error.message);
        res.status(500).json({ success: false, message: error.message });
    }
});

app.get('/api/experiments/stats/:busId', async (req, res) => {
    try {
        const { busId } = req.params;
        const records = await BusExperimentLog.find({ busId }).lean();

        const totalUploads = records.length;
        const successfulUploads = records.filter((r) => r.uploadSuccess === true).length;
        const failedUploads = totalUploads - successfulUploads;
        const imageTransmissionSuccessRate = totalUploads > 0 ? (records.filter((r) => r.imageTransmissionSuccess === true).length / totalUploads) * 100 : 0;
        const averageImageSize = totalUploads > 0 ? records.reduce((sum, r) => sum + (r.imageSizeBytes || 0), 0) / totalUploads : 0;
        const averageProcessingTime = totalUploads > 0 ? records.reduce((sum, r) => sum + (r.processingDurationMs || 0), 0) / totalUploads : 0;
        const averageYoloProcessingTime = totalUploads > 0 ? records.reduce((sum, r) => sum + (r.yoloProcessingDurationMs || 0), 0) / totalUploads : 0;
        const averageEndToEndLatency = totalUploads > 0 ? records.reduce((sum, r) => sum + (r.endToEndDurationMs || 0), 0) / totalUploads : 0;
        const gpsFixSuccessRate = totalUploads > 0 ? (records.filter((r) => r.gpsFixed === true).length / totalUploads) * 100 : 0;
        const averageSatellites = totalUploads > 0 ? records.reduce((sum, r) => sum + (r.satellites || 0), 0) / totalUploads : 0;

        const yoloDetectionCountDistribution = records.reduce((acc, r) => {
            const count = r.yoloPassengerCount ?? 0;
            acc[count] = (acc[count] || 0) + 1;
            return acc;
        }, {});

        res.status(200).json({
            success: true,
            busId,
            totalUploads,
            successfulUploads,
            failedUploads,
            imageTransmissionSuccessRate,
            averageImageSize,
            averageProcessingTime,
            averageYoloProcessingTime,
            averageEndToEndLatency,
            gpsFixSuccessRate,
            averageSatellites,
            yoloDetectionCountDistribution,
        });
    } catch (error) {
        console.error('❌ Error generating experiment stats:', error.message);
        res.status(500).json({ success: false, message: error.message });
    }
});

app.get('/api/experiments/:busId', async (req, res) => {
    try {
        const { busId } = req.params;
        const records = await BusExperimentLog.find({ busId }).sort({ createdAt: -1 }).lean();
        res.status(200).json({ success: true, count: records.length, data: records });
    } catch (error) {
        console.error('❌ Error fetching bus experiment records:', error.message);
        res.status(500).json({ success: false, message: error.message });
    }
});

app.get('/api/experiments/export', async (req, res) => {
    try {
        const { busId, format = 'json' } = req.query;
        const query = busId ? { busId } : {};
        const records = await BusExperimentLog.find(query).sort({ createdAt: -1 }).lean();

        if (String(format).toLowerCase() === 'csv') {
            const keys = [
                'trialId', 'busId', 'routeId', 'serverReceivedAt', 'imageFileName', 'imageFileId', 'imageSizeBytes',
                'imageReceivedAt', 'imageStorageCompletedAt', 'imageStorageDurationMs', 'latitude', 'longitude',
                'speed', 'satellites', 'gpsFixed', 'yoloRequestStartedAt', 'yoloResponseAt', 'yoloProcessingDurationMs',
                'yoloPassengerCount', 'processingDurationMs', 'endToEndDurationMs', 'uploadSuccess', 'imageTransmissionSuccess',
                'yoloSuccess', 'httpStatusCode', 'errorMessage', 'groundTruthPassengerCount', 'absoluteCountError'
            ];

            const csvRows = [keys.join(',')];
            records.forEach((record) => {
                const row = keys.map((key) => {
                    const value = record[key];
                    const safeValue = value === null || value === undefined ? '' : String(value).replace(/"/g, '""');
                    return `"${safeValue}"`;
                });
                csvRows.push(row.join(','));
            });

            res.setHeader('Content-Type', 'text/csv');
            res.setHeader('Content-Disposition', 'attachment; filename="bus_experiments.csv"');
            return res.status(200).send(csvRows.join('\n'));
        }

        return res.status(200).json({ success: true, count: records.length, data: records });
    } catch (error) {
        console.error('❌ Error exporting experiment records:', error.message);
        res.status(500).json({ success: false, message: error.message });
    }
});

// =============================================
// GET /api/bus/latest/:busId
// Get latest data for a specific bus
// =============================================
app.get("/api/bus/latest/:busId", async (req, res) => {
    try {
        const BusData = require('./models/BusData');
        const busId = req.params.busId;
        const latest = await BusData.findOne({ busId }).sort({ createdAt: -1 });
        
        if (latest) {
            res.json({
                success: true,
                data: latest
            });
        } else {
            res.status(404).json({
                success: false,
                message: 'No data found for this bus'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// =============================================
// GET /api/bus/data (All buses or filter by busId)
// Example: /api/bus/data?busId=BUS-001&limit=10
// =============================================
app.get("/api/bus/data", async (req, res) => {
    try {
        const BusData = require('./models/BusData');
        const busId = req.query.busId;
        const limit = parseInt(req.query.limit) || 20;
        
        let query = {};
        if (busId) query.busId = busId;
        
        const data = await BusData.find(query)
            .sort({ createdAt: -1 })
            .limit(limit);
        
        res.json({
            success: true,
            data: data,
            count: data.length,
            total: await BusData.countDocuments(query)
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// =============================================
// GET /api/bus/data/:busId
// Get data for a specific bus (with limit)
// =============================================
app.get("/api/bus/data/:busId", async (req, res) => {
    try {
        const BusData = require('./models/BusData');
        const busId = req.params.busId;
        const limit = parseInt(req.query.limit) || 20;
        
        const data = await BusData.find({ busId: busId })
            .sort({ createdAt: -1 })
            .limit(limit);
        
        if (data.length > 0) {
            res.json({
                success: true,
                data: data,
                count: data.length,
                total: await BusData.countDocuments({ busId: busId })
            });
        } else {
            res.status(404).json({
                success: false,
                message: 'No data found for this bus'
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// =============================================
// GET /api/bus/stats/:busId
// Get statistics for a bus
// =============================================
app.get("/api/bus/stats/:busId", async (req, res) => {
    try {
        const BusData = require('./models/BusData');
        const busId = req.params.busId;
        
        const data = await BusData.find({ busId: busId })
            .sort({ createdAt: -1 })
            .limit(100);
        
        if (data.length === 0) {
            return res.json({
                success: true,
                busId: busId,
                totalReports: 0,
                averagePassengers: 0,
                lastUpdate: null
            });
        }
        
        const totalPassengers = data.reduce((sum, d) => sum + d.passengerCount, 0);
        const avgPassengers = totalPassengers / data.length;
        const latest = data[0];
        
        res.json({
            success: true,
            busId: busId,
            totalReports: data.length,
            averagePassengers: Math.round(avgPassengers),
            lastUpdate: latest.timestamp,
            lastLocation: {
                latitude: latest.latitude,
                longitude: latest.longitude
            },
            lastPassengerCount: latest.passengerCount,
            lastSpeed: latest.speed
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// =============================================
// GET /api/bus/health
// Health check endpoint
// =============================================
app.get("/api/bus/health", async (req, res) => {
    try {
        const BusData = require('./models/BusData');
        const count = await BusData.countDocuments();
        
        res.json({
            status: 'OK',
            timestamp: new Date().toISOString(),
            records: count,
            uptime: process.uptime()
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// =============================================
// DELETE /api/bus/clear (For testing)
// Clear all bus data
// =============================================
app.delete("/api/bus/clear", async (req, res) => {
    try {
        const BusData = require('./models/BusData');
        await BusData.deleteMany({});
        
        res.json({
            success: true,
            message: 'All bus data cleared'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// =============================================
// ROOT TEST
// =============================================
app.get("/", (req, res) => {
    res.send("🚌 IUBAT Bus Backend Running");
});

// =============================================
// MONGODB CONNECT
// Retry failed initial connections with backoff. The API can still start,
// while database-backed endpoints return 503 until MongoDB is available.
// =============================================
let reconnectDelayMs = 5000;
const connectMongo = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI, { serverSelectionTimeoutMS: 10000 });
        console.log("✅ MongoDB Connected Successfully");
        reconnectDelayMs = 5000;
    } catch (err) {
        console.error("❌ MongoDB Error:", err.message);
        console.log(`🔁 Retrying MongoDB connection in ${Math.round(reconnectDelayMs / 1000)} seconds`);
        setTimeout(connectMongo, reconnectDelayMs);
        reconnectDelayMs = Math.min(reconnectDelayMs * 2, 60000);
    }
};

if (!process.env.MONGO_URI) {
    console.error("❌ MongoDB Error: MONGO_URI is not configured in backend/.env");
} else {
    connectMongo();
}

// =============================================
// 🔥 FIXED: SERVER - LISTEN ON ALL INTERFACES
// =============================================
const PORT = process.env.PORT || 5000;

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Server running on port ${PORT}`);
    console.log(`📤 Bus Upload: http://localhost:${PORT}/api/bus/upload`);
    console.log(`📍 Bus Data: http://localhost:${PORT}/api/bus/data`);
    console.log(`📊 Bus Stats: http://localhost:${PORT}/api/bus/stats/BUS-001`);
    console.log(`📋 Health Check: http://localhost:${PORT}/api/bus/health`);
});