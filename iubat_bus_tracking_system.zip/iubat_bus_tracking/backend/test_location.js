require('dotenv').config();
const mongoose = require('mongoose');
const Location = require('./models/Location');
(async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    const loc = await Location.create({
      busId: 'BUS-001',
      latitude: 23.7937,
      longitude: 90.4066,
      timestamp: new Date(),
      speed: 14.5,
      accuracy: 1
    });
    console.log('Created location:', loc);
  } catch (e) {
    console.error('Error creating location:', e);
  } finally {
    await mongoose.disconnect();
  }
})();
