const test = require('node:test');
const assert = require('node:assert/strict');
const { validateAssignmentPayload } = require('../controllers/driverAssignmentController');
const { validateBusAssignment } = require('../controllers/transportController');

test('rejects duplicate active assignment for the same driver', () => {
  const result = validateAssignmentPayload(
    { driverId: 'driver-1', busId: 'bus-1', routeId: 'route-1', scheduleType: 'Morning Route', shift: 'Morning' },
    {
      driver: { _id: 'driver-1', isActive: true },
      bus: { _id: 'bus-1', status: 'active' },
      route: { _id: 'route-1', scheduleType: 'Morning Route' },
      activeAssignments: [{ driverId: 'driver-1' }],
    }
  );

  assert.equal(result.valid, false);
  assert.match(result.message, /already assigned/i);
});

test('rejects inactive bus or driver assignments', () => {
  const result = validateAssignmentPayload(
    { driverId: 'driver-2', busId: 'bus-2', routeId: 'route-2', scheduleType: 'Evening Route', shift: 'Evening' },
    {
      driver: { _id: 'driver-2', isActive: false },
      bus: { _id: 'bus-2', status: 'inactive' },
      route: { _id: 'route-2', scheduleType: 'Evening Route' },
      activeAssignments: [],
    }
  );

  assert.equal(result.valid, false);
  assert.match(result.message, /inactive/i);
});

test('rejects duplicate driver and schedule assignments for buses', () => {
  const result = validateBusAssignment(
    { driverId: 'driver-3', schedule: 'Morning', status: 'active' },
    [
      { _id: 'bus-existing', driverId: 'driver-3', schedule: 'Morning', status: 'active' },
    ],
    'bus-new'
  );

  assert.equal(result.valid, false);
  assert.match(result.message, /already assigned/i);
});
