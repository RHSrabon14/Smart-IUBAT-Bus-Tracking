# =============================================
# YOLO PASSENGER COUNTER SERVER
# For ESP32-CAM Bus Tracking System
# =============================================

import cv2
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from ultralytics import YOLO
import os
from datetime import datetime
import json

print("\n" + "="*50)
print("🚌 BUS PASSENGER COUNTER SERVER")
print("="*50)

# =============================================
# CREATE FLASK APP
# =============================================
app = Flask(__name__)
CORS(app)  # Allow ESP32 to connect

# =============================================
# LOAD YOLO MODEL
# =============================================
print("📥 Loading YOLO AI model...")

try:
    # Load model (downloads automatically first time)
    model = YOLO('yolov8n.pt')
    print("✅ YOLO model loaded successfully!")
except Exception as e:
    print(f"❌ Error loading model: {e}")
    exit()

# Person class ID in YOLO
PERSON_CLASS = 0

# Create uploads folder
if not os.path.exists('uploads'):
    os.makedirs('uploads')
    print("📁 Created 'uploads' folder")

print("="*50 + "\n")

# =============================================
# DETECTION ENDPOINT
# =============================================
@app.route('/detect', methods=['POST'])
def detect_passengers():
    try:
        print("\n" + "─"*40)
        print("📸 New image received!")
        
        # Check if image is in request
        if 'image' not in request.files:
            return jsonify({'error': 'No image provided'}), 400
        
        image_file = request.files['image']
        
        # Save image for debugging (optional)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"uploads/capture_{timestamp}.jpg"
        image_file.save(filename)
        print(f"💾 Image saved: {filename}")
        
        # Read saved image from disk (avoid reading stream after save)
        img = cv2.imread(filename)
        if img is None:
            return jsonify({'error': 'Invalid image'}), 400
        
        print("🔍 Running YOLO detection...")
        
        # Run YOLO detection
        results = model(img, conf=0.25)
        
        # Count people
        people_count = 0
        detections = []
        
        for r in results:
            boxes = r.boxes
            if boxes is not None:
                for box in boxes:
                    cls = int(box.cls[0])
                    conf = float(box.conf[0])
                    
                    if cls == PERSON_CLASS:
                        people_count += 1
                        x1, y1, x2, y2 = box.xyxy[0].tolist()
                        detections.append({
                            'confidence': round(conf, 2),
                            'bbox': [int(x1), int(y1), int(x2), int(y2)]
                        })
        
        print(f"👥 People detected: {people_count}")
        print("─"*40)
        
        # Prepare response
        response = {
            'success': True,
            'passengerCount': people_count,
            'detections': detections,
            'totalDetections': len(detections),
            'timestamp': datetime.now().isoformat(),
            'imageSaved': filename
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        print(f"❌ Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

# =============================================
# HEALTH CHECK ENDPOINT
# =============================================
@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'OK',
        'model': 'YOLOv8n',
        'timestamp': datetime.now().isoformat()
    })

# =============================================
# HOME PAGE
# =============================================
@app.route('/', methods=['GET'])
def home():
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>🚌 Bus Passenger Counter</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 50px auto;
                padding: 20px;
                background: #f0f0f0;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1 { color: #2c3e50; }
            .status {
                background: #27ae60;
                color: white;
                padding: 10px;
                border-radius: 5px;
                display: inline-block;
            }
            .endpoint {
                background: #ecf0f1;
                padding: 10px;
                margin: 10px 0;
                border-radius: 5px;
                font-family: monospace;
            }
            .method {
                color: #2980b9;
                font-weight: bold;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🚌 Bus Passenger Counter Server</h1>
            <p><span class="status">✅ SERVER RUNNING</span></p>
            
            <h2>📡 Available Endpoints:</h2>
            
            <div class="endpoint">
                <span class="method">POST</span> /detect 
                <span style="color:#7f8c8d;">- Send image for detection</span>
            </div>
            
            <div class="endpoint">
                <span class="method">GET</span> /health 
                <span style="color:#7f8c8d;">- Check server status</span>
            </div>
            
            <div class="endpoint">
                <span class="method">GET</span> / 
                <span style="color:#7f8c8d;">- This page</span>
            </div>
            
            <h2>📤 How to use:</h2>
            <p>Send POST request to <strong>/detect</strong> with:</p>
            <ul>
                <li>Multipart/form-data with field name: <strong>image</strong></li>
                <li>File should be JPEG image</li>
            </ul>
            
            <h2>📊 Example Response:</h2>
            <pre style="background:#2c3e50;color:#ecf0f1;padding:15px;border-radius:5px;">
{
  "success": true,
  "passengerCount": 5,
  "detections": [...],
  "timestamp": "2024-01-15T18:00:00.000Z"
}
            </pre>
            
            <p style="color:#7f8c8d;font-size:12px;margin-top:30px;">
                YOLOv8n Model | Port: 5001
            </p>
        </div>
    </body>
    </html>
    """

# =============================================
# START SERVER
# =============================================
if __name__ == '__main__':
    print("\n" + "="*50)
    print("✅ SERVER READY!")
    print("="*50)
    print(f"📡 Local:     http://localhost:5001")
    print(f"📡 Network:   http://0.0.0.0:5001")
    print(f"📤 Detection: http://localhost:5001/detect")
    print(f"📊 Health:    http://localhost:5001/health")
    print("="*50)
    print("🔴 Press CTRL+C to stop server\n")
    
    app.run(host='0.0.0.0', port=5001, debug=True)