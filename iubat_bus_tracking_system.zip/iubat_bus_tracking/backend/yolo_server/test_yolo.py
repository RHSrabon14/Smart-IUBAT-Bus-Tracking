# =============================================
# TEST YOLO SERVER
# Run this to test if YOLO server is working
# =============================================

import requests
import cv2
import numpy as np
import os

# Server URL
SERVER_URL = "http://localhost:5001/detect"

print("\n" + "="*50)
print("🧪 TESTING YOLO SERVER")
print("="*50)

# Create a test image (black square with white circle)
def create_test_image():
    img = np.zeros((320, 320, 3), dtype=np.uint8)
    cv2.circle(img, (160, 160), 50, (255, 255, 255), -1)
    cv2.putText(img, "TEST", (120, 180), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
    return img

# Save test image
test_img = create_test_image()
test_path = "test_image.jpg"
cv2.imwrite(test_path, test_img)
print(f"📸 Created test image: {test_path}")

# Send to server
print("📤 Sending to YOLO server...")

try:
    with open(test_path, 'rb') as f:
        files = {'image': f}
        response = requests.post(SERVER_URL, files=files)
    
    print(f"📥 Response Status: {response.status_code}")
    
    if response.status_code == 200:
        result = response.json()
        print("\n✅ Server Response:")
        print("─" * 40)
        print(f"📊 Passenger Count: {result.get('passengerCount', 0)}")
        print(f"📅 Timestamp: {result.get('timestamp', 'N/A')}")
        print(f"📁 Image Saved: {result.get('imageSaved', 'N/A')}")
        print("─" * 40)
        print("\n✅ YOLO Server is working correctly!")
    else:
        print(f"❌ Error: {response.text}")
        
except requests.exceptions.ConnectionError:
    print("❌ Cannot connect to server!")
    print("   Make sure YOLO server is running:")
    print("   python yolo_server.py")
except Exception as e:
    print(f"❌ Error: {e}")

# Clean up
if os.path.exists(test_path):
    os.remove(test_path)
    print("🗑️ Test image deleted")

print("\n" + "="*50)