const ShuttleRoute = require("../models/ShuttleRoute");
const Bus = require("../models/Bus");

// PUT /api/admin/update-route - Admin updates route info
const updateRoute = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const route = await ShuttleRoute.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true
    });

    if (!route) {
      return res.status(404).json({
        success: false,
        message: "Route not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Route updated successfully",
      data: route
    });
  } catch (error) {
    console.error("Error updating route:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

// DELETE /api/admin/delete-route - Admin deletes route
const deleteRoute = async (req, res) => {
  try {
    const { id } = req.params;

    const route = await ShuttleRoute.findByIdAndDelete(id);

    if (!route) {
      return res.status(404).json({
        success: false,
        message: "Route not found"
      });
    }

    res.status(200).json({
      success: true,
      message: "Route deleted successfully"
    });
  } catch (error) {
    console.error("Error deleting route:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

// POST /api/admin/add-route - Admin adds new route
const addRoute = async (req, res) => {
  try {
    const { busNo, busId, routeName, time, type } = req.body;

    if (!busNo || !routeName) {
      return res.status(400).json({
        success: false,
        message: "busNo and routeName are required"
      });
    }

    const route = new ShuttleRoute({
      busNo,
      busId: busId || busNo,
      routeName,
      time: time || "Not Fixed",
      type: type || "shuttle"
    });

    await route.save();

    res.status(201).json({
      success: true,
      message: "Route added successfully",
      data: route
    });
  } catch (error) {
    console.error("Error adding route:", error);
    if (error.code === 11000) {
      res.status(400).json({
        success: false,
        message: "Route with this bus number already exists"
      });
    } else {
      res.status(500).json({
        success: false,
        message: "Internal server error"
      });
    }
  }
};

// GET /api/admin/routes - Get all routes for admin
const getAllRoutes = async (req, res) => {
  try {
    const routes = await ShuttleRoute.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: routes
    });
  } catch (error) {
    console.error("Error fetching routes:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

// POST /api/admin/add-bus - Add new bus
const addBus = async (req, res) => {
  try {
    const { busId, busNumber, driverName, capacity } = req.body;

    if (!busId || !busNumber) {
      return res.status(400).json({
        success: false,
        message: "busId and busNumber are required"
      });
    }

    const bus = new Bus({
      busId,
      busNumber,
      driverName,
      capacity: capacity || 50
    });

    await bus.save();

    res.status(201).json({
      success: true,
      message: "Bus added successfully",
      data: bus
    });
  } catch (error) {
    console.error("Error adding bus:", error);
    if (error.code === 11000) {
      res.status(400).json({
        success: false,
        message: "Bus with this ID already exists"
      });
    } else {
      res.status(500).json({
        success: false,
        message: "Internal server error"
      });
    }
  }
};

// GET /api/admin/buses - Get all buses
const getAllBuses = async (req, res) => {
  try {
    const buses = await Bus.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: buses
    });
  } catch (error) {
    console.error("Error fetching buses:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

module.exports = {
  updateRoute,
  deleteRoute,
  addRoute,
  getAllRoutes,
  addBus,
  getAllBuses,
};