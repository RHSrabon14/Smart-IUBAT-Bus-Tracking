const Location = require("../models/Location");
const Bus = require("../models/Bus");
const ShuttleRoute = require("../models/ShuttleRoute");
const { calculateEta } = require("../services/etaService");
const { resolveRouteForBus } = require("../services/routeMappingService");

const getRouteInfo = async (busIdentifier, bus = null) => {
  const mappedRoute = await resolveRouteForBus(bus);
  if (mappedRoute) return mappedRoute;

  return ShuttleRoute.findOne({
    $or: [
      { busId: busIdentifier },
      { busNo: busIdentifier },
    ],
  }).select("busId busNo routeName").lean();
};

// POST /api/location/update - Receive GPS coordinates from ESP32
const updateLocation = async (req, res) => {
  try {
    const { busId, latitude, longitude, timestamp, speed, accuracy } = req.body;

    if (!busId || latitude === undefined || longitude === undefined) {
      return res.status(400).json({
        success: false,
        message: "busId, latitude, and longitude are required"
      });
    }

    const parsedLatitude = parseFloat(latitude);
    const parsedLongitude = parseFloat(longitude);

    if (Number.isNaN(parsedLatitude) || Number.isNaN(parsedLongitude)) {
      return res.status(400).json({
        success: false,
        message: "latitude and longitude must be numeric"
      });
    }

    const currentTimestamp = timestamp ? new Date(timestamp) : new Date();
    const location = new Location({
      busId,
      latitude: parsedLatitude,
      longitude: parsedLongitude,
      timestamp: currentTimestamp,
      speed: speed ? parseFloat(speed) : 0,
      accuracy: accuracy ? parseFloat(accuracy) : 0,
    });

    await location.save();

    const existingBus = await Bus.findOne({ busId }).lean();
    const eta = calculateEta({
      currentLocation: { latitude: parsedLatitude, longitude: parsedLongitude, timestamp: currentTimestamp },
      speedKmph: speed ? parseFloat(speed) : existingBus?.currentSpeed || 25,
      departureTime: existingBus?.departureTime || "07:30",
      route: {
        distanceKm: existingBus?.routeDistanceKm || 0,
        destinationLatitude: existingBus?.destinationLatitude || 0,
        destinationLongitude: existingBus?.destinationLongitude || 0,
      },
      now: currentTimestamp,
    });

    await Bus.findOneAndUpdate(
      { busId },
      {
        $set: {
          busNumber: busId,
          status: "active",
          currentLocation: {
            latitude: parsedLatitude,
            longitude: parsedLongitude,
            timestamp: currentTimestamp,
          },
          currentSpeed: speed ? parseFloat(speed) : existingBus?.currentSpeed || 0,
          eta: { ...eta, updatedAt: currentTimestamp },
          lastUpdated: currentTimestamp,
        },
      },
      {
        upsert: true,
        new: true,
        setDefaultsOnInsert: true,
      }
    );

    res.status(200).json({
      success: true,
      message: "Location updated successfully"
    });
  } catch (error) {
    console.error("Error updating location:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

// GET /api/location/:busId - Get single bus live location
const getBusLocation = async (req, res) => {
  try {
    const { busId } = req.params;
    const bus = await Bus.findOne({ busId }).select("busId busNumber status currentLocation departureTime eta routeId routeCode routeModel routeName currentSpeed currentPassengerCount satellites gpsFixed");
    const routeInfo = await getRouteInfo(busId, bus);

    if (bus && bus.currentLocation?.latitude && bus.currentLocation?.longitude) {
      return res.status(200).json({
        success: true,
        data: {
          busId: bus.busId || busId,
          busNumber: bus.busNumber || bus.busId || busId,
          routeName: routeInfo?.routeName || null,
          status: bus.status || "active",
          currentLocation: bus.currentLocation,
          currentSpeed: bus.currentSpeed || 0,
          currentPassengerCount: bus.currentPassengerCount || 0,
          satellites: bus.satellites || 0,
          gpsFixed: bus.gpsFixed || false,
          departureTime: bus.departureTime || "07:30",
          eta: bus.eta || null,
        }
      });
    }

    const fallbackLocation = await Location.findOne({ busId }).sort({ timestamp: -1 });

    if (!fallbackLocation) {
      return res.status(404).json({
        success: false,
        message: "Bus location not found"
      });
    }

    return res.status(200).json({
      success: true,
      data: {
        busId,
        busNumber: bus?.busNumber || bus?.busId || busId,
        routeName: routeInfo?.routeName || null,
        status: bus?.status || "active",
        currentLocation: {
          latitude: fallbackLocation.latitude,
          longitude: fallbackLocation.longitude,
          timestamp: fallbackLocation.timestamp,
        },
        currentSpeed: bus?.currentSpeed || 0,
        currentPassengerCount: bus?.currentPassengerCount || 0,
        satellites: bus?.satellites || 0,
        gpsFixed: bus?.gpsFixed || false,
        departureTime: bus?.departureTime || "07:30",
        eta: bus?.eta || null,
      }
    });
  } catch (error) {
    console.error("Error fetching bus location:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

const getAllBusLocations = async (req, res) => {
  try {
    const buses = await Bus.find({
      "currentLocation.latitude": { $exists: true },
      "currentLocation.longitude": { $exists: true }
    }).select("busId busNumber status currentLocation");

    const busIdentifiers = buses.map((bus) => bus.busId || bus.busNumber);
    const routes = await ShuttleRoute.find({
      $or: [
        { busId: { $in: busIdentifiers } },
        { busNo: { $in: busIdentifiers } },
      ],
    }).select("busId busNo routeName").lean();

    const routeLookup = new Map();
    routes.forEach((route) => {
      if (route.busId) routeLookup.set(route.busId, route.routeName);
      if (route.busNo) routeLookup.set(route.busNo, route.routeName);
    });

    const busesWithRoutes = await Promise.all(buses.map(async (bus) => {
      const route = await getRouteInfo(bus.busId || bus.busNumber, bus);
      return {
        ...bus.toObject(),
        routeName: route?.routeName || routeLookup.get(bus.busId) || routeLookup.get(bus.busNumber) || null,
        routeCode: bus.routeCode || route?.routeId || "",
      };
    }));

    res.status(200).json({
      success: true,
      data: busesWithRoutes
    });
  } catch (error) {
    console.error("Error fetching all bus locations:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

// GET /api/location/history/:busId - Get location history (optional)
const getLocationHistory = async (req, res) => {
  try {
    const { busId } = req.params;
    const { limit = 50 } = req.query;

    const locations = await Location.find({ busId })
      .sort({ timestamp: -1 })
      .limit(parseInt(limit, 10));

    res.status(200).json({
      success: true,
      data: locations
    });
  } catch (error) {
    console.error("Error fetching location history:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

module.exports = {
  updateLocation,
  getBusLocation,
  getAllBusLocations,
  getLocationHistory,
};