const MorningRoute = require("../models/MorningRoute");
const EveningRoute = require("../models/EveningRoute");
const ShuttleRoute = require("../models/ShuttleRoute");
const Driver = require("../models/Driver");
const Bus = require("../models/Bus");

const normalizeRoutePayload = (body) => ({
  busNo: body.busNo,
  busId: body.busId || body.busNo,
  routeName: body.routeName,
  departureLocation: body.departureLocation || body.origin || "",
  destination: body.destination || body.to || "",
  time: body.time || "Not Fixed",
  stops: Array.isArray(body.stops) ? body.stops : (body.stops ? String(body.stops).split(",").map((item) => item.trim()).filter(Boolean) : []),
  status: body.status || "Active",
  gpsEnabled: body.gpsEnabled !== undefined ? body.gpsEnabled : true,
  assignedDriver: body.assignedDriver || null,
  assignedBus: body.assignedBus || null,
});

const listMorningRoutes = async (req, res) => {
  try {
    const routes = await MorningRoute.find().sort({ createdAt: -1 }).populate("assignedDriver").populate("assignedBus");
    res.status(200).json({ success: true, data: routes.map((route) => ({ ...route.toObject(), schedule: "Morning", routeModel: "MorningRoute" })) });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load morning routes" });
  }
};

const createMorningRoute = async (req, res) => {
  try {
    const route = new MorningRoute(normalizeRoutePayload(req.body));
    await route.save();
    res.status(201).json({ success: true, message: "Morning route created", data: route });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to create morning route" });
  }
};

const updateMorningRoute = async (req, res) => {
  try {
    const route = await MorningRoute.findByIdAndUpdate(req.params.id, normalizeRoutePayload(req.body), { new: true, runValidators: true });
    if (!route) return res.status(404).json({ success: false, message: "Morning route not found" });
    res.status(200).json({ success: true, message: "Morning route updated", data: route });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to update morning route" });
  }
};

const deleteMorningRoute = async (req, res) => {
  try {
    const route = await MorningRoute.findByIdAndDelete(req.params.id);
    if (!route) return res.status(404).json({ success: false, message: "Morning route not found" });
    res.status(200).json({ success: true, message: "Morning route deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to delete morning route" });
  }
};

const listEveningRoutes = async (req, res) => {
  try {
    const routes = await EveningRoute.find().sort({ createdAt: -1 }).populate("assignedDriver").populate("assignedBus");
    res.status(200).json({ success: true, data: routes.map((route) => ({ ...route.toObject(), schedule: "Evening", routeModel: "EveningRoute" })) });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load evening routes" });
  }
};

const createEveningRoute = async (req, res) => {
  try {
    const route = new EveningRoute(normalizeRoutePayload(req.body));
    await route.save();
    res.status(201).json({ success: true, message: "Evening route created", data: route });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to create evening route" });
  }
};

const updateEveningRoute = async (req, res) => {
  try {
    const route = await EveningRoute.findByIdAndUpdate(req.params.id, normalizeRoutePayload(req.body), { new: true, runValidators: true });
    if (!route) return res.status(404).json({ success: false, message: "Evening route not found" });
    res.status(200).json({ success: true, message: "Evening route updated", data: route });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to update evening route" });
  }
};

const deleteEveningRoute = async (req, res) => {
  try {
    const route = await EveningRoute.findByIdAndDelete(req.params.id);
    if (!route) return res.status(404).json({ success: false, message: "Evening route not found" });
    res.status(200).json({ success: true, message: "Evening route deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to delete evening route" });
  }
};

const listShuttleRoutes = async (req, res) => {
  try {
    const routes = await ShuttleRoute.find().sort({ createdAt: -1 }).populate("assignedDriver").populate("assignedBus");
    res.status(200).json({ success: true, data: routes.map((route) => ({ ...route.toObject(), schedule: "Shuttle", routeModel: "ShuttleRoute" })) });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load shuttle routes" });
  }
};

const createShuttleRoute = async (req, res) => {
  try {
    const route = new ShuttleRoute({ ...normalizeRoutePayload(req.body), type: req.body.type || "shuttle" });
    await route.save();
    res.status(201).json({ success: true, message: "Shuttle route created", data: route });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to create shuttle route" });
  }
};

const updateShuttleRoute = async (req, res) => {
  try {
    const route = await ShuttleRoute.findByIdAndUpdate(req.params.id, { ...normalizeRoutePayload(req.body), type: req.body.type || "shuttle" }, { new: true, runValidators: true });
    if (!route) return res.status(404).json({ success: false, message: "Shuttle route not found" });
    res.status(200).json({ success: true, message: "Shuttle route updated", data: route });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to update shuttle route" });
  }
};

const deleteShuttleRoute = async (req, res) => {
  try {
    const route = await ShuttleRoute.findByIdAndDelete(req.params.id);
    if (!route) return res.status(404).json({ success: false, message: "Shuttle route not found" });
    res.status(200).json({ success: true, message: "Shuttle route deleted" });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to delete shuttle route" });
  }
};

const listDrivers = async (req, res) => {
  try {
    const drivers = await Driver.find().sort({ createdAt: -1 }).populate("assignedBus").populate("assignedRoute");
    res.status(200).json({ success: true, data: drivers });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load drivers" });
  }
};

const listBuses = async (req, res) => {
  try {
    const buses = await Bus.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: buses });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load buses" });
  }
};

module.exports = {
  listMorningRoutes,
  createMorningRoute,
  updateMorningRoute,
  deleteMorningRoute,
  listEveningRoutes,
  createEveningRoute,
  updateEveningRoute,
  deleteEveningRoute,
  listShuttleRoutes,
  createShuttleRoute,
  updateShuttleRoute,
  deleteShuttleRoute,
  listDrivers,
  listBuses,
};
