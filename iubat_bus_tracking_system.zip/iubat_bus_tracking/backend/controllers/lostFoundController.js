const LostItem = require("../models/LostItem");
const FoundItem = require("../models/FoundItem");

const getLostItems = async (req, res) => {
  try {
    const lostItems = await LostItem.find().sort({ createdAt: -1 }).populate("matchedFoundItem");
    res.status(200).json({ success: true, data: lostItems });
  } catch (error) {
    console.error("Error fetching lost items:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const createLostItem = async (req, res) => {
  try {
    const {
      itemName,
      category,
      description,
      busNumber,
      route,
      dateLost,
      studentId,
      phone,
    } = req.body;

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : "";

    const lostItem = new LostItem({
      itemName,
      category,
      description,
      busNumber,
      route,
      dateLost,
      studentId,
      phone,
      imageUrl,
    });

    await lostItem.save();
    res.status(201).json({ success: true, data: lostItem });
  } catch (error) {
    console.error("Error creating lost item:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const updateLostItem = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    if (req.file) {
      updates.imageUrl = `/uploads/${req.file.filename}`;
    }

    const lostItem = await LostItem.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    }).populate("matchedFoundItem");

    if (!lostItem) {
      return res.status(404).json({ success: false, message: "Lost item not found" });
    }

    res.status(200).json({ success: true, data: lostItem });
  } catch (error) {
    console.error("Error updating lost item:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const getFoundItems = async (req, res) => {
  try {
    const foundItems = await FoundItem.find().sort({ createdAt: -1 }).populate("matchedLostItem");
    res.status(200).json({ success: true, data: foundItems });
  } catch (error) {
    console.error("Error fetching found items:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const createFoundItem = async (req, res) => {
  try {
    const {
      itemName,
      category,
      description,
      busNumber,
      route,
      dateFound,
      phone,
      reportedBy,
    } = req.body;

    const imageUrl = req.file ? `/uploads/${req.file.filename}` : "";

    const foundItem = new FoundItem({
      itemName,
      category,
      description,
      busNumber,
      route,
      dateFound,
      phone,
      reportedBy: reportedBy || "Admin",
      imageUrl,
    });

    await foundItem.save();
    res.status(201).json({ success: true, data: foundItem });
  } catch (error) {
    console.error("Error creating found item:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const updateFoundItem = async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    if (req.file) {
      updates.imageUrl = `/uploads/${req.file.filename}`;
    }

    const foundItem = await FoundItem.findByIdAndUpdate(id, updates, {
      new: true,
      runValidators: true,
    }).populate("matchedLostItem");

    if (!foundItem) {
      return res.status(404).json({ success: false, message: "Found item not found" });
    }

    if (updates.matchedLostItem) {
      const matchedLostItem = await LostItem.findByIdAndUpdate(
        updates.matchedLostItem,
        { status: "Found", matchedFoundItem: foundItem._id },
        { new: true }
      );
      if (matchedLostItem) {
        foundItem.matchedLostItem = matchedLostItem._id;
        await foundItem.save();
      }
    }

    res.status(200).json({ success: true, data: foundItem });
  } catch (error) {
    console.error("Error updating found item:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const matchItem = async (req, res) => {
  try {
    const { lostId, foundId } = req.body;

    const lostItem = await LostItem.findById(lostId);
    const foundItem = await FoundItem.findById(foundId);

    if (!lostItem || !foundItem) {
      return res.status(404).json({ success: false, message: "Lost or found item not found" });
    }

    lostItem.status = "Found";
    lostItem.matchedFoundItem = foundItem._id;
    await lostItem.save();

    foundItem.status = "Ready for Collection";
    foundItem.matchedLostItem = lostItem._id;
    await foundItem.save();

    res.status(200).json({ success: true, data: { lostItem, foundItem } });
  } catch (error) {
    console.error("Error matching items:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const deleteLostItem = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await LostItem.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: "Lost item not found" });
    }
    res.status(200).json({ success: true, message: "Lost report deleted" });
  } catch (error) {
    console.error("Error deleting lost item:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const deleteFoundItem = async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await FoundItem.findByIdAndDelete(id);
    if (!deleted) {
      return res.status(404).json({ success: false, message: "Found item not found" });
    }
    res.status(200).json({ success: true, message: "Found item deleted" });
  } catch (error) {
    console.error("Error deleting found item:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const markReadyForCollection = async (req, res) => {
  try {
    const { id } = req.params;
    const lostItem = await LostItem.findById(id);
    const foundItem = await FoundItem.findById(lostItem?.matchedFoundItem);

    if (!lostItem || !foundItem) {
      return res.status(404).json({ success: false, message: "Item pair not found" });
    }

    lostItem.status = "Ready for Collection";
    foundItem.status = "Ready for Collection";
    await lostItem.save();
    await foundItem.save();

    res.status(200).json({ success: true, data: { lostItem, foundItem } });
  } catch (error) {
    console.error("Error marking ready for collection:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

const markReturned = async (req, res) => {
  try {
    const { id } = req.params;
    const lostItem = await LostItem.findById(id);
    const foundItem = await FoundItem.findById(lostItem?.matchedFoundItem);

    if (!lostItem || !foundItem) {
      return res.status(404).json({ success: false, message: "Item pair not found" });
    }

    lostItem.status = "Returned";
    foundItem.status = "Returned";
    await lostItem.save();
    await foundItem.save();

    res.status(200).json({ success: true, data: { lostItem, foundItem } });
  } catch (error) {
    console.error("Error marking returned:", error);
    res.status(500).json({ success: false, message: "Internal server error" });
  }
};

module.exports = {
  getLostItems,
  createLostItem,
  updateLostItem,
  deleteLostItem,
  getFoundItems,
  createFoundItem,
  updateFoundItem,
  deleteFoundItem,
  matchItem,
  markReadyForCollection,
  markReturned,
};
