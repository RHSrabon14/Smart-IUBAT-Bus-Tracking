const DriverPerformance = require("../models/DriverPerformance");
const Driver = require("../models/Driver");

const createPerformance = async (req, res) => {
  try {
    const { driverId, driverName, safety, behaviour, cleanliness, punctuality, overallRating, comment } = req.body;
    if (!driverId) return res.status(400).json({ success: false, message: "driverId is required" });

    const driver = await Driver.findById(driverId);
    const performance = new DriverPerformance({
      driverId,
      driverName: driverName || driver?.name || "",
      safety: Number(safety) || 0,
      behaviour: Number(behaviour) || 0,
      cleanliness: Number(cleanliness) || 0,
      punctuality: Number(punctuality) || 0,
      overallRating: Number(overallRating) || 0,
      comment: comment || "",
    });

    await performance.save();
    res.status(201).json({ success: true, message: "Performance rating saved", data: performance });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to save performance" });
  }
};

const listPerformance = async (req, res) => {
  try {
    const performances = await DriverPerformance.find().sort({ createdAt: -1 }).populate("driverId");
    res.status(200).json({ success: true, data: performances });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load performance" });
  }
};

const getPerformanceSummary = async (req, res) => {
  try {
    const performances = await DriverPerformance.find();
    const today = new Date();
    const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const weekStart = new Date(today); weekStart.setDate(today.getDate() - 6);
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

    const todayRatings = performances.filter((item) => item.createdAt >= startOfToday);
    const weekRatings = performances.filter((item) => item.createdAt >= weekStart);
    const monthRatings = performances.filter((item) => item.createdAt >= monthStart);

    const averageRating = performances.length ? (performances.reduce((sum, item) => sum + (item.overallRating || 0), 0) / performances.length).toFixed(1) : null;
    const todayAverage = todayRatings.length ? (todayRatings.reduce((sum, item) => sum + (item.overallRating || 0), 0) / todayRatings.length).toFixed(1) : null;
    const weeklyAverage = weekRatings.length ? (weekRatings.reduce((sum, item) => sum + (item.overallRating || 0), 0) / weekRatings.length).toFixed(1) : null;
    const monthlyAverage = monthRatings.length ? (monthRatings.reduce((sum, item) => sum + (item.overallRating || 0), 0) / monthRatings.length).toFixed(1) : null;

    const sorted = [...performances].sort((a, b) => (b.overallRating || 0) - (a.overallRating || 0));
    const topDriver = sorted[0];
    const lowestDriver = [...performances].sort((a, b) => (a.overallRating || 0) - (b.overallRating || 0))[0];

    res.status(200).json({
      success: true,
      data: {
        averageRating,
        todayRating: todayAverage,
        weeklyRating: weeklyAverage,
        monthlyRating: monthlyAverage,
        topDriver: topDriver ? { _id: topDriver.driverId, name: topDriver.driverName, rating: topDriver.overallRating } : null,
        lowestRatedDriver: lowestDriver ? { _id: lowestDriver.driverId, name: lowestDriver.driverName, rating: lowestDriver.overallRating } : null,
      },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to summarize performance" });
  }
};

module.exports = { createPerformance, listPerformance, getPerformanceSummary };
