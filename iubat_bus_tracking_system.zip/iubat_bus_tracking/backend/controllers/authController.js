const bcrypt = require("bcryptjs");
const Admin = require("../models/Admin");
const Student = require("../models/Student");
const Faculty = require("../models/Faculty");
const { sendResetOtp } = require("../services/emailService");

const availableRoles = {
  admin: Admin,
  student: Student,
  faculty: Faculty,
};

const generateOtp = () => Math.floor(100000 + Math.random() * 900000).toString();

const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");

const normalizeIdentifier = (role, identifier) => {
  const value = String(identifier || "").trim();
  if (!value) return "";

  if (role === "student") {
    return value;
  }

  return value.toLowerCase();
};

const buildUserQuery = (role, identifier) => {
  const normalizedIdentifier = normalizeIdentifier(role, identifier);

  if (role === "student") {
    return {
      $or: [
        { studentId: normalizedIdentifier },
        { email: { $regex: `^${escapeRegex(normalizedIdentifier)}$`, $options: "i" } },
      ],
    };
  }

  return {
    email: { $regex: `^${escapeRegex(normalizedIdentifier)}$`, $options: "i" },
  };
};

const findUser = async (role, identifier) => {
  const Model = availableRoles[role];
  if (!Model) return null;

  const query = buildUserQuery(role, identifier);
  console.log(`[auth] selected role: ${role}`);
  console.log(`[auth] email received: ${identifier}`);
  console.log(`[auth] mongo query: ${JSON.stringify(query)}`);
  console.log(`[auth] target collection: ${Model.collection.name}`);

  const user = await Model.findOne(query);
  console.log(`[auth] query result: ${user ? JSON.stringify({ id: user._id, email: user.email, studentId: user.studentId }) : "null"}`);
  return user;
};

const forgotPassword = async (req, res) => {
  try {
    const { role, identifier } = req.body;

    if (!role || !identifier) {
      return res.status(400).json({ msg: "Role and identifier are required." });
    }

    const normalizedRole = role.toLowerCase();
    const user = await findUser(normalizedRole, identifier);

    if (!user) {
      return res.status(404).json({ msg: "No account found for the provided information." });
    }

    const now = Date.now();
    const lastRequest = user.lastOtpRequest ? new Date(user.lastOtpRequest).getTime() : 0;
    const timeSinceLastRequest = now - lastRequest;

    if (user.otpAttempts >= 3 && timeSinceLastRequest < 15 * 60 * 1000) {
      return res.status(429).json({ msg: "Too many OTP requests. Please try again later." });
    }

    const otp = generateOtp();
    const otpHash = await bcrypt.hash(otp, 10);

    user.otp = otpHash;
    user.otpExpiry = new Date(now + 5 * 60 * 1000);
    user.otpAttempts = user.otpAttempts ? user.otpAttempts + 1 : 1;
    user.lastOtpRequest = new Date(now);
    await user.save();

    const emailResult = await sendResetOtp({ to: user.email, otp, role: normalizedRole });

    res.status(200).json({ msg: "OTP sent to your email account.", expiresIn: 5 * 60, emailSent: emailResult?.sent || true });
  } catch (error) {
    console.error("Forgot password error:", error);
    res.status(500).json({ msg: error.message || "Internal server error" });
  }
};

const verifyOtp = async (req, res) => {
  try {
    const { role, identifier, otp } = req.body;

    if (!role || !identifier || !otp) {
      return res.status(400).json({ msg: "Role, identifier, and OTP are required." });
    }

    const normalizedRole = role.toLowerCase();
    const user = await findUser(normalizedRole, identifier);

    if (!user || !user.otp || !user.otpExpiry) {
      return res.status(400).json({ msg: "No active OTP found. Please request a new one." });
    }

    if (new Date(user.otpExpiry).getTime() < Date.now()) {
      user.otp = undefined;
      user.otpExpiry = undefined;
      await user.save();
      return res.status(400).json({ msg: "OTP has expired. Please request a new one." });
    }

    const otpMatch = await bcrypt.compare(otp.trim(), user.otp);
    if (!otpMatch) {
      return res.status(400).json({ msg: "Invalid OTP provided." });
    }

    user.otp = undefined;
    user.otpExpiry = undefined;
    await user.save();

    res.status(200).json({ msg: "OTP verified successfully." });
  } catch (error) {
    console.error("Verify OTP error:", error);
    res.status(500).json({ msg: error.message || "Internal server error" });
  }
};

const resetPassword = async (req, res) => {
  try {
    const { role, identifier, password } = req.body;

    if (!role || !identifier || !password) {
      return res.status(400).json({ msg: "Role, identifier, and new password are required." });
    }

    if (password.length < 8) {
      return res.status(400).json({ msg: "Password must be at least 8 characters long." });
    }

    const normalizedRole = role.toLowerCase();
    const user = await findUser(normalizedRole, identifier);

    if (!user) {
      return res.status(404).json({ msg: "No account found for the provided information." });
    }

    user.password = await bcrypt.hash(password, 10);
    user.otp = undefined;
    user.otpExpiry = undefined;
    user.otpAttempts = 0;
    user.lastOtpRequest = undefined;
    await user.save();

    res.status(200).json({ msg: "Password has been reset successfully." });
  } catch (error) {
    console.error("Reset password error:", error);
    res.status(500).json({ msg: error.message || "Internal server error" });
  }
};

module.exports = {
  forgotPassword,
  verifyOtp,
  resetPassword,
};
