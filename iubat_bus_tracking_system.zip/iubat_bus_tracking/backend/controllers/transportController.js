const mongoose = require("mongoose");
const Bus = require("../models/Bus");
const Driver = require("../models/Driver");
const ShuttleRoute = require("../models/ShuttleRoute");
const PassengerCount = require("../models/PassengerCount");
const Location = require("../models/Location");
const Alert = require("../models/Alert");
const Notification = require("../models/Notification");
const Maintenance = require("../models/Maintenance");
const Student = require("../models/Student");
const DriverAssignment = require("../models/DriverAssignment");
const MorningRoute = require("../models/MorningRoute");
const EveningRoute = require("../models/EveningRoute");
const { calculateEta } = require("../services/etaService");
const { resolveRouteForBus } = require("../services/routeMappingService");

const routeModels = {
  MorningRoute,
  EveningRoute,
  ShuttleRoute,
};

const scheduleToRouteModel = {
  Morning: "MorningRoute",
  Evening: "EveningRoute",
  Shuttle: "ShuttleRoute",
};

const getRouteForBus = async (bus) => {
  const mappedRoute = await resolveRouteForBus(bus);
  if (mappedRoute) return mappedRoute;

  if (!bus?.routeId || !bus.routeModel || !routeModels[bus.routeModel]) {
    return null;
  }
  return routeModels[bus.routeModel].findById(bus.routeId).lean();
};

const serializeBus = async (bus) => {
  const plainBus = bus.toObject ? bus.toObject() : bus;
  const route = await getRouteForBus(plainBus);
  return {
    ...plainBus,
    routeName: plainBus.routeName || route?.routeName || "",
    routeCode: plainBus.routeCode || route?.routeId || "",
    routeModel: plainBus.routeModel || "",
    route: route || null,
  };
};

const validateBusAssignment = (payload, buses = [], currentBusId = null) => {
  if (!payload.driverId || !payload.schedule) {
    return { valid: true };
  }

  const duplicate = buses.some((bus) => {
    if (!bus || !bus.driverId || !bus.schedule) {
      return false;
    }

    const sameDriver = bus.driverId.toString() === payload.driverId.toString();
    const sameSchedule = bus.schedule === payload.schedule;
    const sameBus = currentBusId && bus._id && bus._id.toString() === currentBusId.toString();
    return sameDriver && sameSchedule && !sameBus;
  });

  if (duplicate) {
    return { valid: false, message: "This driver is already assigned to another bus for the selected schedule." };
  }

  return { valid: true };
};

const getDashboardSummary = async (req, res) => {
  try {
    const [buses, drivers, morningRoutes, eveningRoutes, shuttleRoutes, passengers, alerts, lostItems, foundItems, notifications, maintenances, students, assignments, performances] = await Promise.all([
      Bus.find().populate("driverId", "name driverId status availability"),
      Driver.find(),
      MorningRoute.find(),
      EveningRoute.find(),
      ShuttleRoute.find(),
      PassengerCount.find().sort({ timestamp: -1 }).limit(20),
      Alert.find({ isActive: true }).sort({ createdAt: -1 }).limit(10),
      require("../models/LostItem").find(),
      require("../models/FoundItem").find(),
      Notification.find({ isRead: false }).sort({ createdAt: -1 }).limit(10),
      Maintenance.find(),
      Student.find(),
      DriverAssignment.find({ status: "Active" }),
      require("../models/DriverPerformance").find().sort({ createdAt: -1 }),
    ]);

    const activeBuses = buses.filter((bus) => bus.status === "active").length;
    const offlineBuses = buses.filter((bus) => bus.gpsStatus !== "Online").length;
    const driversOnDuty = drivers.filter((driver) => driver.status === "On Duty").length;
    const driversAvailable = drivers.filter((driver) => driver.status === "Available").length;
    const driversOnLeave = drivers.filter((driver) => driver.status === "On Leave").length;

    const latestPassenger = passengers[0];
    const totalPassengersToday = buses.reduce((sum, bus) => sum + (bus.currentPassengerCount || 0), 0);
    const totalCapacity = buses.reduce((sum, bus) => sum + (bus.capacity || 0), 0);
    const occupancyAverage = totalCapacity ? Math.round((totalPassengersToday / totalCapacity) * 100) : 0;
    const routeUsage = [...morningRoutes, ...eveningRoutes, ...shuttleRoutes].map((route) => ({
      routeName: route.routeName,
      busCount: buses.filter((bus) => bus.routeName === route.routeName).length,
    }));
    const mostCrowdedRoute = routeUsage.sort((a, b) => b.busCount - a.busCount)[0] || null;
    const leastUsedRoute = routeUsage.sort((a, b) => a.busCount - b.busCount)[0] || null;

    const activitySources = [
      ...buses.map((item) => ({ type: "Bus Added", detail: `${item.busId} ${item.schedule}`, createdAt: item.createdAt })),
      ...drivers.map((item) => ({ type: "Driver Updated", detail: item.name, createdAt: item.updatedAt || item.createdAt })),
      ...assignments.map((item) => ({ type: "Driver Assigned", detail: "Driver assignment saved", createdAt: item.createdAt })),
      ...alerts.map((item) => ({ type: "Alert Created", detail: item.title, createdAt: item.createdAt })),
      ...maintenances.map((item) => ({ type: "Maintenance Added", detail: item.busId, createdAt: item.createdAt })),
      ...lostItems.map((item) => ({ type: "Lost Report", detail: item.itemName, createdAt: item.createdAt })),
      ...foundItems.map((item) => ({ type: "Found Item", detail: item.itemName, createdAt: item.createdAt })),
    ].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0)).slice(0, 10);

    const averageRating = performances.length
      ? (performances.reduce((sum, item) => sum + (item.overallRating || 0), 0) / performances.length).toFixed(1)
      : null;
    const sortedPerformances = [...performances].sort((a, b) => (b.overallRating || 0) - (a.overallRating || 0));
    const lowestPerformances = [...performances].sort((a, b) => (a.overallRating || 0) - (b.overallRating || 0));
    const ratingDriver = (item) => item ? { _id: item.driverId, name: item.driverName || "N/A", rating: item.overallRating } : null;

    res.status(200).json({
      success: true,
      data: {
        summary: {
          totalRegisteredBuses: buses.length,
          activeBuses,
          offlineBuses,
          totalRegisteredStudents: students.length,
          totalDrivers: drivers.length,
          currentActiveRoutes: morningRoutes.length + eveningRoutes.length + shuttleRoutes.length,
          morningRoutes: buses.filter((bus) => bus.schedule === "Morning").length,
          eveningRoutes: buses.filter((bus) => bus.schedule === "Evening").length,
          shuttleRoutes: buses.filter((bus) => bus.schedule === "Shuttle").length,
          assignedDrivers: assignments.length,
          availableDrivers: drivers.filter((driver) => driver.availability === "Available" || driver.status === "Available").length,
          unassignedDrivers: Math.max(0, drivers.length - assignments.length),
          onlineBuses: buses.filter((bus) => bus.gpsStatus === "Online").length,
          offlineBuses: buses.filter((bus) => bus.gpsStatus === "Offline").length,
          totalPassengersToday,
          currentLivePassengerCount: totalPassengersToday,
          mostCrowdedRoute,
          leastUsedRoute,
          averageBusOccupancy: occupancyAverage,
          lostItemReports: lostItems.length,
          foundItems: foundItems.length,
          matchedItems: foundItems.filter((item) => item.matchedLostItem).length,
          maintenanceRecords: maintenances.length,
          pendingAlerts: alerts.filter((alert) => alert.isActive).length,
          gpsDevicesOnline: buses.filter((bus) => bus.gpsStatus === "Online").length,
          esp32DevicesOnline: buses.filter((bus) => bus.cameraStatus === "Online").length,
        },
        drivers: {
          totalDrivers: drivers.length,
          onDuty: driversOnDuty,
          available: driversAvailable,
          onLeave: driversOnLeave,
        },
        recentActivities: activitySources,
        performance: {
          averageRating,
          topDriver: ratingDriver(sortedPerformances[0]),
          lowestRatedDriver: ratingDriver(lowestPerformances[0]),
        },
        alerts,
        notifications,
        maintenances,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to load dashboard data" });
  }
};

const addBus = async (req, res) => {
  try {
    const payload = { ...req.body };
    const allowedSchedules = ["Shuttle", "Morning", "Evening"];
    if (!payload.busId || !payload.busNumber) {
      return res.status(400).json({ success: false, message: "busId and busNumber are required" });
    }
    if (payload.schedule && !allowedSchedules.includes(payload.schedule)) {
      return res.status(400).json({ success: false, message: "schedule must be Shuttle, Morning, or Evening" });
    }
    const routeModel = payload.routeModel || "";
    const routeName = String(payload.routeName || "").trim();
    if (!routeName) {
      return res.status(400).json({ success: false, message: "A route name is required." });
    }

    payload.busId = String(payload.busId).trim();
    payload.busNumber = String(payload.busNumber).trim();

    const existingBus = await Bus.findOne({ busId: payload.busId }).select("busId").lean();
    if (existingBus) {
      return res.status(409).json({ success: false, message: `A bus with busId ${payload.busId} already exists.` });
    }

    const route = payload.routeId && routeModels[routeModel]
      ? await routeModels[routeModel].findById(payload.routeId).lean()
      : null;

    const normalizedPayload = {
      ...payload,
      driverId: payload.driverId || null,
      routeId: payload.routeId || null,
      routeName: route?.routeName || routeName,
      routeModel,
      schedule: payload.schedule || "Morning",
      departureTime: payload.departureTime || "07:30",
      routeDistanceKm: Number(payload.routeDistanceKm || 0),
      destinationLatitude: Number(payload.destinationLatitude || 0),
      destinationLongitude: Number(payload.destinationLongitude || 0),
      status: payload.status || "active",
      capacity: Number(payload.capacity || 50),
      currentPassengerCount: Number(payload.currentPassengerCount || 0),
    };

    const existingBuses = await Bus.find({ driverId: normalizedPayload.driverId, schedule: normalizedPayload.schedule });
    const duplicateCheck = validateBusAssignment(normalizedPayload, existingBuses);
    if (!duplicateCheck.valid) {
      return res.status(400).json({ success: false, message: duplicateCheck.message });
    }

    if (normalizedPayload.driverId) {
      const driver = await Driver.findById(normalizedPayload.driverId);
      if (!driver || !driver.isActive) {
        return res.status(400).json({ success: false, message: "Only active drivers can be assigned to a bus." });
      }
      normalizedPayload.driverName = driver.name;
    }

    const bus = new Bus(normalizedPayload);
    await bus.save();

    if (normalizedPayload.driverId) {
      await Driver.findByIdAndUpdate(normalizedPayload.driverId, {
        $set: {
          assignedBus: bus._id,
          assignedRoute: normalizedPayload.routeId || null,
          shift: normalizedPayload.schedule === "Shuttle" ? "All Day" : normalizedPayload.schedule,
          availability: "Busy",
          status: "On Duty",
          isActive: true,
        },
      });
    }

    const populatedBus = await Bus.findById(bus._id).populate("driverId", "name driverId status availability");
    res.status(201).json({ success: true, message: "Bus added successfully", data: populatedBus });
  } catch (error) {
    console.error("[POST /api/admin/buses] error", {
      name: error.name,
      code: error.code,
      message: error.message,
      stack: error.stack,
    });
    if (error.name === "ValidationError") {
      return res.status(400).json({ success: false, message: error.message });
    }
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "A bus with this busId already exists." });
    }
    res.status(500).json({
      success: false,
      message: error.message || "Unable to add bus",
      error: error.name || "InternalServerError",
      code: error.code || null,
    });
  }
};

const updateBus = async (req, res) => {
  try {
    const existingBus = await Bus.findById(req.params.id);
    if (!existingBus) {
      return res.status(404).json({ success: false, message: "Bus not found" });
    }

    const payload = { ...req.body };
    if (payload.schedule && !["Shuttle", "Morning", "Evening"].includes(payload.schedule)) {
      return res.status(400).json({ success: false, message: "schedule must be Shuttle, Morning, or Evening" });
    }
    const normalizedPayload = {
      ...payload,
      driverId: payload.driverId !== undefined ? (payload.driverId || null) : existingBus.driverId,
      routeId: payload.routeId !== undefined ? (payload.routeId || null) : existingBus.routeId,
      routeName: payload.routeName !== undefined ? payload.routeName : existingBus.routeName,
      routeModel: payload.routeModel !== undefined ? payload.routeModel : existingBus.routeModel,
      schedule: payload.schedule || existingBus.schedule || "Morning",
      departureTime: payload.departureTime || existingBus.departureTime || "07:30",
      routeDistanceKm: Number(payload.routeDistanceKm || existingBus.routeDistanceKm || 0),
      destinationLatitude: Number(payload.destinationLatitude || existingBus.destinationLatitude || 0),
      destinationLongitude: Number(payload.destinationLongitude || existingBus.destinationLongitude || 0),
      status: payload.status || existingBus.status || "active",
      capacity: Number(payload.capacity || existingBus.capacity || 50),
      currentPassengerCount: Number(payload.currentPassengerCount || existingBus.currentPassengerCount || 0),
    };

    const existingBuses = await Bus.find({ driverId: normalizedPayload.driverId, schedule: normalizedPayload.schedule, _id: { $ne: req.params.id } });
    const duplicateCheck = validateBusAssignment(normalizedPayload, existingBuses, req.params.id);
    if (!duplicateCheck.valid) {
      return res.status(400).json({ success: false, message: duplicateCheck.message });
    }

    if (normalizedPayload.driverId) {
      const driver = await Driver.findById(normalizedPayload.driverId);
      if (!driver || !driver.isActive) {
        return res.status(400).json({ success: false, message: "Only active drivers can be assigned to a bus." });
      }
      normalizedPayload.driverName = driver.name;
    } else {
      normalizedPayload.driverName = "";
    }

    if (normalizedPayload.routeId && normalizedPayload.routeModel && routeModels[normalizedPayload.routeModel]) {
      const route = await routeModels[normalizedPayload.routeModel].findById(normalizedPayload.routeId).lean();
      if (!route) return res.status(404).json({ success: false, message: "Selected route not found" });
      normalizedPayload.routeName = route.routeName;
    }

    const bus = await Bus.findByIdAndUpdate(req.params.id, normalizedPayload, { new: true, runValidators: true });
    if (!bus) {
      return res.status(404).json({ success: false, message: "Bus not found" });
    }

    if (normalizedPayload.driverId) {
      await Driver.findByIdAndUpdate(normalizedPayload.driverId, {
        $set: {
          assignedBus: bus._id,
          assignedRoute: normalizedPayload.routeId || null,
          shift: normalizedPayload.schedule === "Shuttle" ? "All Day" : normalizedPayload.schedule,
          availability: "Busy",
          status: "On Duty",
          isActive: true,
        },
      });
    }

    const populatedBus = await Bus.findById(bus._id).populate("driverId", "name driverId status availability");
    res.status(200).json({ success: true, message: "Bus updated successfully", data: populatedBus });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to update bus" });
  }
};

const deleteBus = async (req, res) => {
  try {
    const bus = await Bus.findByIdAndDelete(req.params.id);
    if (!bus) {
      return res.status(404).json({ success: false, message: "Bus not found" });
    }
    res.status(200).json({ success: true, message: "Bus deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to delete bus" });
  }
};

const listBuses = async (req, res) => {
  try {
    const buses = await Bus.find().sort({ createdAt: -1 }).populate("driverId", "name driverId status availability");
    res.status(200).json({ success: true, data: await Promise.all(buses.map(serializeBus)) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to fetch buses" });
  }
};

const listBusesBySchedule = async (req, res) => {
  try {
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({
        success: false,
        message: "Bus schedule is temporarily unavailable because the database is disconnected.",
      });
    }

    const allowedSchedules = ["Shuttle", "Morning", "Evening"];
    const { schedule } = req.query;
    if (schedule && !allowedSchedules.includes(schedule)) {
      return res.status(400).json({ success: false, message: "Unsupported schedule. Use Shuttle, Morning, or Evening." });
    }

    const query = schedule ? { schedule } : { schedule: { $in: allowedSchedules } };
    const buses = await Bus.find(query)
      .sort({ busNumber: 1 })
      .populate("driverId", "name driverId status availability");

    res.status(200).json({ success: true, data: await Promise.all(buses.map(serializeBus)) });
  } catch (error) {
    if (mongoose.connection.readyState !== 1) {
      return res.status(503).json({
        success: false,
        message: "Bus schedule is temporarily unavailable because the database is disconnected.",
      });
    }
    console.error("Unable to load buses by schedule:", error);
    res.status(500).json({ success: false, message: error.message || "Unable to load buses by schedule" });
  }
};

const addDriver = async (req, res) => {
  try {
    const payload = {
      ...req.body,
      photo: req.body.photo || "",
      nationalId: req.body.nationalId || "",
      experience: Number(req.body.experience || 0),
      shift: req.body.shift || "Morning",
      availability: req.body.availability || "Available",
    };
    const driver = new Driver(payload);
    await driver.save();
    res.status(201).json({ success: true, message: "Driver added successfully", data: driver });
  } catch (error) {
    console.error("[POST /api/admin/drivers] error", error);
    if (error.name === "ValidationError") {
      return res.status(400).json({ success: false, message: error.message });
    }
    if (error.code === 11000) {
      return res.status(409).json({ success: false, message: "A driver with this driver ID already exists." });
    }
    res.status(500).json({ success: false, message: error.message || "Unable to add driver", error: error.name });
  }
};

const listDrivers = async (req, res) => {
  try {
    const drivers = await Driver.find().sort({ createdAt: -1 }).populate("assignedBus").populate("assignedRoute");
    res.status(200).json({ success: true, data: drivers });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to fetch drivers" });
  }
};

const updateDriver = async (req, res) => {
  try {
    const payload = {
      ...req.body,
      photo: req.body.photo || "",
      nationalId: req.body.nationalId || "",
      experience: Number(req.body.experience || 0),
      shift: req.body.shift || "Morning",
      availability: req.body.availability || "Available",
    };
    const driver = await Driver.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true });
    if (!driver) {
      return res.status(404).json({ success: false, message: "Driver not found" });
    }
    res.status(200).json({ success: true, message: "Driver updated successfully", data: driver });
  } catch (error) {
    console.error("[PUT /api/admin/drivers/:id] error", error);
    if (error.name === "ValidationError") return res.status(400).json({ success: false, message: error.message });
    res.status(500).json({ success: false, message: error.message || "Unable to update driver", error: error.name });
  }
};

const deleteDriver = async (req, res) => {
  try {
    const driver = await Driver.findByIdAndDelete(req.params.id);
    if (!driver) {
      return res.status(404).json({ success: false, message: "Driver not found" });
    }
    res.status(200).json({ success: true, message: "Driver deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to delete driver" });
  }
};

const assignDriver = async (req, res) => {
  try {
    const { driverId, busId, routeId, shift, availability, status } = req.body;

    if (!driverId || !busId) {
      return res.status(400).json({ success: false, message: "Driver and bus are required." });
    }

    const [driver, bus] = await Promise.all([
      Driver.findById(driverId),
      Bus.findById(busId),
    ]);

    if (!driver || !bus) {
      return res.status(404).json({ success: false, message: "Driver or bus not found" });
    }

    let route = null;
    if (routeId) {
      route = await ShuttleRoute.findById(routeId);
      if (!route) {
        return res.status(404).json({ success: false, message: "Selected route not found" });
      }
    }

    driver.assignedBus = bus._id;
    driver.assignedRoute = route ? route._id : null;
    driver.shift = shift || driver.shift || "Morning";
    driver.availability = availability || driver.availability || "Available";
    driver.status = status || "On Duty";
    bus.driverName = driver.name;
    bus.driverId = driver._id;
    bus.routeId = route ? route._id : null;
    bus.schedule = shift === "Evening" ? "Evening" : shift === "All Day" ? "Shuttle" : bus.schedule || "Morning";
    await driver.save();
    await bus.save();

    res.status(200).json({ success: true, message: "Driver assigned successfully", data: driver });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to assign driver" });
  }
};

const addRoute = async (req, res) => {
  try {
    const route = new ShuttleRoute(req.body);
    await route.save();
    res.status(201).json({ success: true, message: "Route added successfully", data: route });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to add route" });
  }
};

const listRoutes = async (req, res) => {
  try {
    const routes = await ShuttleRoute.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: routes });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to fetch routes" });
  }
};

const updateRoute = async (req, res) => {
  try {
    const route = await ShuttleRoute.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!route) {
      return res.status(404).json({ success: false, message: "Route not found" });
    }
    res.status(200).json({ success: true, message: "Route updated successfully", data: route });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to update route" });
  }
};

const deleteRoute = async (req, res) => {
  try {
    const route = await ShuttleRoute.findByIdAndDelete(req.params.id);
    if (!route) {
      return res.status(404).json({ success: false, message: "Route not found" });
    }
    res.status(200).json({ success: true, message: "Route deleted successfully" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to delete route" });
  }
};

const uploadPassengerCount = async (req, res) => {
  try {
    const { busId, passengerCount, timestamp, latitude, longitude, capacity } = req.body;
    if (!busId || passengerCount === undefined) {
      return res.status(400).json({ success: false, message: "busId and passengerCount are required" });
    }

    const occupancyStatus = passengerCount >= (capacity || 50) ? "Full" : passengerCount >= (capacity || 50) * 0.7 ? "High" : passengerCount >= (capacity || 50) * 0.4 ? "Medium" : "Low";

    const record = new PassengerCount({
      busId,
      passengerCount,
      timestamp: timestamp || new Date(),
      capacity: capacity || 50,
      occupancyStatus,
    });

    await record.save();

    await Bus.findOneAndUpdate({ busId }, {
      $set: {
        currentPassengerCount: passengerCount,
        occupancyStatus,
        lastUpdated: new Date(),
        currentLocation: latitude && longitude ? { latitude, longitude, timestamp: timestamp || new Date() } : undefined,
      },
    }, { upsert: true, new: true });

    if (latitude && longitude) {
      await new Location({ busId, latitude, longitude, timestamp: timestamp || new Date(), speed: req.body.speed || 0 }).save();
    }

    res.status(201).json({ success: true, message: "Passenger data received", data: record });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to process passenger data" });
  }
};

const listPassengers = async (req, res) => {
  try {
    const passengers = await PassengerCount.find().sort({ timestamp: -1 }).limit(50);
    res.status(200).json({ success: true, data: passengers });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to load passenger data" });
  }
};

const uploadGPS = async (req, res) => {
  try {
    const { busId, latitude, longitude, speed, timestamp, routeDistanceKm, destinationLatitude, destinationLongitude } = req.body;
    if (!busId || latitude === undefined || longitude === undefined) {
      return res.status(400).json({ success: false, message: "busId, latitude, and longitude are required" });
    }

    const parsedLatitude = Number(latitude);
    const parsedLongitude = Number(longitude);
    const currentLocation = { latitude: parsedLatitude, longitude: parsedLongitude, timestamp: timestamp ? new Date(timestamp) : new Date() };
    const location = new Location({ busId, latitude: parsedLatitude, longitude: parsedLongitude, speed: speed || 0, timestamp: currentLocation.timestamp });
    await location.save();

    const bus = await Bus.findOne({ busId }).lean();
    const eta = calculateEta({
      currentLocation,
      speedKmph: speed || bus?.currentSpeed || 25,
      departureTime: bus?.departureTime || "07:30",
      route: {
        distanceKm: routeDistanceKm || bus?.routeDistanceKm || 0,
        destinationLatitude: destinationLatitude || bus?.destinationLatitude || 0,
        destinationLongitude: destinationLongitude || bus?.destinationLongitude || 0,
      },
      now: currentLocation.timestamp,
    });

    const updatedBus = await Bus.findOneAndUpdate({ busId }, {
      $set: {
        gpsStatus: "Online",
        currentLocation,
        currentSpeed: Number(speed) || 0,
        eta: { ...eta, updatedAt: currentLocation.timestamp },
        lastUpdated: currentLocation.timestamp,
      },
    }, { upsert: true, new: true });

    res.status(201).json({ success: true, message: "GPS data received", data: { location, bus: updatedBus } });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to process GPS data" });
  }
};

const createAlert = async (req, res) => {
  try {
    const alert = new Alert(req.body);
    await alert.save();
    await new Notification({ title: "New Alert", message: req.body.message, type: "alert" }).save();
    res.status(201).json({ success: true, message: "Alert created successfully", data: alert });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to create alert" });
  }
};

const listAlerts = async (req, res) => {
  try {
    const alerts = await Alert.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: alerts });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to fetch alerts" });
  }
};

const addMaintenance = async (req, res) => {
  try {
    const maintenance = new Maintenance(req.body);
    await maintenance.save();
    res.status(201).json({ success: true, message: "Maintenance record added", data: maintenance });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to add maintenance" });
  }
};

const listMaintenance = async (req, res) => {
  try {
    const items = await Maintenance.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: items });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to fetch maintenance" });
  }
};

const listLiveTracking = async (req, res) => {
  try {
    const buses = await Bus.find({ status: "active" }).sort({ updatedAt: -1 }).populate("driverId", "name driverId status availability");
    res.status(200).json({ success: true, data: await Promise.all(buses.map(serializeBus)) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to fetch live tracking" });
  }
};

const getTracking = async (req, res) => {
  try {
    const busId = req.params.busId || req.query.busId;
    const tracking = await Bus.findOne({ busId }).lean();
    if (!tracking) {
      return res.status(404).json({ success: false, message: "Tracking data not found" });
    }
    res.status(200).json({ success: true, data: tracking });
  } catch (error) {
    res.status(500).json({ success: false, message: "Unable to fetch tracking data" });
  }
};

module.exports = {
  getDashboardSummary,
  addBus,
  updateBus,
  deleteBus,
  listBuses,
  listBusesBySchedule,
  addDriver,
  listDrivers,
  updateDriver,
  deleteDriver,
  assignDriver,
  addRoute,
  listRoutes,
  updateRoute,
  deleteRoute,
  uploadPassengerCount,
  listPassengers,
  uploadGPS,
  createAlert,
  listAlerts,
  addMaintenance,
  listMaintenance,
  listLiveTracking,
  getTracking,
  validateBusAssignment,
};
