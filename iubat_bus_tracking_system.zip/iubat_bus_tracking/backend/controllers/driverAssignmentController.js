const DriverAssignment = require("../models/DriverAssignment");
const Driver = require("../models/Driver");
const Bus = require("../models/Bus");
const MorningRoute = require("../models/MorningRoute");
const EveningRoute = require("../models/EveningRoute");
const ShuttleRoute = require("../models/ShuttleRoute");

const routeModelBySchedule = {
  "Morning Route": "MorningRoute",
  "Evening Route": "EveningRoute",
  "Shuttle Route": "ShuttleRoute",
};

const routeModelFromSchedule = (scheduleType) => routeModelBySchedule[scheduleType] || null;

const assignmentDriverId = (assignment) => assignment.driverId || assignment.driver;
const assignmentBusId = (assignment) => assignment.busId || assignment.bus;

const hasConflictingShift = (driverShift, requestedShift) => {
  if (!driverShift || !requestedShift) return true;
  return driverShift === "All Day" || requestedShift === "All Day" || driverShift === requestedShift;
};

const validateAssignmentPayload = (payload, context = {}) => {
  const { driver, bus, route, activeAssignments = [] } = context;

  if (!payload.driverId || !payload.busId || !payload.scheduleType || !payload.shift) {
    return { valid: false, message: "Driver, bus, schedule type, and shift are required." };
  }

  if (!driver) {
    return { valid: false, message: "Driver not found." };
  }

  if (!driver.isActive) {
    return { valid: false, message: "Driver is inactive." };
  }

  if (driver.status === "On Duty" || driver.availability === "Busy") {
    return { valid: false, message: "Driver is currently on duty." };
  }

  if (driver.status === "On Leave" || driver.status === "Off Duty" || driver.availability === "On Leave") {
    return { valid: false, message: "Driver is unavailable." };
  }

  if (!bus) {
    return { valid: false, message: "Bus not found." };
  }

  if (bus.status !== "active") {
    return { valid: false, message: "Bus is inactive." };
  }

  if (!route && !payload.routeName) {
    return { valid: false, message: "Selected route does not exist." };
  }

  if (driver.assignedBus) {
    if (driver.assignedBus.toString() === payload.busId) {
      return { valid: false, message: "Driver is already assigned to this bus." };
    }
    return { valid: false, message: "Driver is already assigned to another bus." };
  }

  if (activeAssignments.some((assignment) => {
    const assignedDriverId = assignmentDriverId(assignment)?.toString();
    return assignedDriverId === payload.driverId && hasConflictingShift(assignment.shift, payload.shift);
  })) {
    return { valid: false, message: "Driver is already assigned to another bus for this shift." };
  }

  if (activeAssignments.some((assignment) => assignmentBusId(assignment)?.toString() === payload.busId)) {
    return { valid: false, message: "This bus is already assigned to an active route." };
  }

  return { valid: true };
};

const createAssignment = async (req, res) => {
  try {
    const { driverId, busId, scheduleType, shift, assignmentDate, status } = req.body;
    const bus = await Bus.findById(busId);
    const routeId = req.body.routeId || bus?.routeId || null;
    const routeModel = req.body.routeModel || bus?.routeModel || routeModelFromSchedule(scheduleType);
    const routeName = req.body.routeName || bus?.routeName || "";

    if (!bus) {
      return res.status(404).json({ success: false, message: "Bus not found." });
    }

    if (!routeModel) {
      return res.status(400).json({ success: false, message: "Unsupported schedule type." });
    }

    const [driver, route, activeAssignments] = await Promise.all([
      Driver.findById(driverId),
      routeModel === "MorningRoute"
        ? MorningRoute.findById(routeId)
        : routeModel === "EveningRoute"
          ? EveningRoute.findById(routeId)
          : ShuttleRoute.findById(routeId),
      DriverAssignment.find({ status: "Active" }).lean(),
    ]);

    const validation = validateAssignmentPayload(
      { driverId, busId, routeId, routeName, scheduleType, shift },
      {
        driver,
        bus,
        route,
        activeAssignments,
      }
    );

    if (!validation.valid) {
      return res.status(validation.message === "Driver, bus, schedule type, and shift are required." ? 400 : 409)
        .json({ success: false, message: validation.message });
    }

    const assignment = new DriverAssignment({
      driver: driver._id,
      bus: bus._id,
      scheduleType,
      routeModel,
      route: route?._id || null,
      routeName: route?.routeName || routeName,
      shift: shift || "Morning",
      assignmentDate: assignmentDate || new Date(),
      status: status || "Active",
    });

    await assignment.save();

    await Promise.all([
      Driver.findByIdAndUpdate(driver._id, { $set: { assignedBus: bus._id, assignedRoute: routeModel === "ShuttleRoute" ? route?._id || null : null, assignedRouteName: route?.routeName || routeName, assignedRouteModel: routeModel, shift: shift || "Morning", availability: "Busy", status: "On Duty", isActive: true } }),
      Bus.findByIdAndUpdate(bus._id, { $set: { driverName: driver.name, driverId: driver._id, routeId: route?._id || null, routeName: route?.routeName || routeName, routeModel, schedule: scheduleType === "Shuttle Route" ? "Shuttle" : scheduleType === "Evening Route" ? "Evening" : "Morning", status: "active" } }),
      route && routeModel === "MorningRoute"
        ? MorningRoute.findByIdAndUpdate(route._id, { $set: { assignedDriver: driver._id, assignedBus: bus._id, status: "Active" } })
        : route && routeModel === "EveningRoute"
          ? EveningRoute.findByIdAndUpdate(route._id, { $set: { assignedDriver: driver._id, assignedBus: bus._id, status: "Active" } })
          : route ? ShuttleRoute.findByIdAndUpdate(route._id, { $set: { assignedDriver: driver._id, assignedBus: bus._id, status: "Active" } }) : Promise.resolve(),
    ]);

    const populated = await DriverAssignment.findById(assignment._id).populate("driver").populate("bus").populate({ path: "route", model: routeModel });

    res.status(201).json({ success: true, message: "Driver assigned successfully", data: populated });
  } catch (error) {
    console.error("[POST /api/assignments] error", error);
    if (error.name === "ValidationError") return res.status(400).json({ success: false, message: error.message });
    res.status(500).json({ success: false, message: error.message || "Unable to create assignment", error: error.name });
  }
};

const listAssignments = async (req, res) => {
  try {
    const assignments = await DriverAssignment.find().sort({ assignmentDate: -1 }).populate("driver").populate("bus").populate({ path: "route", model: "MorningRoute" });
    res.status(200).json({ success: true, data: assignments });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to load assignments" });
  }
};

const listAssignmentsBySchedule = async (req, res) => {
  try {
    const { scheduleType } = req.params;
    const model = routeModelFromSchedule(scheduleType);
    const assignments = await DriverAssignment.find({ scheduleType }).sort({ assignmentDate: -1 }).populate("driver").populate("bus").populate({ path: "route", model });
    res.status(200).json({ success: true, data: assignments });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to load assignments" });
  }
};

const getDashboardStats = async (req, res) => {
  try {
    const [morningRoutes, eveningRoutes, shuttleRoutes, assignments, drivers, buses] = await Promise.all([
      MorningRoute.countDocuments(),
      EveningRoute.countDocuments(),
      ShuttleRoute.countDocuments(),
      DriverAssignment.find({ status: "Active" }),
      Driver.find({ isActive: true }),
      Bus.find(),
    ]);

    const availableDrivers = drivers.filter((driver) => driver.availability === "Available" || driver.status === "Available").length;
    const unassignedDrivers = drivers.length - assignments.length;
    const onlineBuses = buses.filter((bus) => bus.gpsStatus === "Online").length;
    const offlineBuses = buses.filter((bus) => bus.gpsStatus === "Offline").length;

    res.status(200).json({
      success: true,
      data: {
        morningRoutes,
        eveningRoutes,
        shuttleRoutes,
        assignedDrivers: assignments.length,
        availableDrivers,
        unassignedDrivers,
        onlineBuses,
        offlineBuses,
        activeRoutes: morningRoutes + eveningRoutes + shuttleRoutes,
      },
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ success: false, message: "Unable to load dashboard stats" });
  }
};

module.exports = {
  createAssignment,
  listAssignments,
  listAssignmentsBySchedule,
  getDashboardStats,
  validateAssignmentPayload,
};
