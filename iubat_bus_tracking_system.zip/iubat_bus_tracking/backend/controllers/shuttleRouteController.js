const ShuttleRoute = require("../models/ShuttleRoute");

// GET /api/shuttle-routes - Get all shuttle routes dynamically
const getShuttleRoutes = async (req, res) => {
  try {
    const routes = await ShuttleRoute.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: routes
    });
  } catch (error) {
    console.error("Error fetching shuttle routes:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

// GET /api/shuttle-routes/:id - Get single shuttle route
const getShuttleRoute = async (req, res) => {
  try {
    const { id } = req.params;

    const route = await ShuttleRoute.findById(id);

    if (!route) {
      return res.status(404).json({
        success: false,
        message: "Shuttle route not found"
      });
    }

    res.status(200).json({
      success: true,
      data: route
    });
  } catch (error) {
    console.error("Error fetching shuttle route:", error);
    res.status(500).json({
      success: false,
      message: "Internal server error"
    });
  }
};

module.exports = {
  getShuttleRoutes,
  getShuttleRoute,
};