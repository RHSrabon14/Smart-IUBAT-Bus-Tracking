const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
require("dotenv").config();

const Student = require("./models/Student");

const { MONGO_URI, STUDENT_INITIAL_PASSWORD } = process.env;

if (!MONGO_URI || !STUDENT_INITIAL_PASSWORD) {
  console.error("Set MONGO_URI and STUDENT_INITIAL_PASSWORD in backend/.env before creating student users.");
  process.exit(1);
}

mongoose.connect(MONGO_URI)
.then(async () => {
  console.log("Connected");

  const students = [
    "22103029",
    "23203049",
    "23203089"
  ];

  for (let id of students) {
    const hashed = await bcrypt.hash(STUDENT_INITIAL_PASSWORD, 10);

    await Student.create({
      studentId: id,
      email: `${id}@iubat.edu`,
      password: hashed
    });

    console.log(`Created: ${id}`);
  }

  mongoose.disconnect();
})
.catch(err => console.log(err));