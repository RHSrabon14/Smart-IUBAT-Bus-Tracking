const mongoose = require('mongoose');

const busDataSchema = new mongoose.Schema({
    busId: {
        type: String,
        required: true,
        index: true
    },
    routeId: {
        type: String,
        required: true
    },
    passengerCount: {
        type: Number,
        default: 0
    },
    latitude: {
        type: Number,
        default: 0
    },
    longitude: {
        type: Number,
        default: 0
    },
    speed: {
        type: Number,
        default: 0
    },
    satellites: {
        type: Number,
        default: 0
    },
    gpsFixed: {
        type: Boolean,
        default: false
    },
    imagePath: {
        type: String
    },
    imageUrl: {
        type: String
    },
    imageSize: {
        type: Number,
        default: 0
    },
    processing: {
        type: Boolean,
        default: true
    },
    detections: {
        type: Array,
        default: []
    },
    totalDetections: {
        type: Number,
        default: 0
    },
    yoloTimestamp: {
        type: String
    },
    error: {
        type: String
    }
}, {
    timestamps: true
});

// Index for faster queries
busDataSchema.index({ busId: 1, createdAt: -1 });

module.exports = mongoose.model('BusData', busDataSchema);