const mongoose = require("mongoose");

const trackingSchema = new mongoose.Schema({
  busId: { type: String, required: true, trim: true },
  route: { type: String, default: "" },
  driver: { type: String, default: "" },
  passengerCount: { type: Number, default: 0 },
  status: { type: String, enum: ["Waiting", "Running", "Delayed", "Arrived"], default: "Waiting" },
  estimatedArrivalTime: { type: String, default: "" },
  coordinates: {
    latitude: { type: Number, default: 0 },
    longitude: { type: Number, default: 0 },
  },
  timestamp: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model("Tracking", trackingSchema);
