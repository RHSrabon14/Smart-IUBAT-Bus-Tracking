const mongoose = require("mongoose");

const locationSchema = new mongoose.Schema({
  busId: {
    type: String,
    required: true,
    trim: true,
  },
  latitude: {
    type: Number,
    required: true,
  },
  longitude: {
    type: Number,
    required: true,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  speed: {
    type: Number,
    default: 0,
  },
  satellites: {
    type: Number,
    default: 0,
  },
  gpsFixed: {
    type: Boolean,
    default: false,
  },
  accuracy: {
    type: Number,
    default: 0,
  },
}, {
  timestamps: true,
});

// Index for efficient queries
locationSchema.index({ busId: 1, timestamp: -1 });

module.exports = mongoose.model("Location", locationSchema);