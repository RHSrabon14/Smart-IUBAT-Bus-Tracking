const mongoose = require("mongoose");

const routeSchema = new mongoose.Schema({
  busNo: {
    type: String,
    required: true,
    trim: true,
  },
  busId: {
    type: String,
    trim: true,
  },
  routeId: {
    type: String,
    trim: true,
    default: "",
    index: true,
  },
  routeName: {
    type: String,
    required: true,
    trim: true,
  },
  time: {
    type: String,
    required: true,
    trim: true,
    default: "Not Fixed",
  },
  type: {
    type: String,
    required: true,
    enum: ["all", "shuttle"],
    default: "shuttle",
  },
  pickupPoints: {
    type: [String],
    default: [],
  },
  destination: {
    type: String,
    default: "",
  },
  schedule: {
    type: String,
    default: "",
  },
  estimatedTravelTime: {
    type: String,
    default: "",
  },
  assignedBus: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bus",
    default: null,
  },
  assignedDriver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Driver",
    default: null,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("ShuttleRoute", routeSchema);