const mongoose = require("mongoose");

const facultySchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  otp: String,
  otpExpiry: Date,
  otpAttempts: { type: Number, default: 0 },
  lastOtpRequest: Date,
  resetPasswordOTPHash: String,
  resetPasswordOTPExpires: Date,
});

module.exports = mongoose.model("Faculty", facultySchema);