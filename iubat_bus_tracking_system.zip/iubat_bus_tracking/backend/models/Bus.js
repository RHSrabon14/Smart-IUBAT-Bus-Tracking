const mongoose = require("mongoose");

const busSchema = new mongoose.Schema({
  busId: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  busNumber: {
    type: String,
    required: true,
    trim: true,
  },
  busName: {
    type: String,
    trim: true,
    default: "",
  },
  routeId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "ShuttleRoute",
    default: null,
  },
  routeCode: {
    type: String,
    trim: true,
    default: "",
    index: true,
  },
  routeName: {
    type: String,
    trim: true,
    default: "",
  },
  routeModel: {
    type: String,
    enum: ["MorningRoute", "EveningRoute", "ShuttleRoute", ""],
    default: "",
  },
  driverId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Driver",
    default: null,
  },
  schedule: {
    type: String,
    enum: ["Morning", "Evening", "Shuttle"],
    default: "Morning",
  },
  departureTime: {
    type: String,
    trim: true,
    default: "07:30",
  },
  routeDistanceKm: {
    type: Number,
    default: 0,
  },
  destinationLatitude: {
    type: Number,
    default: 0,
  },
  destinationLongitude: {
    type: Number,
    default: 0,
  },
  capacity: {
    type: Number,
    default: 50,
  },
  currentSpeed: {
    type: Number,
    default: 0,
  },
  currentPassengerCount: {
    type: Number,
    default: 0,
  },
  satellites: {
    type: Number,
    default: 0,
  },
  gpsFixed: {
    type: Boolean,
    default: false,
  },
  occupancyStatus: {
    type: String,
    enum: ["Low", "Medium", "High", "Full"],
    default: "Low",
  },
  driverName: {
    type: String,
    trim: true,
    default: "",
  },
  gpsStatus: {
    type: String,
    enum: ["Online", "Offline"],
    default: "Offline",
  },
  cameraStatus: {
    type: String,
    enum: ["Online", "Offline"],
    default: "Offline",
  },
  runningStatus: {
    type: String,
    enum: ["Running", "Stopped", "Maintenance"],
    default: "Stopped",
  },
  status: {
    type: String,
    enum: ["active", "inactive", "maintenance"],
    default: "active",
  },
  currentLocation: {
    latitude: {
      type: Number,
    },
    longitude: {
      type: Number,
    },
    timestamp: {
      type: Date,
    },
  },
  lastUpdated: {
    type: Date,
    default: Date.now,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("Bus", busSchema);