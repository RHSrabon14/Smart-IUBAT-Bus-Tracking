const mongoose = require("mongoose");

const foundItemSchema = new mongoose.Schema({
  itemName: { type: String, required: true },
  category: { type: String, required: true },
  description: { type: String, required: true },
  busNumber: { type: String, required: true },
  route: { type: String, required: true },
  dateFound: { type: Date, required: true },
  reportedBy: { type: String, default: "Admin" },
  phone: { type: String, required: true },
  imageUrl: { type: String, default: "" },
  status: {
    type: String,
    enum: ["Found", "Ready for Collection", "Returned"],
    default: "Found",
  },
  matchedLostItem: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "LostItem",
    default: null,
  },
}, { timestamps: true });

module.exports = mongoose.model("FoundItem", foundItemSchema);
