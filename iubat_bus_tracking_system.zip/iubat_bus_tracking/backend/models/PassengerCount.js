const mongoose = require("mongoose");

const passengerCountSchema = new mongoose.Schema({
  busId: {
    type: String,
    required: true,
    trim: true,
  },
  passengerCount: {
    type: Number,
    required: true,
    min: 0,
  },
  timestamp: {
    type: Date,
    default: Date.now,
  },
  occupancyStatus: {
    type: String,
    enum: ["Low", "Medium", "High", "Full"],
    default: "Low",
  },
  capacity: {
    type: Number,
    default: 50,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("PassengerCount", passengerCountSchema);
