const mongoose = require("mongoose");

const driverSchema = new mongoose.Schema({
  driverId: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  name: {
    type: String,
    required: true,
    trim: true,
  },
  phone: {
    type: String,
    required: true,
    trim: true,
  },
  email: {
    type: String,
    trim: true,
    lowercase: true,
  },
  licenseNumber: {
    type: String,
    trim: true,
  },
  licenseExpiryDate: {
    type: Date,
  },
  address: {
    type: String,
    trim: true,
  },
  photo: {
    type: String,
    default: "",
  },
  nationalId: {
    type: String,
    trim: true,
    default: "",
  },
  experience: {
    type: Number,
    default: 0,
  },
  assignedBus: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bus",
    default: null,
  },
  assignedRoute: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "ShuttleRoute",
    default: null,
  },
  assignedRouteName: {
    type: String,
    trim: true,
    default: "",
  },
  assignedRouteModel: {
    type: String,
    enum: ["MorningRoute", "EveningRoute", "ShuttleRoute", ""],
    default: "",
  },
  joiningDate: {
    type: Date,
    default: Date.now,
  },
  emergencyContact: {
    type: String,
    trim: true,
  },
  status: {
    type: String,
    enum: ["Available", "On Duty", "Off Duty", "On Leave"],
    default: "Available",
  },
  shift: {
    type: String,
    enum: ["Morning", "Evening", "All Day"],
    default: "Morning",
  },
  availability: {
    type: String,
    enum: ["Available", "Busy", "On Leave"],
    default: "Available",
  },
  isActive: {
    type: Boolean,
    default: true,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("Driver", driverSchema);
