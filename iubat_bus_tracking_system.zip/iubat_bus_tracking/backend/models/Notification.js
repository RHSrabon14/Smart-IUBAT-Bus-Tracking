const mongoose = require("mongoose");

const notificationSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  message: {
    type: String,
    required: true,
    trim: true,
  },
  type: {
    type: String,
    default: "info",
  },
  isRead: {
    type: Boolean,
    default: false,
  },
  recipient: {
    type: String,
    default: "all",
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("Notification", notificationSchema);
