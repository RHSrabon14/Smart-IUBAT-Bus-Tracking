const mongoose = require("mongoose");

const lostItemSchema = new mongoose.Schema({
  itemName: { type: String, required: true },
  category: { type: String, required: true },
  description: { type: String, required: true },
  busNumber: { type: String, required: true },
  route: { type: String, required: true },
  dateLost: { type: Date, required: true },
  studentId: { type: String, required: true },
  phone: { type: String, required: true },
  imageUrl: { type: String, default: "" },
  status: {
    type: String,
    enum: ["Lost", "Found", "Ready for Collection", "Returned"],
    default: "Lost",
  },
  matchedFoundItem: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "FoundItem",
    default: null,
  },
}, { timestamps: true });

module.exports = mongoose.model("LostItem", lostItemSchema);
