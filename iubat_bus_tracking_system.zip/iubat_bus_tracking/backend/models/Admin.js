const mongoose = require("mongoose");

const adminSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  role: { type: String, default: "admin" },
  otp: String,
  otpExpiry: Date,
  otpAttempts: { type: Number, default: 0 },
  lastOtpRequest: Date,
  resetPasswordOTPHash: String,
  resetPasswordOTPExpires: Date,
});

module.exports = mongoose.model("Admin", adminSchema);