const mongoose = require("mongoose");

const maintenanceSchema = new mongoose.Schema({
  busId: {
    type: String,
    required: true,
    trim: true,
  },
  lastServiceDate: {
    type: Date,
    default: Date.now,
  },
  nextServiceDate: {
    type: Date,
    required: true,
  },
  odometer: {
    type: Number,
    default: 0,
  },
  status: {
    type: String,
    enum: ["Good", "Needs Service", "Critical"],
    default: "Good",
  },
  notes: {
    type: String,
    default: "",
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("Maintenance", maintenanceSchema);
