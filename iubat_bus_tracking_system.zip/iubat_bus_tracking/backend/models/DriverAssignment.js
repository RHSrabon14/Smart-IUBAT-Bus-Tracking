const mongoose = require("mongoose");

const driverAssignmentSchema = new mongoose.Schema({
  driver: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Driver",
    required: true,
  },
  bus: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Bus",
    required: true,
  },
  scheduleType: {
    type: String,
    enum: ["Morning Route", "Evening Route", "Shuttle Route"],
    required: true,
  },
  routeModel: {
    type: String,
    enum: ["MorningRoute", "EveningRoute", "ShuttleRoute"],
    default: "ShuttleRoute",
  },
  route: {
    type: mongoose.Schema.Types.ObjectId,
    refPath: "routeModel",
    default: null,
  },
  routeName: {
    type: String,
    trim: true,
    default: "",
  },
  shift: {
    type: String,
    enum: ["Morning", "Evening", "All Day"],
    default: "Morning",
  },
  assignmentDate: {
    type: Date,
    default: Date.now,
  },
  status: {
    type: String,
    enum: ["Active", "Completed", "Cancelled"],
    default: "Active",
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("DriverAssignment", driverAssignmentSchema);
