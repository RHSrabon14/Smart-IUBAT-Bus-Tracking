const mongoose = require("mongoose");

const studentSchema = new mongoose.Schema({
  studentId: String,
  email: String,
  password: String,
  otp: String,
  otpExpiry: Date,
  otpAttempts: { type: Number, default: 0 },
  lastOtpRequest: Date,
  resetPasswordOTPHash: String,
  resetPasswordOTPExpires: Date,
});

module.exports = mongoose.model("Student", studentSchema);