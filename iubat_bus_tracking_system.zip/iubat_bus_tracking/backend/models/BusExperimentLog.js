const mongoose = require('mongoose');

const calculateAbsoluteCountError = (groundTruth, yoloPassengerCount) => {
  if (groundTruth === null || groundTruth === undefined || yoloPassengerCount === null || yoloPassengerCount === undefined) {
    return null;
  }

  return Math.abs(Number(groundTruth) - Number(yoloPassengerCount));
};

const busExperimentLogSchema = new mongoose.Schema({
  trialId: {
    type: String,
    required: true,
    unique: true,
    index: true,
  },
  busId: {
    type: String,
    required: true,
    index: true,
  },
  routeId: {
    type: String,
    default: null,
  },
  serverReceivedAt: {
    type: Date,
    default: Date.now,
  },
  imageFileName: {
    type: String,
    default: null,
  },
  imageFileId: {
    type: String,
    default: null,
  },
  imageSizeBytes: {
    type: Number,
    default: 0,
  },
  imageReceivedAt: {
    type: Date,
    default: null,
  },
  imageStorageCompletedAt: {
    type: Date,
    default: null,
  },
  imageStorageDurationMs: {
    type: Number,
    default: null,
  },
  latitude: {
    type: Number,
    default: 0,
  },
  longitude: {
    type: Number,
    default: 0,
  },
  speed: {
    type: Number,
    default: 0,
  },
  satellites: {
    type: Number,
    default: 0,
  },
  gpsFixed: {
    type: Boolean,
    default: false,
  },
  yoloRequestStartedAt: {
    type: Date,
    default: null,
  },
  yoloResponseAt: {
    type: Date,
    default: null,
  },
  yoloProcessingDurationMs: {
    type: Number,
    default: null,
  },
  yoloPassengerCount: {
    type: Number,
    default: null,
  },
  processingDurationMs: {
    type: Number,
    default: null,
  },
  endToEndDurationMs: {
    type: Number,
    default: null,
  },
  uploadSuccess: {
    type: Boolean,
    default: false,
  },
  imageTransmissionSuccess: {
    type: Boolean,
    default: false,
  },
  yoloSuccess: {
    type: Boolean,
    default: false,
  },
  httpStatusCode: {
    type: Number,
    default: null,
  },
  errorMessage: {
    type: String,
    default: null,
  },
  groundTruthPassengerCount: {
    type: Number,
    default: null,
  },
  absoluteCountError: {
    type: Number,
    default: null,
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model('BusExperimentLog', busExperimentLogSchema, 'bus_experiment_logs');
