const mongoose = require("mongoose");

const morningRouteSchema = new mongoose.Schema({
  busNo: { type: String, required: true, trim: true },
  busId: { type: String, trim: true, default: "" },
  routeId: { type: String, trim: true, default: "", index: true },
  routeName: { type: String, required: true, trim: true },
  departureLocation: { type: String, default: "" },
  destination: { type: String, default: "IUBAT Campus" },
  time: { type: String, default: "Not Fixed" },
  stops: { type: [String], default: [] },
  status: { type: String, enum: ["Active", "Delayed", "Cancelled"], default: "Active" },
  gpsEnabled: { type: Boolean, default: true },
  assignedDriver: { type: mongoose.Schema.Types.ObjectId, ref: "Driver", default: null },
  assignedBus: { type: mongoose.Schema.Types.ObjectId, ref: "Bus", default: null },
  routeType: { type: String, default: "morning" },
}, {
  timestamps: true,
});

module.exports = mongoose.model("MorningRoute", morningRouteSchema);
