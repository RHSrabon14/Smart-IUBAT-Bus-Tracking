const mongoose = require("mongoose");

const driverPerformanceSchema = new mongoose.Schema({
  driverId: { type: mongoose.Schema.Types.ObjectId, ref: "Driver", required: true },
  driverName: { type: String, default: "" },
  safety: { type: Number, default: 0, min: 0, max: 5 },
  behaviour: { type: Number, default: 0, min: 0, max: 5 },
  cleanliness: { type: Number, default: 0, min: 0, max: 5 },
  punctuality: { type: Number, default: 0, min: 0, max: 5 },
  overallRating: { type: Number, default: 0, min: 0, max: 5 },
  comment: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now },
}, { timestamps: true });

module.exports = mongoose.model("DriverPerformance", driverPerformanceSchema);
