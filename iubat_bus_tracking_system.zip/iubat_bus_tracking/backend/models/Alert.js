const mongoose = require("mongoose");

const alertSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  message: {
    type: String,
    required: true,
    trim: true,
  },
  type: {
    type: String,
    enum: ["Bus Delay", "Route Changed", "Emergency", "Maintenance", "Holiday", "Weather", "Bus Breakdown"],
    default: "Bus Delay",
  },
  busId: {
    type: String,
    default: "",
  },
  route: {
    type: String,
    default: "",
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  createdBy: {
    type: String,
    default: "Admin",
  },
}, {
  timestamps: true,
});

module.exports = mongoose.model("Alert", alertSchema);
